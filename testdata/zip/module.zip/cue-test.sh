#!/bin/sh

set -o errexit
set -o xtrace

./cue.sh eval --all --concrete -e tests ./...
