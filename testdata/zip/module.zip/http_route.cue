package defs

import (
	"prodigy9.co/defs/attr"
	"prodigy9.co/defs/parts"
)

#HTTPRoute: Self={
	parts.#Metadata
	attr.#Hosts
	attr.#ServiceRef

	#gateway_name: string
	#gateway_ns?:  string

	apiVersion: "gateway.networking.k8s.io/v1"
	kind:       "HTTPRoute"

	spec: {
		parentRefs: [{
			name: Self.#gateway_name
			if Self.#gateway_ns != _|_ {
				namespace: Self.#gateway_ns
			}
		}]
		hostnames: Self.#hosts
		rules: [{
			backendRefs: [{
				name: Self.#service_name
				port: Self.#service_port
			}]
		}]
	}
}

tests: http_route: [

	// basic
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "HTTPRoute"
			metadata: {
				name:      "my-route"
				namespace: "my-ns"
			}
			spec: {
				parentRefs: [{name: "my-gateway"}]
				hostnames: ["example.com"]
				rules: [{
					backendRefs: [{
						name: "my-service"
						port: 80
					}]
				}]
			}
		}

		#Expected & #HTTPRoute & {
			#name:         "my-route"
			#ns:           "my-ns"
			#gateway_name: "my-gateway"
			#hosts: ["example.com"]
			#service_name: "my-service"
			#service_port: 80
		}
	},

	// multiple hosts
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "HTTPRoute"
			metadata: {
				name:      "my-route"
				namespace: "my-ns"
			}
			spec: {
				parentRefs: [{name: "my-gateway"}]
				hostnames: ["alpha.com", "beta.com"]
				rules: [{
					backendRefs: [{
						name: "my-service"
						port: 80
					}]
				}]
			}
		}

		#Expected & #HTTPRoute & {
			#name:         "my-route"
			#ns:           "my-ns"
			#gateway_name: "my-gateway"
			#hosts: ["alpha.com", "beta.com"]
			#service_name: "my-service"
			#service_port: 80
		}
	},

	// cross-namespace gateway ref
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "HTTPRoute"
			metadata: {
				name:      "my-route"
				namespace: "my-ns"
			}
			spec: {
				parentRefs: [{
					name:      "shared-gateway"
					namespace: "infra"
				}]
				hostnames: ["example.com"]
				rules: [{
					backendRefs: [{
						name: "my-service"
						port: 8080
					}]
				}]
			}
		}

		#Expected & #HTTPRoute & {
			#name:         "my-route"
			#ns:           "my-ns"
			#gateway_name: "shared-gateway"
			#gateway_ns:   "infra"
			#hosts: ["example.com"]
			#service_name: "my-service"
			#service_port: 8080
		}
	},

]
