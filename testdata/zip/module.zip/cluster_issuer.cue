package defs

import "prodigy9.co/defs/parts"

#ClusterIssuer: Self={
	parts.#Metadata

	#email:   string
	#staging: bool | *false

	// Gateway to use for HTTP-01 ACME challenges. cert-manager creates a
	// temporary HTTPRoute against this Gateway during challenge solving.
	// Requires cert-manager installed with gateway API support enabled.
	#gateway_name: string
	#gateway_ns:   string

	apiVersion: "cert-manager.io/v1"
	kind:       "ClusterIssuer"

	spec: acme: {
		email: Self.#email
		if Self.#staging {
			server: "https://acme-staging-v02.api.letsencrypt.org/directory"
		}
		if !Self.#staging {
			server: "https://acme-v02.api.letsencrypt.org/directory"
		}
		privateKeySecretRef: name: Self.#name + "-secret"
		solvers: [{
			http01: gatewayHTTPRoute: parentRefs: [{
				group:     "gateway.networking.k8s.io"
				kind:      "Gateway"
				name:      Self.#gateway_name
				namespace: Self.#gateway_ns
			}]
		}]
	}
}

tests: cluster_issuer: [

	// Let's Encrypt prod via gateway HTTP-01
	{
		#Expected: {
			apiVersion: "cert-manager.io/v1"
			kind:       "ClusterIssuer"
			metadata: name: "cluster-issuer-main"
			spec: acme: {
				email:  "ops@example.com"
				server: "https://acme-v02.api.letsencrypt.org/directory"
				privateKeySecretRef: name: "cluster-issuer-main-secret"
				solvers: [{
					http01: gatewayHTTPRoute: parentRefs: [{
						group:     "gateway.networking.k8s.io"
						kind:      "Gateway"
						name:      "main-gateway"
						namespace: "gateway-system"
					}]
				}]
			}
		}

		#Expected & #ClusterIssuer & {
			#name:         "cluster-issuer-main"
			#email:        "ops@example.com"
			#gateway_name: "main-gateway"
			#gateway_ns:   "gateway-system"
		}
	},

	// staging: alternate ACME endpoint
	{
		#Expected: {
			apiVersion: "cert-manager.io/v1"
			kind:       "ClusterIssuer"
			metadata: name: "cluster-issuer-staging"
			spec: acme: {
				email:  "ops@example.com"
				server: "https://acme-staging-v02.api.letsencrypt.org/directory"
				privateKeySecretRef: name: "cluster-issuer-staging-secret"
				solvers: [{
					http01: gatewayHTTPRoute: parentRefs: [{
						group:     "gateway.networking.k8s.io"
						kind:      "Gateway"
						name:      "main-gateway"
						namespace: "gateway-system"
					}]
				}]
			}
		}

		#Expected & #ClusterIssuer & {
			#name:         "cluster-issuer-staging"
			#email:        "ops@example.com"
			#staging:      true
			#gateway_name: "main-gateway"
			#gateway_ns:   "gateway-system"
		}
	},
]
