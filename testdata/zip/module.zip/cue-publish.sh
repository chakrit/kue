#!/bin/sh

set -o errexit
set -o nounset

cd "$(dirname "$0")"

if ! git diff --quiet || ! git diff --cached --quiet; then
	echo "refusing to publish: working tree dirty" >&2
	exit 1
fi

BRANCH="$(git rev-parse --abbrev-ref HEAD)"
if [ "${BRANCH}" != "main" ]; then
	echo "refusing to publish: not on main (on ${BRANCH})" >&2
	exit 1
fi

VERSION="$(git describe --exact-match --match 'v*' HEAD 2>/dev/null || true)"
if [ -z "${VERSION}" ]; then
	echo "refusing to publish: HEAD is not on an annotated v* tag" >&2
	exit 1
fi

set -o xtrace
./cue-check.sh
./cue-test.sh >/dev/null
./cue.sh mod publish "${VERSION}"
