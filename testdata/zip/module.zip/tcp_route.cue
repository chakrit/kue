package defs

import (
	"prodigy9.co/defs/attr"
	"prodigy9.co/defs/parts"
)

#TCPRoute: Self={
	parts.#Metadata
	attr.#ServiceRef

	#gateway_name: string
	#gateway_ns?:  string

	apiVersion: "gateway.networking.k8s.io/v1alpha2"
	kind:       "TCPRoute"

	spec: {
		parentRefs: [{
			name:        Self.#gateway_name
			sectionName: "tcp-\(Self.#service_port)"
			if Self.#gateway_ns != _|_ {
				namespace: Self.#gateway_ns
			}
		}]
		rules: [{
			backendRefs: [{
				name: Self.#service_name
				port: Self.#service_port
			}]
		}]
	}
}

tests: tcp_route: [

	// basic
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1alpha2"
			kind:       "TCPRoute"
			metadata: {
				name:      "postgres-tcp"
				namespace: "my-ns"
			}
			spec: {
				parentRefs: [{
					name:        "my-gateway"
					sectionName: "tcp-5432"
				}]
				rules: [{
					backendRefs: [{
						name: "postgres-service"
						port: 5432
					}]
				}]
			}
		}

		#Expected & #TCPRoute & {
			#name:         "postgres-tcp"
			#ns:           "my-ns"
			#gateway_name: "my-gateway"
			#service_name: "postgres-service"
			#service_port: 5432
		}
	},

	// cross-namespace gateway ref
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1alpha2"
			kind:       "TCPRoute"
			metadata: {
				name:      "redis-tcp"
				namespace: "my-ns"
			}
			spec: {
				parentRefs: [{
					name:        "shared-gateway"
					sectionName: "tcp-6379"
					namespace:   "infra"
				}]
				rules: [{
					backendRefs: [{
						name: "redis-service"
						port: 6379
					}]
				}]
			}
		}

		#Expected & #TCPRoute & {
			#name:         "redis-tcp"
			#ns:           "my-ns"
			#gateway_name: "shared-gateway"
			#gateway_ns:   "infra"
			#service_name: "redis-service"
			#service_port: 6379
		}
	},

]
