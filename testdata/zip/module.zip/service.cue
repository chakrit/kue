package defs

import (
	"prodigy9.co/defs/attr"
	"prodigy9.co/defs/parts"
)

#Service: Self={
	parts.#Metadata
	attr.#Ports

	#type?: string
	#selector: [string]: string

	apiVersion: "v1"
	kind:       "Service"
	spec: {
		selector: Self.#selector
		if Self.#type != _|_ {
			type: Self.#type
		}

		ports: [
			for p in Self.#ports {
				name:       "tcp-\(p)"
				protocol:   "TCP"
				port:       p
				targetPort: p
			},
		]
	}
}

tests: service: [
	// basic
	#Service & {
		#name: "example"
		#selector: "prodigy9.co/app": "cueinfra"
		#port: 80
	} & {
		apiVersion: "v1"
		kind:       "Service"
		metadata: name: "example"
		spec: close({// closed so no type: is added
			selector: {"prodigy9.co/app": "cueinfra"}
			ports: [
				{
					name:       "tcp-80"
					protocol:   "TCP"
					port:       80
					targetPort: 80
				},
			]
		})
	},

	// type specified
	#Service & {
		#name: "example"
		#selector: "prodigy9.co/app": "cueinfra"
		#type: "NodePort"
		#port: 8080
	} & {
		apiVersion: "v1"
		kind:       "Service"
		metadata: name: "example"
		spec: {
			selector: "prodigy9.co/app": "cueinfra"
			type: "NodePort"
			ports: [
				{
					name:       "tcp-8080"
					protocol:   "TCP"
					port:       8080
					targetPort: 8080
				},
			]
		}
	},

	// multiple ports
	#Service & {
		#name: "example"
		#selector: "prodigy9.co/app": "cueinfra"
		#ports: [80, 443, 8443, 8080]
	} & {
		apiVersion: "v1"
		kind:       "Service"
		metadata: name: "example"
		spec: close({
			selector: "prodigy9.co/app": "cueinfra"

			ports: [...{
				protocol:   "TCP"
				name:       "tcp-\(port)"
				port:       int
				targetPort: port
			}]
			ports: [{port: 80}, {port: 443}, {port: 8443}, {port: 8080}]
		})
	},
]
