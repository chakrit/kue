package defs

import "prodigy9.co/defs/parts"

#PVC: Self={
	parts.#Metadata

	#storage:       string | *"10Gi"
	#storage_class: string | *"linode-block-storage-retain"

	apiVersion: "v1"
	kind:       "PersistentVolumeClaim"
	spec: {
		accessModes: ["ReadWriteOnce"]
		resources: requests: storage: Self.#storage
		storageClassName: #storage_class
	}
}

tests: pvc: [

	// basic
	#PVC & {
		#name:    "example"
		#ns:      "default"
		#storage: "20Gi"
	} & close({
		apiVersion: "v1"
		kind:       "PersistentVolumeClaim"
		metadata: close({
			name:      "example"
			namespace: "default"
		})
		spec: close({
			accessModes: ["ReadWriteOnce"]
			resources: close({requests: close({storage: "20Gi"})})
			storageClassName: "linode-block-storage-retain"
		})
	}),

	// with storage class
	#PVC & {
		#name:          "example"
		#ns:            "default"
		#storage:       "20Gi"
		#storage_class: "custom-storage-class"
	} & close({
		apiVersion: "v1"
		kind:       "PersistentVolumeClaim"
		metadata: close({name: "example"
			namespace: "default"
		})
		spec: close({
			accessModes: ["ReadWriteOnce"]
			resources: close({requests: close({storage: "20Gi"})})
			storageClassName: "custom-storage-class"
		})
	}),

]
