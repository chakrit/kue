package defs

import (
	"strings"
	"encoding/base64"
	"encoding/json"

	"prodigy9.co/defs/parts"
)

_#OpaqueSecret: Self={
	#type: "Opaque"
	#data: [string]: string

	data: {
		for k, v in Self.#data {
			"\(k)": base64.Encode(null, strings.TrimSpace(v))
		}
	}
}

_#DockerConfigSecret: Self={
	#type: "kubernetes.io/dockerconfigjson"
	#data: [string]: {
		username: string
		password: string
	}

	data: {
		let _auths = {
			for domain, creds in Self.#data {
				let _authstr = "\(creds.username):\(creds.password)"
				"\(domain)": auth: base64.Encode(null, strings.TrimSpace(_authstr))
			}
		}

		".dockerconfigjson": base64.Encode(null, json.Marshal({auths: _auths}))
	}
}

_#TLSSecret: {
	#type: "kubernetes.io/tls"
	#data: {
		cert: string
		key:  string
	}

	data: {
		"tls.crt": base64.Encode(null, strings.TrimSpace(#data.cert))
		"tls.key": base64.Encode(null, strings.TrimSpace(#data.key))
	}
}

#Secret: Self={
	parts.#Metadata
	(*_#OpaqueSecret | _#DockerConfigSecret | _#TLSSecret)

	apiVersion: "v1"
	kind:       "Secret"
	type:       Self.#type
	data: [string]: string
}

tests: secret: [

	// empty
	#Secret & {
		#name: "example"
	} & {
		apiVersion: "v1"
		kind:       "Secret"
		metadata: name: "example"
		data: {}
	},

	// empty, but with all metadata
	#Secret & {
		#name: "example"
		#ns:   "my-ns"
		#labels: "prodigy9.co/app":         "cueinfra"
		#annotations: "keel.sh/managed-by": "keel"

		#type: "Opaque"
		#data: {}
	} & {
		apiVersion: "v1"
		kind:       "Secret"
		metadata: {
			name:      "example"
			namespace: "my-ns"
			labels: "prodigy9.co/app":         "cueinfra"
			annotations: "keel.sh/managed-by": "keel"
		}
		data: {}
	},

	// with some data
	#Secret & {
		#name: "example"
		#data: {
			username: "admin"
			password: "s3cr3t"
		}
	} & {
		apiVersion: "v1"
		kind:       "Secret"
		metadata: name: "example"
		data: {
			username: "YWRtaW4="
			password: "czNjcjN0"
		}
	},

	// everything
	#Secret & {
		#name: "example"
		#labels: "prodigy9.co/app":         "cueinfra"
		#annotations: "keel.sh/managed-by": "keel"
		#data: {
			username: "admin"
			password: "s3cr3t"
		}
	} & {
		apiVersion: "v1"
		kind:       "Secret"
		metadata: {
			name: "example"
			labels: "prodigy9.co/app":         "cueinfra"
			annotations: "keel.sh/managed-by": "keel"
		}
		data: {
			username: "YWRtaW4="
			password: "czNjcjN0"
		}
	},

	// dockerconfig
	#Secret & {
		#name: "example"
		#type: "kubernetes.io/dockerconfigjson"
		#data: "ghcr.io": {
			username: "podman"
			password: "yeyeyey"
		}
	} & {
		apiVersion: "v1"
		kind:       "Secret"
		type:       "kubernetes.io/dockerconfigjson"
		metadata: name:            "example"
		data: ".dockerconfigjson": "eyJhdXRocyI6eyJnaGNyLmlvIjp7ImF1dGgiOiJjRzlrYldGdU9ubGxlV1Y1WlhrPSJ9fX0="
	},

	// tls
	#Secret & {
		#name: "example"
		#type: "kubernetes.io/tls"
		#data: {
			cert: """
				-----BEGIN CERTIFICATE-----
				MIIDFzCCAf+gAwIBAgIUFnZFlLOMuqFmVk7gbtqn63rO7oowDQYJKoZIhvcNAQEL
				BQAwGzEZMBcGA1UEAwwQdGVzdC5leGFtcGxlLmNvbTAeFw0yNTA4MjgxNDMzMTVa
				Fw0yNTA5MjcxNDMzMTVaMBsxGTAXBgNVBAMMEHRlc3QuZXhhbXBsZS5jb20wggEi
				MA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCxZHc4G5Jc1qtNzjmhqTgC3iN8
				dQLE3PqDhnhmyAj4t/UJk8vRJQwEY+56lmAfITGby7jQEEHWvmlU0Iul0Zns42u3
				+2ldQhJR8yspKUxxI2lKPdurODgHfF1AaYCOH0azkaQN+y/x0+RAU0Op//zIGrGv
				OX9DAb1GXNqdKREV2PTvE0r3Lcu6ospD4JUPL8+1UrSe1ALTzj7VxgPXHkqyq9Ib
				jsinV6HQ4B/HPC1ll6b6GX6fAf1pb6A2xo9/ge5jj2WOmoqXVQ5mxUNs1TPStAHr
				1DFkrTnBdgIbPhhbx8opGhueCeYfcZC2dNVpDNLSq2bS4E4vWUAayNp0KPqrAgMB
				AAGjUzBRMB0GA1UdDgQWBBSP6VLAjRYN5ljmUSFph6vCTC8KBzAfBgNVHSMEGDAW
				gBSP6VLAjRYN5ljmUSFph6vCTC8KBzAPBgNVHRMBAf8EBTADAQH/MA0GCSqGSIb3
				DQEBCwUAA4IBAQBts2W50ihLJzs8adqP9aEuHWHa7O7D4A163sQhOBVwCIaIGbeH
				YTm36pwJTi1XtbDITV+pcO2baUjvcNYDRliiL7fxbTXIkR+H88Op9UlRNKvIHZIu
				njoxaHKVYVfCnP2aQWu7QJYSB5zI8d7PYgbzyl06MNpEl4W4xG6U0F6HSeT06d2h
				HOSp9CwrRIRHtThZdWoexPh8+fm3HjJN2T1nnp1Rp7ng12juSxmBIqfYYszktlmA
				3nQ81ANSOfA8WSu5tnSJhfP0IFno+GIfztHw7AN1g5+qFI/iCipES0dVUdPHiaao
				eCsCcNmHZdZ01Twf2jjunTOhXhgVpem0dBzg
				-----END CERTIFICATE-----
				"""
			key: """
				-----BEGIN PRIVATE KEY-----
				MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCxZHc4G5Jc1qtN
				zjmhqTgC3iN8dQLE3PqDhnhmyAj4t/UJk8vRJQwEY+56lmAfITGby7jQEEHWvmlU
				0Iul0Zns42u3+2ldQhJR8yspKUxxI2lKPdurODgHfF1AaYCOH0azkaQN+y/x0+RA
				U0Op//zIGrGvOX9DAb1GXNqdKREV2PTvE0r3Lcu6ospD4JUPL8+1UrSe1ALTzj7V
				xgPXHkqyq9IbjsinV6HQ4B/HPC1ll6b6GX6fAf1pb6A2xo9/ge5jj2WOmoqXVQ5m
				xUNs1TPStAHr1DFkrTnBdgIbPhhbx8opGhueCeYfcZC2dNVpDNLSq2bS4E4vWUAa
				yNp0KPqrAgMBAAECggEANurUYcFfaXBn7hl3DA44MeMVd1U+OzXyND+wDJnG9UD2
				EjX4NlJSyxUo4jiln12GXyYNnBQ8Xb/rGf/KC9a84XJyia3Cq8VlqIswhHitmqUM
				1pgZ5oLsDZ05vVQsIVObbsIa2N03tZUUp7lfTETcvBJPieCx/kuOjjb20wrAqFNS
				Atf1hxgwo6A4pIQnmYIMVQ4EPJzdcTjcgMDAjHAWFhwqxj/gb8/IWJKmJCkljKY+
				lYwPQvp3nPoW91k1dMbSiG2FsKugKrpCfhSIhblHSSYMGLEHx+4r7Jlvmdbhxvkx
				3wUi6Vj5r3rhR97toGXcLhUQJq8t9u6oMPMnZeTA4QKBgQD2V4ufqRkncHT3lBCJ
				6IUYjjRYaSuOpoHJKQukukCs925ND9u1xOai20yPNYkOSb1TpmIQxSLfRkIQc+2O
				72EgSrwzZOW6H4TRMjdLfmDM5/EU0g6WHylGJJlCdsP+JnVB1i+dop5MfplNG6kb
				zAtJnOLDaNrXhPAPZZY3Y657mwKBgQC4WOVtKYscynbzn0k8H97Q2ozWPWQxBksp
				3CeWGSKtvaJsuedNYk5e/OhIjMM2dD4Dya8D+cW/rQeiMKT7Y9Lv/1ygTNexDuRf
				xf+IVmbQCsfoNVPKBUEUa+0pY0NCGDa5oYya2GHoyS0lbSR1eUd7J5xsTacTPKrJ
				ujCmz6wWMQKBgEg183TS8c+w1Gi6m3qBkXpYPRnpgl4niwX3pTUdb9YEFe47BtGq
				rVzx4ehc7hclIH2D2V1HHGjMxJLkGK/8lcEMh0ydeAXuNVXJXZIgsql+GBpdVO9G
				pSetlMt52wwGI/svmPehcrvDpJaI1DKUxn5GoeZcN0JT8rbgtX75Fm2fAoGAWAU6
				JpE7dxfFDDX2BdtBzH9N182gVTgoE2inDigaQtLVBw0MwAo8WWZwkpODcjC2m6Bl
				DITqQscfafXIELBtO2K2m2OVaVku+fvUMwjuNk+ve9RamY9Ar7uIlcZritd86c2V
				ESpYNYo5IDGowt6RnuAe9CdvquPAuGlKaZunE0ECgYATweXBfuQCMu7aAKREBCIm
				fFJFurVplqpVmxRFUIu9kOeOWSFlTlQ2T+mmrltrh5wMKqgiYb9hm7V/bS5T0i1b
				9oETeMW96MGkDPAhXKKPzOoA+vJ5PfRVqGrAyUcVOFDtJlcgTO8RVwiW4sUa7q7A
				jvjNToJkpueQvpucpRVGcA==
				-----END PRIVATE KEY-----
				"""
		}
	} & {
		apiVersion: "v1"
		kind:       "Secret"
		type:       "kubernetes.io/tls"
		metadata: name: "example"
		data: {
			"tls.crt": "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSURGekNDQWYrZ0F3SUJBZ0lVRm5aRmxMT011cUZtVms3Z2J0cW42M3JPN29vd0RRWUpLb1pJaHZjTkFRRUwKQlFBd0d6RVpNQmNHQTFVRUF3d1FkR1Z6ZEM1bGVHRnRjR3hsTG1OdmJUQWVGdzB5TlRBNE1qZ3hORE16TVRWYQpGdzB5TlRBNU1qY3hORE16TVRWYU1Cc3hHVEFYQmdOVkJBTU1FSFJsYzNRdVpYaGhiWEJzWlM1amIyMHdnZ0VpCk1BMEdDU3FHU0liM0RRRUJBUVVBQTRJQkR3QXdnZ0VLQW9JQkFRQ3haSGM0RzVKYzFxdE56am1ocVRnQzNpTjgKZFFMRTNQcURobmhteUFqNHQvVUprOHZSSlF3RVkrNTZsbUFmSVRHYnk3alFFRUhXdm1sVTBJdWwwWm5zNDJ1MworMmxkUWhKUjh5c3BLVXh4STJsS1BkdXJPRGdIZkYxQWFZQ09IMGF6a2FRTit5L3gwK1JBVTBPcC8veklHckd2Ck9YOURBYjFHWE5xZEtSRVYyUFR2RTByM0xjdTZvc3BENEpVUEw4KzFVclNlMUFMVHpqN1Z4Z1BYSGtxeXE5SWIKanNpblY2SFE0Qi9IUEMxbGw2YjZHWDZmQWYxcGI2QTJ4bzkvZ2U1amoyV09tb3FYVlE1bXhVTnMxVFBTdEFIcgoxREZrclRuQmRnSWJQaGhieDhvcEdodWVDZVlmY1pDMmROVnBETkxTcTJiUzRFNHZXVUFheU5wMEtQcXJBZ01CCkFBR2pVekJSTUIwR0ExVWREZ1FXQkJTUDZWTEFqUllONWxqbVVTRnBoNnZDVEM4S0J6QWZCZ05WSFNNRUdEQVcKZ0JTUDZWTEFqUllONWxqbVVTRnBoNnZDVEM4S0J6QVBCZ05WSFJNQkFmOEVCVEFEQVFIL01BMEdDU3FHU0liMwpEUUVCQ3dVQUE0SUJBUUJ0czJXNTBpaExKenM4YWRxUDlhRXVIV0hhN083RDRBMTYzc1FoT0JWd0NJYUlHYmVICllUbTM2cHdKVGkxWHRiRElUVitwY08yYmFVanZjTllEUmxpaUw3ZnhiVFhJa1IrSDg4T3A5VWxSTkt2SUhaSXUKbmpveGFIS1ZZVmZDblAyYVFXdTdRSllTQjV6SThkN1BZZ2J6eWwwNk1OcEVsNFc0eEc2VTBGNkhTZVQwNmQyaApIT1NwOUN3clJJUkh0VGhaZFdvZXhQaDgrZm0zSGpKTjJUMW5ucDFScDduZzEyanVTeG1CSXFmWVlzemt0bG1BCjNuUTgxQU5TT2ZBOFdTdTV0blNKaGZQMElGbm8rR0lmenRIdzdBTjFnNStxRkkvaUNpcEVTMGRWVWRQSGlhYW8KZUNzQ2NObUhaZFowMVR3ZjJqanVuVE9oWGhnVnBlbTBkQnpnCi0tLS0tRU5EIENFUlRJRklDQVRFLS0tLS0="
			"tls.key": "LS0tLS1CRUdJTiBQUklWQVRFIEtFWS0tLS0tCk1JSUV2QUlCQURBTkJna3Foa2lHOXcwQkFRRUZBQVNDQktZd2dnU2lBZ0VBQW9JQkFRQ3haSGM0RzVKYzFxdE4KemptaHFUZ0MzaU44ZFFMRTNQcURobmhteUFqNHQvVUprOHZSSlF3RVkrNTZsbUFmSVRHYnk3alFFRUhXdm1sVQowSXVsMFpuczQydTMrMmxkUWhKUjh5c3BLVXh4STJsS1BkdXJPRGdIZkYxQWFZQ09IMGF6a2FRTit5L3gwK1JBClUwT3AvL3pJR3JHdk9YOURBYjFHWE5xZEtSRVYyUFR2RTByM0xjdTZvc3BENEpVUEw4KzFVclNlMUFMVHpqN1YKeGdQWEhrcXlxOUlianNpblY2SFE0Qi9IUEMxbGw2YjZHWDZmQWYxcGI2QTJ4bzkvZ2U1amoyV09tb3FYVlE1bQp4VU5zMVRQU3RBSHIxREZrclRuQmRnSWJQaGhieDhvcEdodWVDZVlmY1pDMmROVnBETkxTcTJiUzRFNHZXVUFhCnlOcDBLUHFyQWdNQkFBRUNnZ0VBTnVyVVljRmZhWEJuN2hsM0RBNDRNZU1WZDFVK096WHlORCt3REpuRzlVRDIKRWpYNE5sSlN5eFVvNGppbG4xMkdYeVlObkJROFhiL3JHZi9LQzlhODRYSnlpYTNDcThWbHFJc3doSGl0bXFVTQoxcGdaNW9Mc0RaMDV2VlFzSVZPYmJzSWEyTjAzdFpVVXA3bGZURVRjdkJKUGllQ3gva3VPampiMjB3ckFxRk5TCkF0ZjFoeGd3bzZBNHBJUW5tWUlNVlE0RVBKemRjVGpjZ01EQWpIQVdGaHdxeGovZ2I4L0lXSkttSkNrbGpLWSsKbFl3UFF2cDNuUG9XOTFrMWRNYlNpRzJGc0t1Z0tycENmaFNJaGJsSFNTWU1HTEVIeCs0cjdKbHZtZGJoeHZreAozd1VpNlZqNXIzcmhSOTd0b0dYY0xoVVFKcTh0OXU2b01QTW5aZVRBNFFLQmdRRDJWNHVmcVJrbmNIVDNsQkNKCjZJVVlqalJZYVN1T3BvSEpLUXVrdWtDczkyNU5EOXUxeE9haTIweVBOWWtPU2IxVHBtSVF4U0xmUmtJUWMrMk8KNzJFZ1Nyd3paT1c2SDRUUk1qZExmbURNNS9FVTBnNldIeWxHSkpsQ2RzUCtKblZCMWkrZG9wNU1mcGxORzZrYgp6QXRKbk9MRGFOclhoUEFQWlpZM1k2NTdtd0tCZ1FDNFdPVnRLWXNjeW5iem4wazhIOTdRMm96V1BXUXhCa3NwCjNDZVdHU0t0dmFKc3VlZE5ZazVlL09oSWpNTTJkRDREeWE4RCtjVy9yUWVpTUtUN1k5THYvMXlnVE5leER1UmYKeGYrSVZtYlFDc2ZvTlZQS0JVRVVhKzBwWTBOQ0dEYTVvWXlhMkdIb3lTMGxiU1IxZVVkN0o1eHNUYWNUUEtySgp1akNtejZ3V01RS0JnRWcxODNUUzhjK3cxR2k2bTNxQmtYcFlQUm5wZ2w0bml3WDNwVFVkYjlZRUZlNDdCdEdxCnJWeng0ZWhjN2hjbElIMkQyVjFISEdqTXhKTGtHSy84bGNFTWgweWRlQVh1TlZYSlhaSWdzcWwrR0JwZFZPOUcKcFNldGxNdDUyd3dHSS9zdm1QZWhjcnZEcEphSTFES1V4bjVHb2VaY04wSlQ4cmJndFg3NUZtMmZBb0dBV0FVNgpKcEU3ZHhmRkREWDJCZHRCekg5TjE4MmdWVGdvRTJpbkRpZ2FRdExWQncwTXdBbzhXV1p3a3BPRGNqQzJtNkJsCkRJVHFRc2NmYWZYSUVMQnRPMksybTJPVmFWa3UrZnZVTXdqdU5rK3ZlOVJhbVk5QXI3dUlsY1pyaXRkODZjMlYKRVNwWU5ZbzVJREdvd3Q2Um51QWU5Q2R2cXVQQXVHbEthWnVuRTBFQ2dZQVR3ZVhCZnVRQ011N2FBS1JFQkNJbQpmRkpGdXJWcGxxcFZteFJGVUl1OWtPZU9XU0ZsVGxRMlQrbW1ybHRyaDV3TUtxZ2lZYjlobTdWL2JTNVQwaTFiCjlvRVRlTVc5Nk1Ha0RQQWhYS0tQek9vQSt2SjVQZlJWcUdyQXlVY1ZPRkR0SmxjZ1RPOFJWd2lXNHNVYTdxN0EKanZqTlRvSmtwdWVRdnB1Y3BSVkdjQT09Ci0tLS0tRU5EIFBSSVZBVEUgS0VZLS0tLS0="
		}
	},
]
