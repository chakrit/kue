package defs

import (
	"prodigy9.co/defs/attr"
	"prodigy9.co/defs/parts"
)

#Deployment: Self={
	parts.#PodController
	attr.#Ports

	#replicas?: int

	kind: "Deployment"
	if Self.#replicas != _|_ {
		spec: {
			replicas: Self.#replicas
			...
		}
		...
	}
}

tests: deployment: [

	{
		// vanilla
		#Expected: close({
			apiVersion: "apps/v1"
			kind:       "Deployment"
			metadata: {
				name:      "my-app"
				namespace: "my-ns"
			}
			spec: close({
				selector: close({matchLabels: close({
					"prodigy9.co/app":     "my-app"
					"prodigy9.co/part-of": "my-ns"
				})
				})
				revisionHistoryLimit: 2
				template: close({
					metadata: close({labels: close({
						"prodigy9.co/app":     "my-app"
						"prodigy9.co/part-of": "my-ns"
					})
					})
					spec: close({
						containers: [close({
							name:            "my-app"
							image:           "nginx:latest"
							imagePullPolicy: "Always"
						})]
					})
				})
			})
		})

		#Expected & #Deployment & {
			#name:  "my-app"
			#ns:    "my-ns"
			#image: "nginx:latest"
		}
	},

	{
		// full option
		#Expected: close({
			apiVersion: "apps/v1"
			kind:       "Deployment"
			metadata: {
				name:      "my-app"
				namespace: "my-ns"
				labels: "prodigy9.co/env":             "prod"
				annotations: "prodigy9.co/managed-by": "cueinfra"
			}
			spec: close({
				replicas: 3
				selector: close({matchLabels: close({
					"prodigy9.co/app":     "my-app"
					"prodigy9.co/part-of": "my-ns"
				})
				})
				revisionHistoryLimit: 2
				template: close({
					metadata: close({labels: close({
						"prodigy9.co/app":     "my-app"
						"prodigy9.co/part-of": "my-ns"
					})
					})
					spec: close({
						serviceAccountName: "my-service-account"
						imagePullSecrets: [close({name: "my-pull-secret"})]
						initContainers: [close({
							name:            "my-app-init"
							image:           "nginx:latest"
							imagePullPolicy: "Always"
							command: ["/bin/sh", "-c", "echo"]
							args: ["hello", "init"]
							envFrom: [close({secretRef: name: "my-env-secret"})]
						})]
						containers: [close({
							name:            "my-app"
							image:           "nginx:latest"
							imagePullPolicy: "Always"
							command: ["/bin/sh", "-c", "echo"]
							args: ["hello", "real app"]
							ports: [{
								name:          "port-8080"
								containerPort: 8080
								protocol:      "TCP"
							}]
							envFrom: [close({secretRef: name: "my-env-secret"})]
						})]
					})
				})
			})
		})

		#Expected & #Deployment & {
			#name: "my-app"
			#ns:   "my-ns"
			#labels: "prodigy9.co/env":             "prod"
			#annotations: "prodigy9.co/managed-by": "cueinfra"

			#image:    "nginx:latest"
			#replicas: 3

			#env_from:        "my-env-secret"
			#pull_secret:     "my-pull-secret"
			#service_account: "my-service-account"

			#command: ["/bin/sh", "-c", "echo"]
			#args: ["hello", "real app"]
			#init_command: ["/bin/sh", "-c", "echo"]
			#init_args: ["hello", "init"]

			#ports: [8080]
		}
	},

	{
		// no replicas
		#Expected: close({
			apiVersion: "apps/v1"
			kind:       "Deployment"
			metadata: {
				name:      "my-app"
				namespace: "my-ns"
			}
			spec: close({
				selector: close({matchLabels: close({
					"prodigy9.co/app":     "my-app"
					"prodigy9.co/part-of": "my-ns"
				})
				})
				revisionHistoryLimit: 2
				template: close({
					metadata: close({labels: close({
						"prodigy9.co/app":     "my-app"
						"prodigy9.co/part-of": "my-ns"
					})
					})
					spec: close({
						containers: [close({
							name:            "my-app"
							image:           "nginx:latest"
							imagePullPolicy: "Always"
						})]
					})
				})
			})
		})

		#Expected & #Deployment & {
			#name:  "my-app"
			#ns:    "my-ns"
			#image: "nginx:latest"
		}
	},

]
