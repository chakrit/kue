package defs

import (
	"prodigy9.co/defs/parts"
)

#PodDisruptionBudget: Self={
	parts.#Metadata

	#target: string

	#min_available?:   int | string
	#max_unavailable?: int | string

	apiVersion: "policy/v1"
	kind:       "PodDisruptionBudget"
	spec: {
		selector: matchLabels: {
			"prodigy9.co/app":     Self.#target
			"prodigy9.co/part-of": Self.#ns
		}
		if Self.#min_available != _|_ {
			minAvailable: Self.#min_available
		}
		if Self.#max_unavailable != _|_ {
			maxUnavailable: Self.#max_unavailable
		}
	}
}

tests: pod_disruption_budget: [

	{
		// minAvailable as int
		#Expected: close({
			apiVersion: "policy/v1"
			kind:       "PodDisruptionBudget"
			metadata: close({
				name:      "my-app-pdb"
				namespace: "my-ns"
			})
			spec: close({
				selector: close({matchLabels: close({
					"prodigy9.co/app":     "my-app"
					"prodigy9.co/part-of": "my-ns"
				})
				})
				minAvailable: 2
			})
		})

		#Expected & #PodDisruptionBudget & {
			#name:          "my-app-pdb"
			#ns:            "my-ns"
			#target:        "my-app"
			#min_available: 2
		}
	},

	{
		// maxUnavailable as int
		#Expected: close({
			apiVersion: "policy/v1"
			kind:       "PodDisruptionBudget"
			metadata: close({
				name:      "my-app-pdb"
				namespace: "my-ns"
			})
			spec: close({
				selector: close({matchLabels: close({
					"prodigy9.co/app":     "my-app"
					"prodigy9.co/part-of": "my-ns"
				})
				})
				maxUnavailable: 1
			})
		})

		#Expected & #PodDisruptionBudget & {
			#name:            "my-app-pdb"
			#ns:              "my-ns"
			#target:          "my-app"
			#max_unavailable: 1
		}
	},

	{
		// minAvailable as percentage string
		#Expected: close({
			apiVersion: "policy/v1"
			kind:       "PodDisruptionBudget"
			metadata: close({
				name:      "my-app-pdb"
				namespace: "my-ns"
			})
			spec: close({
				selector: close({matchLabels: close({
					"prodigy9.co/app":     "my-app"
					"prodigy9.co/part-of": "my-ns"
				})
				})
				minAvailable: "50%"
			})
		})

		#Expected & #PodDisruptionBudget & {
			#name:          "my-app-pdb"
			#ns:            "my-ns"
			#target:        "my-app"
			#min_available: "50%"
		}
	},

]
