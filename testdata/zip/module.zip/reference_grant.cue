package defs

import (
	"prodigy9.co/defs/parts"
)

// Maps a `kind` to its default API `group`. Kinds not listed must specify
// `group` explicitly.
_group_for_kind: {
	Gateway:   "gateway.networking.k8s.io"
	HTTPRoute: "gateway.networking.k8s.io"
	GRPCRoute: "gateway.networking.k8s.io"
	TCPRoute:  "gateway.networking.k8s.io"
	TLSRoute:  "gateway.networking.k8s.io"
	Service:   ""
	Secret:    ""
}

#ReferenceGrant: Self={
	parts.#Metadata

	#ns: string
	#from: [...{
		group?:    string
		kind:      string
		namespace: string
	}]
	#to: [...{
		group?: string
		kind:   string
		name?:  string
	}]

	apiVersion: "gateway.networking.k8s.io/v1"
	kind:       "ReferenceGrant"
	spec: {
		from: [
			for f in Self.#from {
				group:     *f.group | _group_for_kind[f.kind]
				kind:      f.kind
				namespace: f.namespace
			},
		]
		to: [
			for t in Self.#to {
				group: *t.group | _group_for_kind[t.kind]
				kind:  t.kind
				if t.name != _|_ {
					name: t.name
				}
			},
		]
	}
}

tests: reference_grant: [

	// HTTPRoute in app-ns → Gateway in gateway-ns (group defaulted)
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "ReferenceGrant"
			metadata: {
				name:      "allow-route"
				namespace: "gateway-ns"
			}
			spec: {
				from: [{
					group:     "gateway.networking.k8s.io"
					kind:      "HTTPRoute"
					namespace: "app-ns"
				}]
				to: [{
					group: "gateway.networking.k8s.io"
					kind:  "Gateway"
				}]
			}
		}

		#Expected & #ReferenceGrant & {
			#name: "allow-route"
			#ns:   "gateway-ns"
			#from: [{kind: "HTTPRoute", namespace: "app-ns"}]
			#to: [{kind: "Gateway"}]
		}
	},

	// Service-in-other-ns target — core group default (empty string)
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "ReferenceGrant"
			metadata: {
				name:      "allow-backend"
				namespace: "backend-ns"
			}
			spec: {
				from: [{
					group:     "gateway.networking.k8s.io"
					kind:      "HTTPRoute"
					namespace: "app-ns"
				}]
				to: [{
					group: ""
					kind:  "Service"
					name:  "my-service"
				}]
			}
		}

		#Expected & #ReferenceGrant & {
			#name: "allow-backend"
			#ns:   "backend-ns"
			#from: [{kind: "HTTPRoute", namespace: "app-ns"}]
			#to: [{kind: "Service", name: "my-service"}]
		}
	},

	// explicit group overrides default
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "ReferenceGrant"
			metadata: {
				name:      "custom-group"
				namespace: "target-ns"
			}
			spec: {
				from: [{
					group:     "custom.example.com"
					kind:      "HTTPRoute"
					namespace: "src-ns"
				}]
				to: [{
					group: "gateway.networking.k8s.io"
					kind:  "Gateway"
				}]
			}
		}

		#Expected & #ReferenceGrant & {
			#name: "custom-group"
			#ns:   "target-ns"
			#from: [{
				group:     "custom.example.com"
				kind:      "HTTPRoute"
				namespace: "src-ns"
			}]
			#to: [{kind: "Gateway"}]
		}
	},

]
