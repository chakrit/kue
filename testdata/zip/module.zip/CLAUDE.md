### Project Identity

- **CUE module:** `prodigy9.co/defs` — the PRODIGY9 K8S infrastructure definitions framework.
- **CUE version:** v0.15.4 (evalv3 only).
- **Architecture:** `attr/` → `parts/` → root defs → `packs/`. See the `p9-infra` skill for full reference.

### Always-load Skills

Load these at session start, regardless of trigger heuristics:

- `general-coding` — workflow + always-apply principles.
- `cue-coding` — CUE syntax/gotchas (every edit touches `.cue`).
- `p9-infra` — framework conventions (`attr`/`parts`/`defs`/`packs`).

### Linear Project

- **Project:** "Infrastructure Definitions" — use this exact name as the Linear lookup key. (`infra-defs` is the repo name, not a Linear slug.)
- **Team:** PRODIGY9 (`PROD9`)
- **URL:** https://linear.app/prodigy9/project/infrastructure-definitions-1bffd3d00cec
- Issues in this project serve as the task list for this repo.

### Commit Convention

- All commits in this repo use the `defs:` prefix (e.g. `defs: Add #NodeAffinity part`).

### Shell Scripts

- `./cue-fmt.sh` — format all `.cue` files (always run first).
- `./cue-check.sh` — validate/vet.
- `./cue-test.sh` — run inline `tests` blocks.
- `./cue.sh` — wrapper that sets `CUE_REGISTRY` env before running `cue`.
- **Workflow:** `./cue-fmt.sh && ./cue-check.sh && ./cue-test.sh`

### Communication Preferences

- Be very very terse, direct, concise, and short.
- Save token, and user time, be brief, to the point, and generally very very efficient.
- Do not offer extra help at the end of conversation.
- Avoid pleasantries, niceties, and small talk.
- If a question is asked, just answer directly and say nothing else.
- If a response isn't required, simply acknowledge and stop.

### CUE Pattern Notes

- **No package-self iteration.** CUE has no "self" / "package as value" — you cannot iterate over the package's own top-level struct from within a file in that package. Workaround for cross-file collection (e.g., `apps/gateway.cue` discovering all peer apps): each file writes into a shared struct field (`#apps: <name>: "<ns>"`) that merges across files; the consumer iterates that struct. Tested 2026-04-26.
- Hidden fields (`_name`) and definitions (`#name`) both merge across files in the same package — they are package-scoped, not file-scoped. Only `let` bindings are file-scoped.
- Inside an embedded struct, identifiers shadow package-level fields with the same name. Use `let _alias = <name>` or quoted keys (`"<name>": ...`) to avoid silent cycle/`_` resolution.
- **`[...T]` without default is the right contract for "list input" fields.** A for-comprehension over an unset `[...T]` iterates zero times (silently produces empty); a direct assignment of an unset `[...T]` stays incomplete and `cue eval --concrete` errors. Net effect: list inputs gracefully default to "no items" when iterated but stay strictly required when consumed scalar-wise. Don't add `| *[]` unless you specifically want to allow direct scalar assignment to default to empty. Tested 2026-04-27.
- **Mixin design (v0.3).** Shipped 2026-05-02 (commit `b39fa85`). Spec at `spec/mixins.md`. Helper is `parts.#Mixin` (definition, with trailing `...` at the outer struct to stay open against closed targets like `defs.#Gateway`). Dispatch is **disjunction** — `listShape | structShape | error("...")`. The third branch surfaces a clear message when the target has neither `#components` nor a root `kind`, instead of an "empty disjunction" wall. Authoring: embed `#Mixin`, populate `#additions: [string]: {#kind, #patch}` with **scoped keys** (`<mixin>_<kind>` — e.g. `keel_dep`, `resources_dep`; unscoped `deploy:` collides when composing two mixins on the same kind). `_patch` guards live at the **field emission site**, not wrapping the outer block — typoed inputs would otherwise silently no-op. Every nested level of `_patch` needs trailing `...`. Defs stay pure-struct K8s wrappers (no `#components` publishing). Packs stay list-shape (top-level emit). Receipts in `spec/decisions/0001-mixin-design-v0.3.md`.
- **Tests for kind-gated mixins.** When asserting mixin output via `close({...})`, do NOT compose with `parts.#PodController` in the test — PodController adds `apiVersion`, `metadata`, `spec.{selector, revisionHistoryLimit}`, container `image`/`imagePullPolicy` that violate close(). Use a minimal stub instead: `{kind: "Deployment", spec: template: spec: containers: [{name: "test"}]} & #PodMounts & {...} & close({...})`. The mixin's struct-shape branch fires on `kind:` regardless. Tested 2026-05-02.
- **Pack output constraints.** Under v0.3 disjunction-dispatch mixins, packs that conditionally add to `#components` MUST emit via list comprehension: `[for _, c in Self.#components {c}]`. The hand-listed form `[Self.#components.X, Self.#components.Y, if cond {Self.#components.Z}]` paired with a conditional `if cond { #components: <name>: ... }` add trips a closure leak — the mixin's pattern constraint evaluates against a stale view of `#components` and retroactively closes the other entries. Isolated 2026-05-02 in `_probe/repro.cue` variants V1-V8; fix shipped in commit `b39fa85`. The earlier note (2026-04-27) claiming `[for x in ...]` breaks mixin routing was an if-branch-dispatch artifact; under disjunction, comprehension is the recommended form. Static packs (no conditional `#components` adds) can still hand-list. CUE 0.16.1 panics on the existing parts package — do not upgrade.
- **CUE error messages are unreliable.** evalv3 errors very often point at the WRONG location. A subtle upstream mistake (missing `...` at a nested level, list-vs-struct shape on a trailing `&`, alias scope collision, hidden vs `#`-def mismatch) pushes unification into a branch we didn't intend, and CUE reports the failure of *that* branch. Concrete examples seen 2026-05-02: (a) a `_patch` written with path-shorthand `spec: template: spec: x: ..., ...` puts `...` only at the top level — leaving intermediate levels closed — caused CUE to report "field not allowed" on `parts.#PodController.spec.selector` and `revisionHistoryLimit`. The actual fix was adding `...` at every intermediate level of `_patch`. The error pointed at PodController; the bug was several layers away. (b) This misleading error caused the v0.3 implementation to abandon the locked disjunction design and switch to if-branches — both designs actually work fine with correctly-structured `_patch`. **Rules:** (1) treat error locations as "something is wrong somewhere in the resolution chain that flows through this point," not "the bug is here." (2) When an error names fields inside a def you didn't write, suspect closure leakage from your own struct upstream. (3) Before accepting "approach X is broken," isolate the variable: strip surrounding code to bare minimum, re-test, and revisit decision-record claims. (4) Prefer disjunction-based dispatch over if-branch dispatch — disjunction collapses via unification (deterministic) while if-branches depend on phased evaluation order (fragile, especially for `if X != _|_` checks gating pattern constraints with nested for-comprehensions). Confirmed shipped 2026-05-02 in v0.3 mixin (`parts.#Mixin`).
- **Let-bound aggregates referencing `Self.#x != _|_` cycle under disjunction dispatch.** A pattern like `let _has_mounts = Self.#mount_pvc != _|_ || Self.#mount_config != _|_ || ...` worked under v0.3 if-branch dispatch but cycles under disjunction (saw it in `parts.#PodMounts` 2026-05-02). Inline the disjunctive presence check at each emission site instead. The cycle surfaces as `cycle with field: <let-name>` at the inner `if` reference, not at the let definition. Fixed in commit `b39fa85`.
- **Strategic `error()` as a disjunction branch.** Add a third branch `listShape | structShape | error("clear message")` so when neither shape unifies, the user sees a clear message instead of CUE's "empty disjunction" wall. Shipped in `parts.#Mixin`. **Avoid post-dispatch unmatched-input checks** (`for ak, add in #additions { if !matched { error() } }`) — multi-kind mixins (e.g. `#UseCertManager` covering both Gateway and Ingress) legitimately have additions that don't match every target. The check rejects valid compositions. Tests should catch silent no-ops, not the helper.

### Gateway API Notes

- **cert-manager gateway-shim** auto-issues a Certificate per Gateway listener only when the listener has all of: non-empty `hostname`, `tls.mode: "Terminate"`, `tls.certificateRefs[].name`. Hostname-less HTTPS listeners get no cert. `defs.#Gateway` therefore fans out one HTTPS listener per host (from `attr.#Hosts`) — see `7894af8`.
- **Listener `name`** is constrained to DNS-1123 label (no dots), unlike `hostname` which is an FQDN. `defs.#Gateway` derives listener names via `strings.Replace(host, ".", "-", -1)`.
- **cert-manager ≥1.15** requires `config.enableGatewayAPI: true` at install time. This is a deployment concern, not a CUE concern.

### Task Workflow

When working through a task list:

1. Work on **one task at a time**, starting from the first unblocked task.
2. After completing the task, run a **self-audit loop** — review the output for correctness,
   completeness, and consistency. Repeat until satisfactory.
3. Prepare a **compaction note** summarizing: what was done, what files changed, current task
   list state, and context needed for the next task.
4. **Wait for user to compact** before starting the next task.

### RTK (Rust Token Killer)

Always prefix shell commands with `rtk` (including each command in `&&` chains).
Full reference and command catalogue: [RTK.md](RTK.md).
