package defs

import (
	"prodigy9.co/defs/attr"
	"prodigy9.co/defs/parts"
)

#CronJob: Self={
	parts.#Metadata
	attr.#Workload

	#schedule: string

	#concurrency?: "Allow" | "Forbid" | "Replace"
	#restart:      "OnFailure" | "Never" | *"OnFailure"

	let _container = {
		name:            Self.#name
		image:           Self.#image
		imagePullPolicy: "Always"
		if Self.#env_from != _|_ {
			envFrom: [{secretRef: name: Self.#env_from}]
		}
		if Self.#command != _|_ {
			command: Self.#command
		}
		if Self.#args != _|_ {
			args: Self.#args
		}
	}

	apiVersion: "batch/v1"
	kind:       "CronJob"
	spec: {
		schedule: Self.#schedule
		if Self.#concurrency != _|_ {
			concurrencyPolicy: Self.#concurrency
		}
		jobTemplate: spec: template: spec: {
			restartPolicy: Self.#restart
			if Self.#service_account != _|_ {
				serviceAccountName: Self.#service_account
			}
			if Self.#pull_secret != _|_ {
				imagePullSecrets: [{name: Self.#pull_secret}]
			}
			containers: [_container]
		}
	}
}

tests: cron_job: [

	{
		// vanilla
		#Expected: close({
			apiVersion: "batch/v1"
			kind:       "CronJob"
			metadata: close({
				name:      "my-job"
				namespace: "my-ns"
			})
			spec: close({
				schedule: "0 * * * *"
				jobTemplate: close({spec: close({template: close({spec: close({
					restartPolicy: "OnFailure"
					containers: [close({
						name:            "my-job"
						image:           "nginx:latest"
						imagePullPolicy: "Always"
					})]
				})
				})
				})
				})
			})
		})

		#Expected & #CronJob & {
			#name:     "my-job"
			#ns:       "my-ns"
			#image:    "nginx:latest"
			#schedule: "0 * * * *"
		}
	},

	{
		// full options
		#Expected: close({
			apiVersion: "batch/v1"
			kind:       "CronJob"
			metadata: close({
				name:      "my-job"
				namespace: "my-ns"
			})
			spec: close({
				schedule:          "*/5 * * * *"
				concurrencyPolicy: "Forbid"
				jobTemplate: close({spec: close({template: close({spec: close({
					restartPolicy:      "Never"
					serviceAccountName: "my-sa"
					imagePullSecrets: [close({name: "my-pull-secret"})]
					containers: [close({
						name:            "my-job"
						image:           "nginx:latest"
						imagePullPolicy: "Always"
						command: ["/bin/sh", "-c"]
						args: ["echo hello"]
						envFrom: [close({secretRef: name: "my-env"})]
					})]
				})
				})
				})
				})
			})
		})

		#Expected & #CronJob & {
			#name:            "my-job"
			#ns:              "my-ns"
			#image:           "nginx:latest"
			#schedule:        "*/5 * * * *"
			#concurrency:     "Forbid"
			#restart:         "Never"
			#service_account: "my-sa"
			#pull_secret:     "my-pull-secret"
			#env_from:        "my-env"
			#command: ["/bin/sh", "-c"]
			#args: ["echo hello"]
		}
	},

]
