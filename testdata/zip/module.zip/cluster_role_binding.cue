package defs

import (
	"prodigy9.co/defs/parts"
)

#ClusterRoleBinding: Self={
	parts.#Metadata

	#role: #ClusterRole | string

	#service_account:    #ServiceAccount | string
	#service_account_ns: string | *Self.#ns

	let sa = string & (Self.#service_account | Self.#service_account.#name)
	if Self.#service_account.#ns != _|_ {
		#service_account_ns: Self.#service_account.#ns
	}
	let role = string & (Self.#role | Self.#role.#name)

	apiVersion: "rbac.authorization.k8s.io/v1"
	kind:       "ClusterRoleBinding"
	subjects: [
		{
			kind:      "ServiceAccount"
			name:      sa
			namespace: Self.#service_account_ns
		},
	]
	roleRef: {
		kind:     "ClusterRole"
		name:     role
		apiGroup: "rbac.authorization.k8s.io"
	}
}

tests: cluster_role_binding: [
	// basic with role and service account as strings
	#ClusterRoleBinding & {
		#name:               "example-binding"
		#ns:                 "my-ns"
		#role:               "example-role"
		#service_account:    "example-sa"
		#service_account_ns: "sa-ns"
	} & close({
		apiVersion: "rbac.authorization.k8s.io/v1"
		kind:       "ClusterRoleBinding"
		metadata: close({name: "example-binding", namespace: "my-ns"})
		subjects: [{
			kind:      "ServiceAccount"
			name:      "example-sa"
			namespace: "sa-ns"
		}]
		roleRef: {
			kind:     "ClusterRole"
			name:     "example-role"
			apiGroup: "rbac.authorization.k8s.io"
		}
	}),

	// default sa ns to binding ns
	#ClusterRoleBinding & {
		#name:            "example-binding"
		#ns:              "my-ns"
		#role:            "example-role"
		#service_account: "example-sa"
	} & {
		subjects: [{
			kind:      "ServiceAccount"
			name:      "example-sa"
			namespace: "my-ns"
		}]
		roleRef: {
			kind:     "ClusterRole"
			name:     "example-role"
			apiGroup: "rbac.authorization.k8s.io"
		}
	},

	// with role and service account as refs
	#ClusterRoleBinding & {
		#name: "example-binding"
		#ns:   "my-ns"
		#role: #ClusterRole & {#name: "example-role"}
		#service_account: #ServiceAccount & {#name: "example-sa", #ns: "sa-ns"}
	} & close({
		apiVersion: "rbac.authorization.k8s.io/v1"
		kind:       "ClusterRoleBinding"
		metadata: close({name: "example-binding", namespace: "my-ns"})
		subjects: [{
			kind:      "ServiceAccount"
			name:      "example-sa"
			namespace: "sa-ns"
		}]
		roleRef: {
			kind:     "ClusterRole"
			name:     "example-role"
			apiGroup: "rbac.authorization.k8s.io"
		}
	}),

	// with role as ref and service account as string, default sa ns to binding ns
	#ClusterRoleBinding & {
		#name: "example-binding"
		#ns:   "my-ns"
		#role: #ClusterRole & {#name: "example-role"}
		#service_account: "example-sa"
	} & close({
		apiVersion: "rbac.authorization.k8s.io/v1"
		kind:       "ClusterRoleBinding"
		metadata: close({name: "example-binding", namespace: "my-ns"})
		subjects: [{
			kind:      "ServiceAccount"
			name:      "example-sa"
			namespace: "my-ns"
		}]
		roleRef: {
			kind:     "ClusterRole"
			name:     "example-role"
			apiGroup: "rbac.authorization.k8s.io"
		}
	}),
]
