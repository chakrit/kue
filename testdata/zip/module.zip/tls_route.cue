package defs

import (
	"strings"

	"prodigy9.co/defs/attr"
	"prodigy9.co/defs/parts"
)

#TLSRoute: Self={
	parts.#Metadata
	attr.#Hosts
	attr.#ServiceRef

	#gateway_name: string
	#gateway_ns?:  string

	apiVersion: "gateway.networking.k8s.io/v1"
	kind:       "TLSRoute"

	spec: {
		parentRefs: [{
			name:        Self.#gateway_name
			sectionName: "tls-\(strings.Replace(Self.#hosts[0], ".", "-", -1))"
			if Self.#gateway_ns != _|_ {
				namespace: Self.#gateway_ns
			}
		}]
		hostnames: Self.#hosts
		rules: [{
			backendRefs: [{
				name: Self.#service_name
				port: Self.#service_port
			}]
		}]
	}
}

tests: tls_route: [

	// basic
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "TLSRoute"
			metadata: {
				name:      "argocd-tls"
				namespace: "argocd-ns"
			}
			spec: {
				parentRefs: [{
					name:        "my-gateway"
					sectionName: "tls-argocd-example-com"
				}]
				hostnames: ["argocd.example.com"]
				rules: [{
					backendRefs: [{
						name: "argocd-server"
						port: 443
					}]
				}]
			}
		}

		#Expected & #TLSRoute & {
			#name:         "argocd-tls"
			#ns:           "argocd-ns"
			#gateway_name: "my-gateway"
			#host:         "argocd.example.com"
			#service_name: "argocd-server"
			#service_port: 443
		}
	},

	// cross-namespace gateway ref
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "TLSRoute"
			metadata: {
				name:      "app-tls"
				namespace: "app-ns"
			}
			spec: {
				parentRefs: [{
					name:        "shared-gateway"
					sectionName: "tls-app-example-com"
					namespace:   "infra"
				}]
				hostnames: ["app.example.com"]
				rules: [{
					backendRefs: [{
						name: "app-svc"
						port: 8443
					}]
				}]
			}
		}

		#Expected & #TLSRoute & {
			#name:         "app-tls"
			#ns:           "app-ns"
			#gateway_name: "shared-gateway"
			#gateway_ns:   "infra"
			#host:         "app.example.com"
			#service_name: "app-svc"
			#service_port: 8443
		}
	},

]
