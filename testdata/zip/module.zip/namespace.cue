package defs

import (
	"prodigy9.co/defs/parts"
)

#Namespace: {
	parts.#Metadata

	apiVersion: "v1"
	kind:       "Namespace"
}

tests: namespace: [
	// basic
	#Namespace & {#name: "example"} & close({
		apiVersion: "v1"
		kind:       "Namespace"
		metadata: close({// prevent labels/annotations from being added
			name: "example"
		})
	}),

	// with labels
	#Namespace & {
		#name: "example"
		#labels: "prodigy9.co/app":         "cueinfra"
		#annotations: "keel.sh/managed-by": "keel"
	} & close({
		apiVersion: "v1"
		kind:       "Namespace"
		metadata: close({
			name: "example"
			labels: "prodigy9.co/app":         "cueinfra"
			annotations: "keel.sh/managed-by": "keel"
		})
	}),
]
