package defs

import (
	"prodigy9.co/defs/parts"
)

#ConfigMap: {
	parts.#Metadata

	#data: [string]: string

	apiVersion: "v1"
	kind:       "ConfigMap"
	data:       #data
}

tests: config_map: [

	// basic
	#ConfigMap & {
		#name: "my-config"
		#ns:   "my-ns"
		#data: key1: "value1"
	} & close({
		apiVersion: "v1"
		kind:       "ConfigMap"
		metadata: close({
			name:      "my-config"
			namespace: "my-ns"
		})
		data: close({
			key1: "value1"
		})
	}),

	// with labels and annotations
	#ConfigMap & {
		#name: "my-config"
		#ns:   "my-ns"
		#labels: "prodigy9.co/app":         "cueinfra"
		#annotations: "keel.sh/managed-by": "keel"
		#data: key1:                        "value1"
	} & close({
		apiVersion: "v1"
		kind:       "ConfigMap"
		metadata: close({
			name:      "my-config"
			namespace: "my-ns"
			labels: close({"prodigy9.co/app": "cueinfra"})
			annotations: close({"keel.sh/managed-by": "keel"})
		})
		data: close({
			key1: "value1"
		})
	}),

]
