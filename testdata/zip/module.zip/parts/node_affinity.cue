package parts

import "strings"

#NodeAffinity: Self={
	#Mixin
	#affinity?: string
	#affinities: [...string]

	if Self.#affinity != _|_ {
		#affinities: [Self.#affinity]
	}

	#required: bool | *true
	#weight:   int | *100

	// operator=In matches "value is one of the listed values". Parsing
	// "key=value" maps to a single-element values list — equivalent to
	// "node label key has value v". Other operators (NotIn/Exists/etc.) would
	// need a richer input shape.
	let #parseAffinity = {
		_affinity: string
		let _kv = strings.Split(_affinity, "=")

		key:      _kv[0]
		operator: "In"
		values: [_kv[1]]
	}

	let _expressions = [
		for a in Self.#affinities {
			(#parseAffinity & {_affinity: a})
		},
	]

	let _patch = {
		spec: {
			template: {
				spec: {
					if len(Self.#affinities) > 0 {
						affinity: nodeAffinity: {
							if Self.#required {
								requiredDuringSchedulingIgnoredDuringExecution: nodeSelectorTerms: [{
									matchExpressions: _expressions
								}]
							}
							if !Self.#required {
								preferredDuringSchedulingIgnoredDuringExecution: [{
									weight: Self.#weight
									preference: matchExpressions: _expressions
								}]
							}
						}
					}
					...
				}
				...
			}
			...
		}
		...
	}

	#additions: affinity_dep: {#kind: "Deployment", #patch: _patch}
	#additions: affinity_ss: {#kind: "StatefulSet", #patch: _patch}
	#additions: affinity_ds: {#kind: "DaemonSet", #patch: _patch}
}

tests: node_affinity: [

	// required affinity, single label, struct-shape via #PodController
	#PodController & #NodeAffinity & {
		#name:     "test-app"
		#ns:       "test-ns"
		#image:    "nginx:latest"
		#affinity: "node-type=compute"

		kind: "Deployment"
	} & {
		spec: template: spec: {
			affinity: nodeAffinity: requiredDuringSchedulingIgnoredDuringExecution: nodeSelectorTerms: [{
				matchExpressions: [{
					key:      "node-type"
					operator: "In"
					values: ["compute"]
				}]
			}]
			...
		}
		...
	},

	// required affinity, multiple labels
	#PodController & #NodeAffinity & {
		#name:  "test-app"
		#ns:    "test-ns"
		#image: "nginx:latest"
		#affinities: ["node-type=compute", "zone=us-east-1a"]

		kind: "Deployment"
	} & {
		spec: template: spec: {
			affinity: nodeAffinity: requiredDuringSchedulingIgnoredDuringExecution: nodeSelectorTerms: [{
				matchExpressions: [{
					key:      "node-type"
					operator: "In"
					values: ["compute"]
				}, {
					key:      "zone"
					operator: "In"
					values: ["us-east-1a"]
				}]
			}]
			...
		}
		...
	},

	// preferred affinity (default weight 100)
	#PodController & #NodeAffinity & {
		#name:     "test-app"
		#ns:       "test-ns"
		#image:    "nginx:latest"
		#affinity: "node-type=compute"
		#required: false

		kind: "Deployment"
	} & {
		spec: template: spec: {
			affinity: nodeAffinity: preferredDuringSchedulingIgnoredDuringExecution: [{
				weight: 100
				preference: matchExpressions: [{
					key:      "node-type"
					operator: "In"
					values: ["compute"]
				}]
			}]
			...
		}
		...
	},

	// preferred affinity with custom weight
	#PodController & #NodeAffinity & {
		#name:     "test-app"
		#ns:       "test-ns"
		#image:    "nginx:latest"
		#affinity: "node-type=compute"
		#required: false
		#weight:   50

		kind: "Deployment"
	} & {
		spec: template: spec: {
			affinity: nodeAffinity: preferredDuringSchedulingIgnoredDuringExecution: [{
				weight: 50
				preference: matchExpressions: [{
					key:      "node-type"
					operator: "In"
					values: ["compute"]
				}]
			}]
			...
		}
		...
	},

	// list-shape via minimal pack fixture (defined below)
	_packAffinity & #NodeAffinity & {
		#affinity: "node-type=compute"
		[...]
	} & [
		{kind: "Secret", metadata: name: "myapp-env"},
		{
			kind: "Deployment"
			metadata: name: "myapp"
			spec: template: spec: {
				affinity: nodeAffinity: requiredDuringSchedulingIgnoredDuringExecution: nodeSelectorTerms: [{
					matchExpressions: [{
						key:      "node-type"
						operator: "In"
						values: ["compute"]
					}]
				}]
				...
			}
		},
	],
]

_packAffinity: Self={
	#components: env: {
		kind: "Secret"
		metadata: name: "myapp-env"
	}
	#components: deploy: {
		kind: "Deployment"
		metadata: name: "myapp"
		spec: template: spec: {
			containers: [{
				name: "myapp"
				...
			}]
			...
		}
		...
	}

	[Self.#components.env, Self.#components.deploy]
}
