package parts

#UseCertManager: Self={
	#Mixin
	#cluster_issuer: string | *"cluster-issuer-main"

	let _patch = {
		metadata: {
			annotations: {
				"cert-manager.io/cluster-issuer": Self.#cluster_issuer
				...
			}
			...
		}
		...
	}

	#additions: cert_gw: {#kind: "Gateway", #patch: _patch}
	#additions: cert_ing: {#kind: "Ingress", #patch: _patch}
}

tests: use_cert_manager: [

	// Struct-shape on a Gateway-like def with custom issuer.
	{
		kind:       "Gateway"
		apiVersion: "gateway.networking.k8s.io/v1"
		metadata: {
			name:      "my-gateway"
			namespace: "my-ns"
			...
		}
		...
	} & #UseCertManager & {
		#cluster_issuer: "letsencrypt-prod"
	} & {
		kind:       "Gateway"
		apiVersion: "gateway.networking.k8s.io/v1"
		metadata: {
			name:      "my-gateway"
			namespace: "my-ns"
			annotations: "cert-manager.io/cluster-issuer": "letsencrypt-prod"
		}
	},

	// Struct-shape with default issuer.
	{
		kind: "Ingress"
		metadata: {
			name:      "my-ingress"
			namespace: "my-ns"
			...
		}
		...
	} & #UseCertManager & {
		metadata: annotations: "cert-manager.io/cluster-issuer": "cluster-issuer-main"
	},

	// List-shape pack with one Gateway and one HTTPRoute component.
	_packCertManager & #UseCertManager & {
		#cluster_issuer: "letsencrypt-prod"
		[...]
	} & [
		{
			kind: "Gateway"
			metadata: {
				name:      "g"
				namespace: "ns"
				annotations: "cert-manager.io/cluster-issuer": "letsencrypt-prod"
			}
		},
		{
			kind: "HTTPRoute"
			metadata: {
				name: "r"
				_
			}
		},
	],
]

_packCertManager: Self={
	#components: gw: {
		kind: "Gateway"
		metadata: {
			name:      "g"
			namespace: "ns"
			...
		}
		...
	}
	#components: route: {
		kind: "HTTPRoute"
		metadata: {
			name:      "r"
			namespace: "ns"
			...
		}
		...
	}

	[Self.#components.gw, Self.#components.route]
}
