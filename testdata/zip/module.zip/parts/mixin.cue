package parts

// Polymorphic mixin helper. See spec/mixins.md for the locked design.
//
// Authors embed #Mixin and populate #additions with kind-scoped patches.
// Callers compose via & on either a raw def (struct-shape) or a pack
// publishing #components + top-level list emit (list-shape). Shape
// dispatch via disjunction: CUE picks the matching branch; the third
// branch surfaces a clear error when neither shape fits.
#Mixin: Self={
	#additions: [string]: {
		#kind:  string
		#patch: _
	}

	let _patch = {
		kind: string
		for _, add in Self.#additions {
			if kind == add.#kind {
				add.#patch
			}
		}
		...
	}

	let listShape = {
		#components: [string]: _patch
		[...]
	}

	let structShape = {
		_patch
		...
	}

	listShape | structShape | error("#Mixin: target must have #components (pack lists) or kind: string")
	...
}
