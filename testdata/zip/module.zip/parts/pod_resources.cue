package parts

// requests-only by design: CPU limits cause throttling under burst, memory limits
// must be tuned per-app to avoid OOMKill. Reservations land in scheduler accounting
// without imposing runtime caps.
#PodResources: Self={
	#Mixin
	#reserved_cpu?: string
	#reserved_mem?: string

	let _patch = {
		spec: {
			template: {
				spec: {
					containers: [{
						if Self.#reserved_cpu != _|_ || Self.#reserved_mem != _|_ {
							resources: requests: {
								if Self.#reserved_cpu != _|_ {cpu: Self.#reserved_cpu}
								if Self.#reserved_mem != _|_ {memory: Self.#reserved_mem}
							}
						}
						...
					}]
					initContainers?: [{
						if Self.#reserved_cpu != _|_ || Self.#reserved_mem != _|_ {
							resources: requests: {
								if Self.#reserved_cpu != _|_ {cpu: Self.#reserved_cpu}
								if Self.#reserved_mem != _|_ {memory: Self.#reserved_mem}
							}
						}
						...
					}]
					...
				}
				...
			}
			...
		}
		...
	}

	#additions: resources_dep: {#kind: "Deployment", #patch: _patch}
	#additions: resources_ss: {#kind: "StatefulSet", #patch: _patch}
	#additions: resources_ds: {#kind: "DaemonSet", #patch: _patch}
}

tests: pod_resources: [

	// Test 1: Struct-shape via #PodController with Deployment kind
	#PodController & #PodResources & {
		#name:         "test-app"
		#ns:           "test-ns"
		#image:        "nginx:latest"
		#reserved_cpu: "100m"
		#reserved_mem: "128Mi"
		kind:          "Deployment"
	} & {
		spec: template: spec: {
			containers: [{
				resources: requests: {
					cpu:    "100m"
					memory: "128Mi"
				}
				...
			}]
			...
		}
		...
	},

	// Test 2: List-shape via inline pack with #components pattern
	_packResources & #PodResources & {
		#reserved_cpu: "150m"
		#reserved_mem: "256Mi"
		[...]
	} & [
		{
			kind: "Secret"
			...
		},
		{
			kind: "Deployment"
			spec: template: spec: {
				containers: [{
					resources: requests: {
						cpu:    "150m"
						memory: "256Mi"
					}
					...
				}]
				...
			}
			...
		},
	],

	// Test 3: CPU only
	#PodController & #PodResources & {
		#name:         "test-cpu"
		#ns:           "test-ns"
		#image:        "nginx:latest"
		#reserved_cpu: "200m"
		kind:          "Deployment"
	} & {
		spec: template: spec: {
			containers: [{
				resources: requests: cpu: "200m"
				...
			}]
			...
		}
		...
	},

	// Test 4: Memory only
	#PodController & #PodResources & {
		#name:         "test-mem"
		#ns:           "test-ns"
		#image:        "nginx:latest"
		#reserved_mem: "512Mi"
		kind:          "Deployment"
	} & {
		spec: template: spec: {
			containers: [{
				resources: requests: memory: "512Mi"
				...
			}]
			...
		}
		...
	},

]

_packResources: Self={
	#components: env: {
		kind: "Secret"
		metadata: name: "app-env"
		data: VAR:      "value"
	}
	#components: deploy: {
		kind: "Deployment"
		metadata: name: "app"
		spec: template: spec: {
			containers: [{
				name:  "app"
				image: "nginx:latest"
				...
			}]
			...
		}
		...
	}

	[Self.#components.env, Self.#components.deploy]
}
