package parts

import "strings"

#PodMounts: Self={
	#Mixin
	#mount_pvc?: [string]:      string
	#mount_config?: [string]:   string
	#mount_secret?: [string]:   string
	#mount_hostpath?: [string]: string

	// `string &` constrains the struct to scalar; trailing `string` at use sites collapses it.
	let _#NameOf = string & {
		#hostPath: string

		_1: strings.TrimPrefix(#hostPath, "/")
		strings.Replace(_1, "/", "-", -1)
	}

	let _volumes = [
		if Self.#mount_pvc != _|_ {
			for pvc, _ in Self.#mount_pvc {
				name: pvc
				// readOnly: false — PVCs back stateful workloads; writable is the point.
				persistentVolumeClaim: {
					claimName: pvc
					readOnly:  false
				}
			}
		},
		if Self.#mount_config != _|_ {
			for config, _ in Self.#mount_config {
				name: config
				configMap: name: config
			}
		},
		if Self.#mount_secret != _|_ {
			for sec, _ in Self.#mount_secret {
				name: sec
				secret: secretName: sec
			}
		},
		if Self.#mount_hostpath != _|_ {
			for hp, _ in Self.#mount_hostpath {
				name: _#NameOf & {#hostPath: hp, string}
				// type: "Directory" — k8s hostPath bind-mounts a directory; file-shaped
				// mounts need type "File" + a different volumeMount layout we don't model.
				hostPath: {
					path: hp
					type: "Directory"
				}
			}
		},
	]

	let _mounts = [
		if Self.#mount_pvc != _|_ {
			for pvc, path in Self.#mount_pvc {
				name:      pvc
				mountPath: path
			}
		},
		if Self.#mount_config != _|_ {
			for config, path in Self.#mount_config {
				name:      config
				mountPath: path
			}
		},
		if Self.#mount_secret != _|_ {
			for secret, path in Self.#mount_secret {
				name:      secret
				mountPath: path
			}
		},
		if Self.#mount_hostpath != _|_ {
			for hp, path in Self.#mount_hostpath {
				name: _#NameOf & {#hostPath: hp, string}
				mountPath: path
				// readOnly: true — host fs leaks through hostPath; default to read-only to
				// blunt blast radius. Workloads needing writes should use a PVC.
				readOnly: true
			}
		},
	]

	let _patch = {
		spec: {
			template: {
				spec: {
					if Self.#mount_pvc != _|_ || Self.#mount_config != _|_ || Self.#mount_secret != _|_ || Self.#mount_hostpath != _|_ {
						volumes: _volumes
					}
					containers: [{
						if Self.#mount_pvc != _|_ || Self.#mount_config != _|_ || Self.#mount_secret != _|_ || Self.#mount_hostpath != _|_ {
							volumeMounts: _mounts
						}
						...
					}]
					initContainers?: [{
						if Self.#mount_pvc != _|_ || Self.#mount_config != _|_ || Self.#mount_secret != _|_ || Self.#mount_hostpath != _|_ {
							volumeMounts: _mounts
						}
						...
					}]
					...
				}
				...
			}
			...
		}
		...
	}

	#additions: mounts_dep: {#kind: "Deployment", #patch: _patch}
	#additions: mounts_ss: {#kind: "StatefulSet", #patch: _patch}
	#additions: mounts_ds: {#kind: "DaemonSet", #patch: _patch}
}

tests: pod_mounts: [

	// just pvc — minimal target struct, mixin dispatches on kind
	{
		kind: "StatefulSet"
		spec: template: spec: containers: [{name: "test"}]
	} & #PodMounts & {
		#mount_pvc: "psql-data": "/var/lib/postgresql/data"
	} & {
		spec: template: spec: {
			containers: [close({
				name: "test"
				volumeMounts: [close({
					name:      "psql-data"
					mountPath: "/var/lib/postgresql/data"
				})]
			})]
			volumes: [
				close({
					name: "psql-data"
					persistentVolumeClaim: close({
						claimName: "psql-data"
						readOnly:  false
					})
				}),
			]
		}
	},

	// just configmap
	{
		kind: "Deployment"
		spec: template: spec: containers: [{name: "test"}]
	} & #PodMounts & {
		#mount_config: "my-config": "/etc/config"
	} & {
		spec: template: spec: {
			containers: [close({
				name: "test"
				volumeMounts: [close({
					name:      "my-config"
					mountPath: "/etc/config"
				})]
			})]
			volumes: [
				close({
					name: "my-config"
					configMap: close({name: "my-config"})
				}),
			]
		}
	},

	// everything — containers and initContainers receive the same mounts.
	{
		let _mounts = [
			close({name: "psql-data", mountPath: "/var/lib/postgresql/data"}),
			close({name: "my-config", mountPath: "/etc/config"}),
			close({name: "my-secret", mountPath: "/etc/secret"}),
			close({name: "var-log", mountPath: "/host/log", readOnly: true}),
		]

		{
			kind: "Deployment"
			spec: template: spec: {
				containers: [{name: "test"}]
				initContainers: [{name: "init-test"}]
			}
		} & #PodMounts & {
			#mount_pvc: "psql-data":     "/var/lib/postgresql/data"
			#mount_config: "my-config":  "/etc/config"
			#mount_secret: "my-secret":  "/etc/secret"
			#mount_hostpath: "/var/log": "/host/log"
		} & {
			spec: template: spec: {
				containers: [close({name: "test", volumeMounts: _mounts})]
				initContainers: [close({name: "init-test", volumeMounts: _mounts})]

				volumes: [
					close({
						name: "psql-data"
						persistentVolumeClaim: close({
							claimName: "psql-data"
							readOnly:  false
						})
					}),
					close({
						name: "my-config"
						configMap: close({name: "my-config"})
					}),
					close({
						name: "my-secret"
						secret: close({secretName: "my-secret"})
					}),
					close({
						name: "var-log"
						hostPath: close({
							path: "/var/log"
							type: "Directory"
						})
					}),
				]
			}
		}
	},

	// no mounts set — passes through with no volumes/volumeMounts injected.
	{
		kind: "Deployment"
		spec: template: spec: containers: [{name: "test"}]
	} & #PodMounts & close({
		kind: "Deployment"
		spec: template: spec: close({
			containers: [close({name: "test"})]
		})
	}),
]
