package parts

import "strings"

#PodTolerations: Self={
	#Mixin
	#toleration?: string
	#tolerations: [...string]

	if Self.#toleration != _|_ {
		#tolerations: [Self.#toleration]
	}

	#Effect: "NoSchedule" | "PreferNoSchedule" | "NoExecute"

	let #parseToleration = {
		_toleration: string
		let _parts = strings.Split(_toleration, ":")
		let _keyValue = strings.Split(_parts[0], "=")

		key:   _keyValue[0]
		value: _keyValue[1]

		if _parts[1] != _|_ {
			if _parts[1] != "" {
				effect: Self.#Effect & _parts[1]
			}
		}
	}

	let _patch = {
		spec: {
			template: {
				spec: {
					if len(Self.#tolerations) > 0 {
						tolerations: [
							for t in Self.#tolerations {
								(#parseToleration & {_toleration: t})
							},
						]
					}
					...
				}
				...
			}
			...
		}
		...
	}

	#additions: tolerations_dep: {#kind: "Deployment", #patch: _patch}
	#additions: tolerations_ss: {#kind: "StatefulSet", #patch: _patch}
	#additions: tolerations_ds: {#kind: "DaemonSet", #patch: _patch}
}

tests: pod_tolerations: [
	// Multiple tolerations on Deployment
	{kind: "Deployment"} & #PodTolerations & {
		#tolerations: ["key1=value1:NoSchedule", "key2=value2:NoSchedule"]
	} & close({
		kind: "Deployment"
		spec: template: spec: close({
			tolerations: [{
				key:    "key1"
				value:  "value1"
				effect: "NoSchedule"
			}, {
				key:    "key2"
				value:  "value2"
				effect: "NoSchedule"
			}]
		})
	}),

	// Single toleration string
	{kind: "Deployment"} & #PodTolerations & {
		#toleration: "key1=value1:NoSchedule"
	} & close({
		kind: "Deployment"
		spec: template: spec: close({
			tolerations: [{
				key:    "key1"
				value:  "value1"
				effect: "NoSchedule"
			}]
		})
	}),

	// Toleration without effect (empty after colon)
	{kind: "Deployment"} & #PodTolerations & {
		#toleration: "key1=value1:"
	} & close({
		kind: "Deployment"
		spec: template: spec: close({
			tolerations: [{
				key:   "key1"
				value: "value1"
			}]
		})
	}),

	// Toleration without colon
	{kind: "Deployment"} & #PodTolerations & {
		#toleration: "key1=value1"
	} & close({
		kind: "Deployment"
		spec: template: spec: close({
			tolerations: [{
				key:   "key1"
				value: "value1"
			}]
		})
	}),

	// PreferNoSchedule effect
	{kind: "Deployment"} & #PodTolerations & {
		#toleration: "key1=value1:PreferNoSchedule"
	} & close({
		kind: "Deployment"
		spec: template: spec: close({
			tolerations: [{
				key:    "key1"
				value:  "value1"
				effect: "PreferNoSchedule"
			}]
		})
	}),

	// NoExecute effect
	{kind: "Deployment"} & #PodTolerations & {
		#toleration: "key1=value1:NoExecute"
	} & close({
		kind: "Deployment"
		spec: template: spec: close({
			tolerations: [{
				key:    "key1"
				value:  "value1"
				effect: "NoExecute"
			}]
		})
	}),

	// List-shape pack: Secret + Deployment in #components
	_packTolerations & #PodTolerations & {
		#tolerations: ["key1=value1:NoSchedule"]
		[...]
	} & [
		{kind: "Secret"},
		{
			kind: "Deployment"
			spec: template: spec: tolerations: [{
				key:    "key1"
				value:  "value1"
				effect: "NoSchedule"
			}]
		},
	],
]

_packTolerations: Self={
	#components: secret: {
		kind: "Secret"
		metadata: name: "test-secret"
	}
	#components: deploy: {
		kind: "Deployment"
		metadata: name: "test-deploy"
		spec: template: spec: {
			containers: [{}]
			...
		}
		...
	}

	[Self.#components.secret, Self.#components.deploy]
}
