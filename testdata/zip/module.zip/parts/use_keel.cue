package parts

// PRODIGY9 convention: image tags are environment names, e.g.
// `ghcr.io/prod9/fx:fx.prodigy9.co` is the image currently online at
// fx.prodigy9.co. The tag is stable per-environment and never changes; only the
// digest moves when a new build is pushed. Keel watches that digest.
//   - policy=force: roll on any digest change (no semver — the tag isn't versioned).
//   - match-tag=true: match the exact env tag, not a prefix or semver pattern.
#UseKeel: {
	#Mixin

	let _patch = {
		metadata: {
			annotations: {
				"keel.sh/policy":    "force"
				"keel.sh/match-tag": "true"
				...
			}
			...
		}
		...
	}

	#additions: keel_dep: {#kind: "Deployment", #patch: _patch}
	#additions: keel_ss: {#kind: "StatefulSet", #patch: _patch}
	#additions: keel_ds: {#kind: "DaemonSet", #patch: _patch}
}

tests: use_keel: [
	// Struct-shape: raw Deployment def unifies with keel annotations.
	{
		kind: "Deployment"
		metadata: {name: "x", namespace: "default"}
	} & #UseKeel & {
		metadata: annotations: {
			"keel.sh/policy":    "force"
			"keel.sh/match-tag": "true"
		}
	},
	// Struct-shape: non-target kind (Service) passes through without keel annotations.
	{
		kind: "Service"
		metadata: {name: "y", namespace: "default"}
	} & #UseKeel & {
		metadata: {name: "y", namespace: "default"}
	},
	// Composition: two mixins on the same kind. Scoped #additions keys
	// (keel_dep vs resources_dep) prevent collision; both patches land.
	{
		kind: "Deployment"
		metadata: {name: "z", namespace: "default"}
		spec: template: spec: containers: [{name: "z"}]
	} & #UseKeel & #PodResources & {
		#reserved_cpu: "100m"
	} & {
		metadata: annotations: {
			"keel.sh/policy":    "force"
			"keel.sh/match-tag": "true"
		}
		spec: template: spec: containers: [{
			resources: requests: cpu: "100m"
			...
		}]
	},
]
