package parts

import (
	"prodigy9.co/defs/attr"
)

#PodController: Self={
	#Metadata
	attr.#Ports
	attr.#Workload

	#priority?: string

	#privileged: bool | *false

	#liveness?:  attr.#HTTPProbe | attr.#TCPProbe | attr.#ExecProbe | attr.#GRPCProbe
	#readiness?: attr.#HTTPProbe | attr.#TCPProbe | attr.#ExecProbe | attr.#GRPCProbe
	#startup?:   attr.#HTTPProbe | attr.#TCPProbe | attr.#ExecProbe | attr.#GRPCProbe

	#init_command?: [...string]
	#init_args?: [...string]

	let _selector = {
		"prodigy9.co/app":     Self.#name
		"prodigy9.co/part-of": Self.#ns
	}

	#out: selector: _selector

	let _container = {

		name:            Self.#name
		image:           Self.#image
		imagePullPolicy: "Always"
		if Self.#env_from != _|_ {
			envFrom: [{secretRef: name: Self.#env_from}]
		}

		if Self.#command != _|_ {
			command: Self.#command
		}
		if Self.#args != _|_ {
			args: Self.#args
		}

		if Self.#privileged {
			securityContext: privileged: true
		}

		if Self.#liveness != _|_ {
			livenessProbe: Self.#liveness
		}
		if Self.#readiness != _|_ {
			readinessProbe: Self.#readiness
		}
		if Self.#startup != _|_ {
			startupProbe: Self.#startup
		}

		if len(Self.#ports) > 0 {
			ports: [
				for p in Self.#ports {
					name:          "port-\(p)"
					containerPort: p
					protocol:      "TCP"
				},
			]
		}

		volumeMounts?: _
		...
	}

	let _initContainer = {
		name:            "\(Self.#name)-init"
		image:           Self.#image
		imagePullPolicy: "Always"
		if Self.#env_from != _|_ {
			envFrom: [{secretRef: name: Self.#env_from}]
		}

		if Self.#init_command != _|_ {
			command: Self.#init_command
		}
		if Self.#init_args != _|_ {
			args: Self.#init_args
		}

		volumeMounts?: _
	}

	apiVersion: "apps/v1"
	kind:       string // specified by the embedding object
	spec: {

		selector: matchLabels: _selector
		revisionHistoryLimit: 2
		template: {

			metadata: labels: _selector
			spec: {

				if Self.#service_account != _|_ {
					serviceAccountName: Self.#service_account
				}
				if Self.#pull_secret != _|_ {
					imagePullSecrets: [{name: Self.#pull_secret}]
				}
				if Self.#init_command != _|_ || Self.#init_args != _|_ {
					initContainers: [_initContainer]
				}
				if Self.#priority != _|_ {
					priorityClassName: Self.#priority
				}

				containers: [_container]
				volumes?: _
				...
			}
			...
		}
		...
	}
	...
}

tests: pod_controller: [

	{
		// vanilla
		#Expected: close({
			apiVersion: "apps/v1"
			kind:       "__NOT_SPECIFIED__"
			metadata: {
				name:      "my-app"
				namespace: "my-ns"
			}
			spec: close({
				selector: close({matchLabels: close({
					"prodigy9.co/app":     "my-app"
					"prodigy9.co/part-of": "my-ns"
				})
				})
				revisionHistoryLimit: 2
				template: close({
					metadata: close({labels: close({
						"prodigy9.co/app":     "my-app"
						"prodigy9.co/part-of": "my-ns"
					})
					})
					spec: close({
						containers: [close({
							name:            "my-app"
							image:           "nginx:latest"
							imagePullPolicy: "Always"
						})]
					})
				})
			})
		})

		#Expected & #PodController & {
			#name:  "my-app"
			#ns:    "my-ns"
			#image: "nginx:latest"
		}
	},

	{
		// full option
		#Expected: close({
			apiVersion: "apps/v1"
			kind:       "__NOT_SPECIFIED__"
			metadata: {
				name:      "my-app"
				namespace: "my-ns"
				labels: "prodigy9.co/env":             "prod"
				annotations: "prodigy9.co/managed-by": "cueinfra"
			}
			spec: close({
				selector: close({matchLabels: close({
					"prodigy9.co/app":     "my-app"
					"prodigy9.co/part-of": "my-ns"
				})
				})
				revisionHistoryLimit: 2
				template: close({
					metadata: close({labels: close({
						"prodigy9.co/app":     "my-app"
						"prodigy9.co/part-of": "my-ns"
					})
					})
					spec: close({
						serviceAccountName: "my-service-account"
						imagePullSecrets: [close({name: "my-pull-secret"})]
						initContainers: [close({
							name:            "my-app-init"
							image:           "nginx:latest"
							imagePullPolicy: "Always"
							command: ["/bin/sh", "-c", "echo"]
							args: ["hello", "init"]
							envFrom: [close({secretRef: name: "my-env-secret"})]
						})]
						containers: [close({
							name:            "my-app"
							image:           "nginx:latest"
							imagePullPolicy: "Always"
							command: ["/bin/sh", "-c", "echo"]
							args: ["hello", "real app"]
							ports: [{
								name:          "port-8080"
								containerPort: 8080
								protocol:      "TCP"
							}]
							envFrom: [close({secretRef: name: "my-env-secret"})]
						})]
					})
				})
			})
		})

		#Expected & #PodController & {
			#name: "my-app"
			#ns:   "my-ns"
			#labels: "prodigy9.co/env":             "prod"
			#annotations: "prodigy9.co/managed-by": "cueinfra"

			#image: "nginx:latest"

			#env_from:        "my-env-secret"
			#pull_secret:     "my-pull-secret"
			#service_account: "my-service-account"

			#command: ["/bin/sh", "-c", "echo"]
			#args: ["hello", "real app"]
			#init_command: ["/bin/sh", "-c", "echo"]
			#init_args: ["hello", "init"]

			#ports: [8080]
		}
	},

	{
		// privileged container
		#Expected: close({
			apiVersion: "apps/v1"
			kind:       "__NOT_SPECIFIED__"
			metadata: {
				name:      "my-app"
				namespace: "my-ns"
			}
			spec: close({
				selector: close({matchLabels: close({
					"prodigy9.co/app":     "my-app"
					"prodigy9.co/part-of": "my-ns"
				})
				})
				revisionHistoryLimit: 2
				template: close({
					metadata: close({labels: close({
						"prodigy9.co/app":     "my-app"
						"prodigy9.co/part-of": "my-ns"
					})
					})
					spec: close({
						containers: [close({
							name:            "my-app"
							image:           "nginx:latest"
							imagePullPolicy: "Always"
							securityContext: privileged: true
						})]
					})
				})
			})
		})

		#Expected & #PodController & {
			#name:       "my-app"
			#ns:         "my-ns"
			#image:      "nginx:latest"
			#privileged: true
		}
	},

	{
		// priority class test
		#Expected: close({
			apiVersion: "apps/v1"
			kind:       "__NOT_SPECIFIED__"
			metadata: {
				name:      "my-app"
				namespace: "my-ns"
			}
			spec: close({
				selector: close({matchLabels: close({
					"prodigy9.co/app":     "my-app"
					"prodigy9.co/part-of": "my-ns"
				})
				})
				revisionHistoryLimit: 2
				template: close({
					metadata: close({labels: close({
						"prodigy9.co/app":     "my-app"
						"prodigy9.co/part-of": "my-ns"
					})
					})
					spec: close({
						containers: [close({
							name:            "my-app"
							image:           "nginx:latest"
							imagePullPolicy: "Always"
						})]
						priorityClassName: "high-priority"
					})
				})
			})
		})
		#Expected & #PodController & {
			#name:     "my-app"
			#ns:       "my-ns"
			#image:    "nginx:latest"
			#priority: "high-priority"
		}
	},

	{
		// http liveness probe
		#Expected: close({
			apiVersion: "apps/v1"
			kind:       "__NOT_SPECIFIED__"
			metadata: {
				name:      "my-app"
				namespace: "my-ns"
			}
			spec: close({
				selector: close({matchLabels: close({
					"prodigy9.co/app":     "my-app"
					"prodigy9.co/part-of": "my-ns"
				})
				})
				revisionHistoryLimit: 2
				template: close({
					metadata: close({labels: close({
						"prodigy9.co/app":     "my-app"
						"prodigy9.co/part-of": "my-ns"
					})
					})
					spec: close({
						containers: [close({
							name:            "my-app"
							image:           "nginx:latest"
							imagePullPolicy: "Always"
							livenessProbe: close({
								httpGet: close({
									path: "/healthz"
									port: 8080
								})
							})
						})]
					})
				})
			})
		})
		#Expected & #PodController & {
			#name:  "my-app"
			#ns:    "my-ns"
			#image: "nginx:latest"
			#liveness: attr.#HTTPProbe & {
				#path: "/healthz"
				#port: 8080
			}
		}
	},

	{
		// tcp readiness with timing
		#Expected: close({
			apiVersion: "apps/v1"
			kind:       "__NOT_SPECIFIED__"
			metadata: {
				name:      "my-app"
				namespace: "my-ns"
			}
			spec: close({
				selector: close({matchLabels: close({
					"prodigy9.co/app":     "my-app"
					"prodigy9.co/part-of": "my-ns"
				})
				})
				revisionHistoryLimit: 2
				template: close({
					metadata: close({labels: close({
						"prodigy9.co/app":     "my-app"
						"prodigy9.co/part-of": "my-ns"
					})
					})
					spec: close({
						containers: [close({
							name:            "my-app"
							image:           "nginx:latest"
							imagePullPolicy: "Always"
							readinessProbe: close({
								tcpSocket: close({port: 5432})
								initialDelaySeconds: 5
								periodSeconds:       15
							})
						})]
					})
				})
			})
		})
		#Expected & #PodController & {
			#name:  "my-app"
			#ns:    "my-ns"
			#image: "nginx:latest"
			#readiness: attr.#TCPProbe & {
				#port:   5432
				#delay:  5
				#period: 15
			}
		}
	},

	{
		// exec liveness
		#Expected: close({
			apiVersion: "apps/v1"
			kind:       "__NOT_SPECIFIED__"
			metadata: {
				name:      "my-app"
				namespace: "my-ns"
			}
			spec: close({
				selector: close({matchLabels: close({
					"prodigy9.co/app":     "my-app"
					"prodigy9.co/part-of": "my-ns"
				})
				})
				revisionHistoryLimit: 2
				template: close({
					metadata: close({labels: close({
						"prodigy9.co/app":     "my-app"
						"prodigy9.co/part-of": "my-ns"
					})
					})
					spec: close({
						containers: [close({
							name:            "my-app"
							image:           "nginx:latest"
							imagePullPolicy: "Always"
							livenessProbe: close({
								exec: close({command: ["pg_isready"]})
							})
						})]
					})
				})
			})
		})
		#Expected & #PodController & {
			#name:  "my-app"
			#ns:    "my-ns"
			#image: "nginx:latest"
			#liveness: attr.#ExecProbe & {
				#command: ["pg_isready"]
			}
		}
	},

	{
		// http startup probe
		#Expected: close({
			apiVersion: "apps/v1"
			kind:       "__NOT_SPECIFIED__"
			metadata: {
				name:      "my-app"
				namespace: "my-ns"
			}
			spec: close({
				selector: close({matchLabels: close({
					"prodigy9.co/app":     "my-app"
					"prodigy9.co/part-of": "my-ns"
				})
				})
				revisionHistoryLimit: 2
				template: close({
					metadata: close({labels: close({
						"prodigy9.co/app":     "my-app"
						"prodigy9.co/part-of": "my-ns"
					})
					})
					spec: close({
						containers: [close({
							name:            "my-app"
							image:           "nginx:latest"
							imagePullPolicy: "Always"
							startupProbe: close({
								httpGet: close({
									path: "/started"
									port: 8080
								})
								initialDelaySeconds: 10
								periodSeconds:       5
							})
						})]
					})
				})
			})
		})
		#Expected & #PodController & {
			#name:  "my-app"
			#ns:    "my-ns"
			#image: "nginx:latest"
			#startup: attr.#HTTPProbe & {
				#path:   "/started"
				#port:   8080
				#delay:  10
				#period: 5
			}
		}
	},

	{
		// grpc readiness with empty service
		#Expected: close({
			apiVersion: "apps/v1"
			kind:       "__NOT_SPECIFIED__"
			metadata: {
				name:      "my-app"
				namespace: "my-ns"
			}
			spec: close({
				selector: close({matchLabels: close({
					"prodigy9.co/app":     "my-app"
					"prodigy9.co/part-of": "my-ns"
				})
				})
				revisionHistoryLimit: 2
				template: close({
					metadata: close({labels: close({
						"prodigy9.co/app":     "my-app"
						"prodigy9.co/part-of": "my-ns"
					})
					})
					spec: close({
						containers: [close({
							name:            "my-app"
							image:           "nginx:latest"
							imagePullPolicy: "Always"
							readinessProbe: close({
								grpc: close({
									port:    9000
									service: ""
								})
							})
						})]
					})
				})
			})
		})
		#Expected & #PodController & {
			#name:  "my-app"
			#ns:    "my-ns"
			#image: "nginx:latest"
			#readiness: attr.#GRPCProbe & {
				#port:    9000
				#service: ""
			}
		}
	},

]
