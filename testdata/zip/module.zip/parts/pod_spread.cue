package parts

// Even pod spread across nodes. Reads the resource's own selector via
// #out.selector — the same map #PodController publishes for
// spec.selector.matchLabels — so the spread group exactly matches the
// controller's pod set with no key duplication. Hardcoded to hostname
// spread, maxSkew=1, ScheduleAnyway.
//
// Compose this when an app has more than one replica; for single-replica
// workloads the constraint is a no-op but does no harm. For list-shape
// packs to compose cleanly, the pack must re-export `selector` in its
// #out (see packs.#WebApp).
//
// Knobs are intentionally absent: this is the framework's opinion on
// "spread evenly", not a topology programming surface.
#PodSpread: Self={
	#Mixin

	let _patch = {
		spec: {
			template: {
				spec: {
					topologySpreadConstraints: [{
						maxSkew:           1
						topologyKey:       "kubernetes.io/hostname"
						whenUnsatisfiable: "ScheduleAnyway"
						labelSelector: matchLabels: Self.#out.selector
					}]
					...
				}
				...
			}
			...
		}
		...
	}

	#additions: spread_dep: {#kind: "Deployment", #patch: _patch}
	#additions: spread_ss: {#kind: "StatefulSet", #patch: _patch}
	#additions: spread_ds: {#kind: "DaemonSet", #patch: _patch}
}

// Back-compat alias for v0.3.1 callers. #PodSpread is the canonical name.
#TopologySpread: #PodSpread

tests: pod_spread: [

	// struct-shape: Deployment — selector flows through from #out.selector
	{
		kind: "Deployment"
		#out: selector: "prodigy9.co/app": "myapp"
	} & #PodSpread & {
		spec: template: spec: topologySpreadConstraints: [{
			maxSkew:           1
			topologyKey:       "kubernetes.io/hostname"
			whenUnsatisfiable: "ScheduleAnyway"
			labelSelector: matchLabels: "prodigy9.co/app": "myapp"
		}]
	},

	// struct-shape: StatefulSet
	{
		kind: "StatefulSet"
		#out: selector: "prodigy9.co/app": "myapp"
	} & #PodSpread & {
		spec: template: spec: topologySpreadConstraints: [{
			labelSelector: matchLabels: "prodigy9.co/app": "myapp"
			...
		}]
	},

	// struct-shape: DaemonSet
	{
		kind: "DaemonSet"
		#out: selector: "prodigy9.co/app": "myapp"
	} & #PodSpread & {
		spec: template: spec: topologySpreadConstraints: [{
			labelSelector: matchLabels: "prodigy9.co/app": "myapp"
			...
		}]
	},

	// non-targeted kind: no patch applied (Service untouched)
	{kind: "Service"} & #PodSpread & close({
		kind: "Service"
	}),

	// integration: composed onto #PodController-derived stub. Selector is
	// auto-derived from #name/#ns by #PodController and flows into the
	// spread constraint without duplication.
	#PodController & #PodSpread & {
		#name:  "myapp"
		#ns:    "myns"
		#image: "nginx:latest"
		kind:   "Deployment"
	} & {
		spec: template: spec: topologySpreadConstraints: [{
			labelSelector: matchLabels: {
				"prodigy9.co/app":     "myapp"
				"prodigy9.co/part-of": "myns"
			}
			...
		}]
		...
	},

	// alias shim: #TopologySpread resolves to the same definition
	{
		kind: "Deployment"
		#out: selector: "prodigy9.co/app": "myapp"
	} & #TopologySpread & {
		spec: template: spec: topologySpreadConstraints: [{
			labelSelector: matchLabels: "prodigy9.co/app": "myapp"
			...
		}]
	},

	// list-shape via minimal pack fixture (defined below)
	_packSpread & #PodSpread & {
		#name: "myapp"
		[...]
	} & [
		{kind: "Secret", metadata: name: "myapp-env"},
		{
			kind: "Deployment"
			metadata: name: "myapp"
			spec: template: spec: {
				topologySpreadConstraints: [{
					labelSelector: matchLabels: "prodigy9.co/app": "myapp"
					...
				}]
				...
			}
		},
	],
]

_packSpread: Self={
	#name: string

	#components: env: {
		kind: "Secret"
		metadata: name: "\(Self.#name)-env"
	}
	#components: deploy: {
		kind: "Deployment"
		metadata: name: Self.#name
		spec: template: spec: {
			containers: [{
				name: Self.#name
				...
			}]
			...
		}
		...
	}

	#out: selector: "prodigy9.co/app": Self.#name

	[Self.#components.env, Self.#components.deploy]
}
