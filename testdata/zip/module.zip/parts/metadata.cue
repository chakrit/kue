package parts

import "prodigy9.co/defs/attr"

#Metadata: Self={
	attr.#Metadata

	metadata: {
		name: Self.#name
		if Self.#ns != _|_ {
			namespace: Self.#ns
		}
		if Self.#labels != _|_ {
			if len(Self.#labels) > 0 {
				labels: Self.#labels
			}
		}
		if Self.#annotations != _|_ {
			if len(Self.#annotations) > 0 {
				annotations: Self.#annotations
			}
		}
		...
	}
}

tests: metadata: [
	// just the name
	#Metadata & {#name: "my-name"} & {
		metadata: close({
			name: "my-name"
		})
	},

	// name and namespace
	#Metadata & {
		#name: "my-name"
		#ns:   "my-ns"
	} & {
		metadata: close({
			name:      "my-name"
			namespace: "my-ns"
		})
	},

	// with labels and annotations
	#Metadata & {
		#name: "my-name"
		#ns:   "my-ns"
		#labels: "prodigy9.co/app":         "cueinfra"
		#annotations: "keel.sh/managed-by": "keel"
	} & {
		metadata: close({
			name:      "my-name"
			namespace: "my-ns"
			labels: close({"prodigy9.co/app": "cueinfra"})
			annotations: close({"keel.sh/managed-by": "keel"})
		})
	},
]
