package defs

import (
	"prodigy9.co/defs/parts"
)

#HorizontalPodAutoscaler: Self={
	parts.#Metadata

	#target:       string
	#min_replicas: int
	#max_replicas: int

	#avg_cpu?: string
	#avg_mem?: string

	apiVersion: "autoscaling/v2"
	kind:       "HorizontalPodAutoscaler"
	spec: {
		scaleTargetRef: {
			apiVersion: "apps/v1"
			kind:       "Deployment"
			name:       Self.#target
		}
		minReplicas: Self.#min_replicas
		maxReplicas: Self.#max_replicas
		behavior: {
			scaleUp: tolerance:   0.05
			scaleDown: tolerance: 0.05
		}
		metrics: [
			if Self.#avg_cpu != _|_ {
				type: "Resource"
				resource: {
					name: "cpu"
					target: {
						type:         "AverageValue"
						averageValue: Self.#avg_cpu
					}
				}
			},
			if Self.#avg_mem != _|_ {
				type: "Resource"
				resource: {
					name: "memory"
					target: {
						type:         "AverageValue"
						averageValue: Self.#avg_mem
					}
				}
			},
		]
	}
}

tests: horizontal_pod_autoscaler: [

	{
		#Expected: close({
			apiVersion: "autoscaling/v2"
			kind:       "HorizontalPodAutoscaler"
			metadata: close({
				name:      "my-app-hpa"
				namespace: "my-ns"
			})
			spec: close({
				scaleTargetRef: close({
					apiVersion: "apps/v1"
					kind:       "Deployment"
					name:       "my-app"
				})
				minReplicas: 2
				maxReplicas: 10
				behavior: close({
					scaleUp: close({tolerance: 0.05})
					scaleDown: close({tolerance: 0.05})
				})
				metrics: [close({
					type: "Resource"
					resource: close({
						name: "cpu"
						target: close({
							type:         "AverageValue"
							averageValue: "500m"
						})
					})
				})]
			})
		})

		#Expected & #HorizontalPodAutoscaler & {
			#name:         "my-app-hpa"
			#ns:           "my-ns"
			#target:       "my-app"
			#min_replicas: 2
			#max_replicas: 10
			#avg_cpu:      "500m"
		}
	},

	{
		#Expected: close({
			apiVersion: "autoscaling/v2"
			kind:       "HorizontalPodAutoscaler"
			metadata: close({
				name:      "my-app-hpa"
				namespace: "my-ns"
			})
			spec: close({
				scaleTargetRef: close({
					apiVersion: "apps/v1"
					kind:       "Deployment"
					name:       "my-app"
				})
				minReplicas: 3
				maxReplicas: 20
				behavior: close({
					scaleUp: close({tolerance: 0.05})
					scaleDown: close({tolerance: 0.05})
				})
				metrics: [
					close({
						type: "Resource"
						resource: close({
							name: "cpu"
							target: close({
								type:         "AverageValue"
								averageValue: "1000m"
							})
						})
					}),
					close({
						type: "Resource"
						resource: close({
							name: "memory"
							target: close({
								type:         "AverageValue"
								averageValue: "2Gi"
							})
						})
					}),
				]
			})
		})

		#Expected & #HorizontalPodAutoscaler & {
			#name:         "my-app-hpa"
			#ns:           "my-ns"
			#target:       "my-app"
			#min_replicas: 3
			#max_replicas: 20
			#avg_cpu:      "1000m"
			#avg_mem:      "2Gi"
		}
	},

]
