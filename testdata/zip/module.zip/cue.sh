#!/bin/sh

CUE_VERSION="v0.15.4"
export CUE_REGISTRY="prodigy9.co=ghcr.io/prod9"

INFRA_DIR="$(cd "$(dirname "$0")" && pwd)"
CUE_BIN="${INFRA_DIR}/bin/cue-${CUE_VERSION}"

if [ ! -x "${CUE_BIN}" ]
then
	echo "downloading ${CUE_BIN} ..."
	mkdir -p "${INFRA_DIR}/bin"

	export GOBIN="${INFRA_DIR}/bin"
	(
		set -xe
		go install "cuelang.org/go/cmd/cue@${CUE_VERSION}"
		mv "${GOBIN}/cue" "${CUE_BIN}"
		${CUE_BIN} version
	)
fi

${CUE_BIN} "$@"

