package defs

import (
	"prodigy9.co/defs/attr"
	"prodigy9.co/defs/parts"
)

#GRPCRoute: Self={
	parts.#Metadata
	attr.#Hosts
	attr.#ServiceRef

	#gateway_name: string
	#gateway_ns?:  string

	apiVersion: "gateway.networking.k8s.io/v1"
	kind:       "GRPCRoute"

	spec: {
		parentRefs: [{
			name: Self.#gateway_name
			if Self.#gateway_ns != _|_ {
				namespace: Self.#gateway_ns
			}
		}]
		hostnames: Self.#hosts
		rules: [{
			backendRefs: [{
				name: Self.#service_name
				port: Self.#service_port
			}]
		}]
	}
}

tests: grpc_route: [

	// basic
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "GRPCRoute"
			metadata: {
				name:      "my-route"
				namespace: "my-ns"
			}
			spec: {
				parentRefs: [{name: "my-gateway"}]
				hostnames: ["grpc.example.com"]
				rules: [{
					backendRefs: [{
						name: "my-service"
						port: 50051
					}]
				}]
			}
		}

		#Expected & #GRPCRoute & {
			#name:         "my-route"
			#ns:           "my-ns"
			#gateway_name: "my-gateway"
			#hosts: ["grpc.example.com"]
			#service_name: "my-service"
			#service_port: 50051
		}
	},

	// multiple hosts
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "GRPCRoute"
			metadata: {
				name:      "my-route"
				namespace: "my-ns"
			}
			spec: {
				parentRefs: [{name: "my-gateway"}]
				hostnames: ["alpha.grpc.com", "beta.grpc.com"]
				rules: [{
					backendRefs: [{
						name: "my-service"
						port: 50051
					}]
				}]
			}
		}

		#Expected & #GRPCRoute & {
			#name:         "my-route"
			#ns:           "my-ns"
			#gateway_name: "my-gateway"
			#hosts: ["alpha.grpc.com", "beta.grpc.com"]
			#service_name: "my-service"
			#service_port: 50051
		}
	},

	// cross-namespace gateway ref
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "GRPCRoute"
			metadata: {
				name:      "my-route"
				namespace: "my-ns"
			}
			spec: {
				parentRefs: [{
					name:      "shared-gateway"
					namespace: "infra"
				}]
				hostnames: ["grpc.example.com"]
				rules: [{
					backendRefs: [{
						name: "my-service"
						port: 9000
					}]
				}]
			}
		}

		#Expected & #GRPCRoute & {
			#name:         "my-route"
			#ns:           "my-ns"
			#gateway_name: "shared-gateway"
			#gateway_ns:   "infra"
			#hosts: ["grpc.example.com"]
			#service_name: "my-service"
			#service_port: 9000
		}
	},

]
