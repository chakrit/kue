# prodigy9.co/defs

PRODIGY9's K8S infrastructure definitions framework (v2). A CUE module of thin K8s
resource wrappers, composable parts, and full app blueprints — consumed by downstream
infra repos to render manifests with `cue export`.

## Quick Start

Add the dep in your downstream repo's `cue.mod/module.cue`:

```cue
module: "yourorg.example/infra"
language: version: "v0.15.4"
deps: "prodigy9.co/defs": v: "v0.3.0"  // pin to the latest published tag
```

Drop a `cue.sh` wrapper into the downstream repo — it pins `cue` to v0.15.4 and exports
`CUE_REGISTRY=prodigy9.co=ghcr.io/prod9`, which redirects the `prodigy9.co/defs`
module to OCI artifacts published from `prod9/infra-defs` at `ghcr.io/prod9/defs`:

```sh
#!/bin/sh

CUE_VERSION="v0.15.4"
export CUE_REGISTRY="prodigy9.co=ghcr.io/prod9"

INFRA_DIR="$(cd "$(dirname "$0")" && pwd)"
CUE_BIN="${INFRA_DIR}/bin/cue-${CUE_VERSION}"

if [ ! -x "${CUE_BIN}" ]
then
	echo "downloading ${CUE_BIN} ..."
	mkdir -p "${INFRA_DIR}/bin"

	export GOBIN="${INFRA_DIR}/bin"
	(
		set -xe
		go install "cuelang.org/go/cmd/cue@${CUE_VERSION}"
		mv "${GOBIN}/cue" "${CUE_BIN}"
		${CUE_BIN} help
	)
fi

${CUE_BIN} "$@"
```

Then resolve with `./cue.sh mod tidy`.

Minimal `#WebApp` (Standard App Pattern):

```cue
package apps

import (
    "prodigy9.co/defs/packs"
    "prodigy9.co/defs/parts"
)

my_app: packs.#WebApp & {
    #name:         "my-app"
    #ns:           "my-ns"
    #image:        "ghcr.io/myorg/my-app:latest"
    #host:         "my-app.example.com"
    #port:         80
    #gateway_name: "main-gateway"
    #env: DATABASE_URL: "postgres://..."
    [...]
} & parts.#PodResources & {
    #reserved_cpu: "200m"
    #reserved_mem: "256Mi"
    [...]
}
```

The pack expands to `Secret + Deployment + Service + HTTPRoute`. Mixins
(`parts.#PodResources`, `parts.#PodTolerations`, `parts.#NodeAffinity`,
`parts.#UseCertManager`, `parts.#UseKeel`, `parts.#PodMounts`) chain via `&` onto the
pack. The trailing `[...]` in each mixin's param struct is required for pack targets
(list-shape compat); omit it when applying directly to raw defs. See `spec/mixins.md`
for the full mixin model and `packs/web_app.cue` / `packs/basics.cue` for input
surfaces.

Render to YAML with `cue export` — pointing at `./apps/...` evaluates inside the
`apps` package, so the field name (`my_app`) is the export path:

```sh
./cue.sh export -e my_app --out yaml ./apps/...
```

`--out yaml` produces a multi-document stream, pipeable straight into
`kubectl apply -f -`.

Or write per-app manifests into a `k8s/` tree for `kubectl apply -f k8s/<app>/`:

```sh
mkdir -p k8s/my-app
./cue.sh export -e my_app --out yaml ./apps/... > k8s/my-app/manifests.yaml
```

Loop over multiple apps with a shell `for` to keep the tree in sync.

## Architecture

Layered, bottom-up. Each layer consumes the one below.

- `attr/` — reusable input fragments (`#Metadata`, `#Hosts`, `#Ports`, `#Probe` family).
  Embedded via unification into higher layers.
- `parts/` — composable bases (`#PodController`, `#Metadata`) and mixins
  (`#UseCertManager`, `#UseKeel`, `#PodResources`, `#PodTolerations`, `#NodeAffinity`,
  `#PodMounts`).
- root `defs` (package `defs`) — thin K8s resource wrappers (`#Deployment`, `#Service`,
  `#Ingress`, `#Gateway`, `#HTTPRoute`, `#Secret`, `#PVC`, ...).
- `packs/` — full app blueprints (`#Basics`, `#WebApp`, `#Gateway`, `#Postgres`,
  `#Redis`) emitting fixed-position resource lists.

Design specs and decision records live in [`spec/`](spec/).

## Conventions

- `#snake_case` for input fields (`#db_name`, `#pull_secret`, `#cluster_issuer`).
- `#out` struct for derived outputs other components can reference
  (`db.#out.db_url`, `nsp.#out.pull_secret_name`).
- `let` bindings for in-pack composition (file-scoped; safe inside packs).
- Dashes-not-underscores in K8s resource names — secret names, service names, etc. use
  `"\(#name)-secret"`, never `"\(#name)_secret"`.
- Labels use `prodigy9.co/app` and `prodigy9.co/part-of` (not `app.kubernetes.io/*`).

## Cluster Prerequisites

Defs only emit manifests — the CRDs and controllers must already exist on the target
cluster. A few non-obvious version pins to know about:

- **Gateway API CRDs** (for `#Gateway` / `#HTTPRoute`): install the Standard channel
  bundle at **v1.3+** (v1.4.x recommended). Older bundles (e.g. v1.2.1) ship
  `referencegrants` only at `v1beta1`, which NGINX Gateway Fabric ≥ 2.5.x rejects with
  `SupportedVersion=False` / `UnsupportedVersion` on the `GatewayClass` and the
  controller logs `ReferenceGrant v1 CRD not found … controller disabled`. Defs here
  don't emit `ReferenceGrant`, but the controller still gates on its API version.
- **cert-manager** (for `parts.#UseCertManager`): ≥ 1.15 with
  `config.enableGatewayAPI: true` set at install time, otherwise the gateway-shim won't
  issue per-listener `Certificate`s.

## Local Development

All scripts run from repo root. `./cue.sh` auto-downloads CUE v0.15.4 to `bin/` on first
use; the rest delegate through it.

- `./cue.sh [args]` — `cue` wrapper. Sets `CUE_REGISTRY=prodigy9.co=ghcr.io/prod9` and
  pins to v0.15.4.
- `./cue-fmt.sh` — `cue fmt -Eis ./...`. Always run first.
- `./cue-check.sh` — `cue vet -c ./...`. Validates concretely.
- `./cue-test.sh` — `cue eval --all --concrete -e tests ./...`. Runs inline `tests`
  blocks in every package.
- `./cue-publish.sh` — validates clean tree on `main` at an annotated `v*` tag, then
  `cue mod publish $TAG`.

Standard loop: `./cue-fmt.sh && ./cue-check.sh && ./cue-test.sh`.

## Publishing

`./cue-publish.sh` refuses unless all three hold:

- working tree clean (no unstaged or staged changes),
- `HEAD` is on branch `main`,
- `HEAD` carries an annotated `v*` tag (resolved via `git describe --exact-match`).

Tag, push, then run the script. The tag itself drives the published version — there is
no version arg.

## Issue Tracking

Linear project — Infrastructure Definitions:
https://linear.app/prodigy9/project/infrastructure-definitions-1bffd3d00cec
