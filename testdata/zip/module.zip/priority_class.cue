package defs

import (
	"prodigy9.co/defs/parts"
)

#PriorityClass: Self={
	parts.#Metadata

	#value:        int
	#default:      bool | *false
	#description?: string

	kind:       "PriorityClass"
	apiVersion: "scheduling.k8s.io/v1"
	spec: {
		value:         Self.#value
		globalDefault: Self.#default
		if Self.#description != _|_ {
			description: Self.#description
		}
		...
	}
	...
}

tests: priority_class: [
	// basic test – only value and name
	#PriorityClass & {
		#name:  "high-priority"
		#value: 1000
	} & close({
		apiVersion: "scheduling.k8s.io/v1"
		kind:       "PriorityClass"
		metadata: close({
			name: "high-priority"
		})
		spec: close({
			value:         1000
			globalDefault: false
		})
	}),

	// default true test
	#PriorityClass & {
		#name:  "default-priority"
		#value: 500, #default: true
	} & close({
		apiVersion: "scheduling.k8s.io/v1"
		kind:       "PriorityClass"
		metadata: close({
			name: "default-priority"
		})
		spec: close({
			value:         500
			globalDefault: true
		})
	}),

	// description test
	#PriorityClass & {
		#name:        "desc-priority"
		#value:       200
		#description: "used for low priority"
	} & close({
		apiVersion: "scheduling.k8s.io/v1"
		kind:       "PriorityClass"
		metadata: close({
			name: "desc-priority"
		})
		spec: close({
			value:         200
			globalDefault: false
			description:   "used for low priority"
		})
	}),

	// full metadata test (labels, annotations, description, default true)
	#PriorityClass & {
		#name: "full-priority"
		#labels: "prodigy9.co/app":         "cueinfra"
		#annotations: "keel.sh/managed-by": "keel"
		#value:       300
		#default:     true
		#description: "full metadata test"
	} & close({
		apiVersion: "scheduling.k8s.io/v1"
		kind:       "PriorityClass"
		metadata: close({
			name: "full-priority"
			labels: close({"prodigy9.co/app": "cueinfra"})
			annotations: close({"keel.sh/managed-by": "keel"})
		})
		spec: close({
			value:         300
			globalDefault: true
			description:   "full metadata test"
		})
	}),
]
