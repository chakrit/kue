module: "prodigy9.co/defs"
source: kind: "git"
language: {
	version: "v0.15.4"
}
