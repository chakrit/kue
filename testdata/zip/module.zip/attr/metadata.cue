package attr

#Metadata: {
	#name: string
	#ns?:  string
	#labels?: [string]:      string
	#annotations?: [string]: string

	_
}
