package attr

#Hosts: {
	#host?: string
	#hosts: [...string]

	if #host != _|_ {
		#hosts: [#host]
	}
}

tests: hosts: [
	#Hosts & {#host: "example.com"} & {#hosts: ["example.com"]},
	#Hosts & {#host: "example.com", #hosts: ["example.com"]},
]
