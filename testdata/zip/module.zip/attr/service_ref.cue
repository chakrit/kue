package attr

#ServiceRef: {
	#service?: {
		#name: string
		#ports: [...int]
		...
	}
	if #service == _|_ {
		#service_name: string
		#service_port: int
	}
	if #service != _|_ {
		#service_name: #service.#name
		#service_port: #service.#ports[0]
	}
}
