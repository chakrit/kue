package attr

#Workload: {
	#image: string

	#env_from?: string

	#pull_secret?:     string
	#service_account?: string

	#command?: [...string]
	#args?: [...string]
}
