package attr

#Ports: {
	#port?: int
	#ports: [...int]

	if #port != _|_ {
		#ports: [#port]
	}
}

tests: ports: [
	#Ports & {#port: 80} & {#ports: [80]},
	#Ports & {#ports: [80, 443]} & {#ports: [80, 443]},
	#Ports & {#port: 80, #ports: [80]},
]
