package attr

#Probe: {
	#delay?:   int
	#period?:  int
	#timeout?: int

	if #delay != _|_ {
		initialDelaySeconds: #delay
	}
	if #period != _|_ {
		periodSeconds: #period
	}
	if #timeout != _|_ {
		timeoutSeconds: #timeout
	}
}

#HTTPProbe: {
	#Probe
	#path:    string
	#port:    int
	#scheme?: "HTTP" | "HTTPS"

	httpGet: {
		path: #path
		port: #port
		if #scheme != _|_ {
			scheme: #scheme
		}
	}
}

#TCPProbe: {
	#Probe
	#port: int

	tcpSocket: port: #port
}

#ExecProbe: {
	#Probe
	#command: [...string]

	exec: command: #command
}

#GRPCProbe: {
	#Probe
	#port:    int
	#service: string

	grpc: {
		port:    #port
		service: #service
	}
}

tests: probe: [
	// http minimal
	#HTTPProbe & {#path: "/healthz", #port: 8080} & {
		httpGet: {
			path: "/healthz"
			port: 8080
		}
	},

	// http with scheme + timing
	#HTTPProbe & {
		#path:    "/healthz"
		#port:    8443
		#scheme:  "HTTPS"
		#delay:   5
		#period:  15
		#timeout: 3
	} & {
		httpGet: {
			path:   "/healthz"
			port:   8443
			scheme: "HTTPS"
		}
		initialDelaySeconds: 5
		periodSeconds:       15
		timeoutSeconds:      3
	},

	// tcp
	#TCPProbe & {#port: 5432} & {
		tcpSocket: port: 5432
	},

	// exec
	#ExecProbe & {#command: ["pg_isready", "-U", "postgres"]} & {
		exec: command: ["pg_isready", "-U", "postgres"]
	},

	// grpc with service
	#GRPCProbe & {#port: 9000, #service: "Health"} & {
		grpc: {
			port:    9000
			service: "Health"
		}
	},

	// grpc overall server health
	#GRPCProbe & {#port: 9000, #service: ""} & {
		grpc: {
			port:    9000
			service: ""
		}
	},
]
