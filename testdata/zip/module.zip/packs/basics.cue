package packs

import (
	"prodigy9.co/defs/attr"
	"prodigy9.co/defs"
)

#Basics: Self={
	attr.#Metadata

	#registry:          string | *"ghcr.io"
	#registry_username: string | *"x9-github"
	#registry_password: string

	#components: {
		ns: defs.#Namespace & {
			#name: Self.#name
			if Self.#labels != _|_ {
				#labels: Self.#labels
			}
			if Self.#annotations != _|_ {
				#annotations: Self.#annotations
			}
		}

		pull_secret: defs.#Secret & {
			#name: "\(Self.#registry)-pull-secret"
			#ns:   Self.#name
			#type: "kubernetes.io/dockerconfigjson"

			#data: "\(Self.#registry)": {
				username: Self.#registry_username
				password: Self.#registry_password
			}
		}
	}

	// TODO: ResourceQuota and LimitRange
	[Self.#components.ns, Self.#components.pull_secret]

	#out: pull_secret_name: Self.#components.pull_secret.#name
}

tests: basics: [

	// basic
	#Basics & {
		#name:              "basicapp"
		#registry:          "ghcr.io"
		#registry_username: "basicapp-robot"
		#registry_password: "s3cr3t"

		#out: pull_secret_name: "ghcr.io-pull-secret"

		[...]
	} & [
		{
			kind: "Namespace"
			metadata: close({name: "basicapp"})
		},
		{
			kind: "Secret"
			metadata: close({
				name:      "ghcr.io-pull-secret"
				namespace: "basicapp"
			})
			type: "kubernetes.io/dockerconfigjson"
			data: close({
				".dockerconfigjson": "eyJhdXRocyI6eyJnaGNyLmlvIjp7ImF1dGgiOiJZbUZ6YVdOaGNIQXRjbTlpYjNRNmN6Tmpjak4wIn19fQ=="
			})
		},
	],

	// with labels and annotations
	#Basics & {
		#name:              "labeledapp"
		#registry_password: "test-password"
		#labels: {
			"app.kubernetes.io/part-of":    "labeledapp"
			"app.kubernetes.io/managed-by": "cue"
		}
		#annotations: "example.com/annotation": "value"

		[...]
	} & [
		{
			kind: "Namespace"
			metadata: close({
				name: "labeledapp"
				labels: {
					"app.kubernetes.io/part-of":    "labeledapp"
					"app.kubernetes.io/managed-by": "cue"
				}
				annotations: "example.com/annotation": "value"
			})
		},
		{
			kind: "Secret"
			metadata: close({
				name:      "ghcr.io-pull-secret"
				namespace: "labeledapp"
			})
			type: "kubernetes.io/dockerconfigjson"
			data: close({
				".dockerconfigjson": "eyJhdXRocyI6eyJnaGNyLmlvIjp7ImF1dGgiOiJlRGt0WjJsMGFIVmlPblJsYzNRdGNHRnpjM2R2Y21RPSJ9fX0="
			})
		},
	],

]
