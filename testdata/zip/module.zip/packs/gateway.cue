package packs

import (
	"prodigy9.co/defs"
	"prodigy9.co/defs/attr"
	"prodigy9.co/defs/parts"
)

#Gateway: Self={
	attr.#Metadata

	#gateway_class: string

	#gateway_hosts: [string]: (defs.#HTTPRoute | defs.#TLSRoute | defs.#TCPRoute)

	let _http_hosts = [
		for _, r in Self.#gateway_hosts if r.kind == "HTTPRoute" for h in r.spec.hostnames {h},
	]
	let _tls_hosts = [
		for _, r in Self.#gateway_hosts if r.kind == "TLSRoute" for h in r.spec.hostnames {h},
	]
	let _tcp_ports_map = {
		for _, r in Self.#gateway_hosts if r.kind == "TCPRoute" {
			"\(r.spec.rules[0].backendRefs[0].port)": r.spec.rules[0].backendRefs[0].port
		}
	}
	let _tcp_ports = [for _, p in _tcp_ports_map {p}]

	let _rg_keys = {
		for _, r in Self.#gateway_hosts {
			"\(r.kind):\(r.metadata.namespace)": {
				kind:      r.kind
				namespace: r.metadata.namespace
			}
		}
	}

	#components: {
		gateway: defs.#Gateway & {
			#name:              Self.#name
			#ns:                Self.#ns
			#gateway_class:     Self.#gateway_class
			#hosts:             _http_hosts
			#passthrough_hosts: _tls_hosts
			#tcp_ports:         _tcp_ports
		}

		// Catch-all 80 → 443 redirect for every host the gateway accepts.
		// Inlined raw because defs.#HTTPRoute requires a backend.
		redirect: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "HTTPRoute"
			metadata: {
				name:      "\(Self.#name)-redirect"
				namespace: Self.#ns
			}
			spec: {
				parentRefs: [{
					name:        Self.#name
					sectionName: "http"
				}]
				rules: [{
					filters: [{
						type: "RequestRedirect"
						requestRedirect: {
							scheme:     "https"
							statusCode: 301
						}
					}]
				}]
			}
		}

		if len(_rg_keys) > 0 {
			rg: defs.#ReferenceGrant & {
				#name: "rg-to-\(Self.#name)"
				#ns:   Self.#ns
				#from: [for _, e in _rg_keys {e}]
				#to: [{kind: "Gateway"}]
			}
		}
	}

	[for _, c in Self.#components {c}]

	#out: {
		name: Self.#name
		ns:   Self.#ns
	}
}

tests: gateway: [

	// single HTTPRoute — Gateway + redirect + RG with one from-entry
	#Gateway & {
		#name:          "main"
		#ns:            "gateway-ns"
		#gateway_class: "nginx"
		#gateway_hosts: foo: defs.#HTTPRoute & {
			#name:         "foo-route"
			#ns:           "foo-ns"
			#gateway_name: "main"
			#gateway_ns:   "gateway-ns"
			#host:         "foo.example.com"
			#service_name: "foo-svc"
			#service_port: 80
		}
		[...]
	} & [
		{
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "Gateway"
			metadata: {
				name:      "main"
				namespace: "gateway-ns"
			}
			spec: {
				gatewayClassName: "nginx"
				listeners: [{
					name:     "https-foo-example-com"
					hostname: "foo.example.com"
					port:     443
					protocol: "HTTPS"
					_
				}, {
					name:     "http"
					port:     80
					protocol: "HTTP"
					_
				}]
			}
		},
		{
			kind: "HTTPRoute"
			metadata: name: "main-redirect"
			_
		},
		{
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "ReferenceGrant"
			metadata: {
				name:      "rg-to-main"
				namespace: "gateway-ns"
			}
			spec: {
				from: [
					{group: "gateway.networking.k8s.io", kind: "HTTPRoute", namespace: "foo-ns"},
				]
				to: [{group: "gateway.networking.k8s.io", kind: "Gateway"}]
			}
		},
	],

	// multiple apps, deduped RG (one entry per (kind, namespace))
	#Gateway & {
		#name:          "main"
		#ns:            "gateway-ns"
		#gateway_class: "nginx"
		#gateway_hosts: {
			foo: defs.#HTTPRoute & {
				#name:         "foo-route"
				#ns:           "foo-ns"
				#gateway_name: "main"
				#gateway_ns:   "gateway-ns"
				#host:         "foo.example.com"
				#service_name: "foo-svc"
				#service_port: 80
			}
			bar: defs.#HTTPRoute & {
				#name:         "bar-route"
				#ns:           "bar-ns"
				#gateway_name: "main"
				#gateway_ns:   "gateway-ns"
				#host:         "bar.example.com"
				#service_name: "bar-svc"
				#service_port: 80
			}
		}
		[...]
	} & [
		{kind: "Gateway", _},
		{kind: "HTTPRoute", metadata: name: "main-redirect", _},
		{
			kind: "ReferenceGrant"
			spec: from: [
				{group: "gateway.networking.k8s.io", kind: "HTTPRoute", namespace: "foo-ns"},
				{group: "gateway.networking.k8s.io", kind: "HTTPRoute", namespace: "bar-ns"},
			]
			_
		},
	],

	// mixed HTTP + TLS + TCP routes — all listener kinds + RG with three entries
	#Gateway & {
		#name:          "main"
		#ns:            "gateway-ns"
		#gateway_class: "nginx"
		#gateway_hosts: {
			web: defs.#HTTPRoute & {
				#name:         "web-route"
				#ns:           "web-ns"
				#gateway_name: "main"
				#gateway_ns:   "gateway-ns"
				#host:         "web.example.com"
				#service_name: "web-svc"
				#service_port: 80
			}
			argo: defs.#TLSRoute & {
				#name:         "argo-route"
				#ns:           "argo-ns"
				#gateway_name: "main"
				#gateway_ns:   "gateway-ns"
				#host:         "argo.example.com"
				#service_name: "argo-svc"
				#service_port: 443
			}
			db: defs.#TCPRoute & {
				#name:         "db-route"
				#ns:           "db-ns"
				#gateway_name: "main"
				#gateway_ns:   "gateway-ns"
				#service_name: "db-svc"
				#service_port: 5432
			}
		}
		[...]
	} & [
		{
			kind: "Gateway"
			spec: listeners: [{
				name:     "https-web-example-com"
				hostname: "web.example.com"
				protocol: "HTTPS"
				_
			}, {
				name:     "http"
				protocol: "HTTP"
				_
			}, {
				name:     "tls-argo-example-com"
				hostname: "argo.example.com"
				port:     443
				protocol: "TLS"
				tls: mode: "Passthrough"
				_
			}, {
				name:     "tcp-5432"
				port:     5432
				protocol: "TCP"
				_
			}]
			_
		},
		{kind: "HTTPRoute", metadata: name: "main-redirect", _},
		{
			kind: "ReferenceGrant"
			spec: from: [
				{group: "gateway.networking.k8s.io", kind: "HTTPRoute", namespace: "web-ns"},
				{group: "gateway.networking.k8s.io", kind: "TLSRoute", namespace: "argo-ns"},
				{group: "gateway.networking.k8s.io", kind: "TCPRoute", namespace: "db-ns"},
			]
			_
		},
	],

	// #out values exposed
	(#Gateway & {
		#name:          "main"
		#ns:            "gateway-ns"
		#gateway_class: "nginx"
		[...]
	}).#out & {
		name: "main"
		ns:   "gateway-ns"
	},

	// cert-manager mixin — annotation lands on Gateway, redirect/RG untouched
	#Gateway & parts.#UseCertManager & {
		#name:           "main"
		#ns:             "gateway-ns"
		#gateway_class:  "nginx"
		#cluster_issuer: "letsencrypt-prod"
		#gateway_hosts: foo: defs.#HTTPRoute & {
			#name:         "foo-route"
			#ns:           "foo-ns"
			#gateway_name: "main"
			#gateway_ns:   "gateway-ns"
			#host:         "foo.example.com"
			#service_name: "foo-svc"
			#service_port: 80
		}
		[...]
	} & [
		{
			kind: "Gateway"
			metadata: {
				name:      "main"
				namespace: "gateway-ns"
				annotations: "cert-manager.io/cluster-issuer": "letsencrypt-prod"
			}
			_
		},
		{
			kind: "HTTPRoute"
			metadata: name:         "main-redirect"
			metadata: annotations?: _|_
			_
		},
		{kind: "ReferenceGrant", _},
	],
]
