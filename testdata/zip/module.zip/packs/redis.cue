package packs

import (
	"prodigy9.co/defs"
	"prodigy9.co/defs/attr"
	"prodigy9.co/defs/parts"
)

#Redis: Self={
	attr.#Metadata

	#version:       string | *"8"
	#storage:       string
	#storage_class: string

	#components: {
		pvc: defs.#PVC & {
			#name:          "\(Self.#name)-pvc"
			#ns:            Self.#ns
			#storage:       Self.#storage
			#storage_class: Self.#storage_class
		}

		ss: defs.#StatefulSet & {
			#name:  Self.#name
			#ns:    Self.#ns
			#image: "redis:\(Self.#version)-alpine"
			#args: ["--appendonly", "yes"]

			#port:     6379
			#replicas: 1

			#init_command: [
				"sh", "-c",
				"chown -R $(id -u redis):$(id -g redis) /data",
			]

			if Self.#labels != _|_ {
				#labels: Self.#labels
			}
			if Self.#annotations != _|_ {
				#annotations: Self.#annotations
			}

			parts.#PodMounts
			#mount_pvc: "\(Self.#name)-pvc": "/data"
		}

		svc: defs.#Service & {
			#name:     "\(Self.#name)-service"
			#ns:       Self.#ns
			#port:     Self.#components.ss.#port
			#selector: Self.#components.ss.#out.selector
		}
	}

	[
		Self.#components.pvc,
		Self.#components.ss,
		Self.#components.svc,
	]

	#out: {
		host: "\(Self.#components.svc.#name).\(Self.#ns).svc.cluster.local"
		port: Self.#components.ss.#port

		url:          "redis://\(host):\(port)"
		service_name: Self.#components.svc.#name
	}
}

tests: redis: [
	// basic
	#Redis & {
		#name:          "my-redis"
		#ns:            "my-ns"
		#storage:       "1Gi"
		#storage_class: "cue-standard"

		#out: url: "redis://my-redis-service.my-ns.svc.cluster.local:6379"

		[...]
	} & [
		{
			apiVersion: "v1"
			kind:       "PersistentVolumeClaim"
			metadata: {
				name:      "my-redis-pvc"
				namespace: "my-ns"
			}
			spec: {
				accessModes: ["ReadWriteOnce"]
				resources: requests: storage: "1Gi"
				storageClassName: "cue-standard"
			}
		},
		{
			apiVersion: "apps/v1"
			kind:       "StatefulSet"
			metadata: {
				name:      "my-redis"
				namespace: "my-ns"
			}
			spec: {
				replicas: 1
				template: spec: {
					containers: [{
						name:  "my-redis"
						image: "redis:8-alpine"
						args: ["--appendonly", "yes"]
						ports: [{
							containerPort: 6379
							name:          "port-6379"
						}]
						volumeMounts: [{
							name:      "my-redis-pvc"
							mountPath: "/data"
						}]
					}]
					volumes: [{
						name: "my-redis-pvc"
						persistentVolumeClaim: claimName: "my-redis-pvc"
					}]
				}
			}
		},
		{
			apiVersion: "v1"
			kind:       "Service"
			metadata: {
				name:      "my-redis-service"
				namespace: "my-ns"
			}
			spec: {
				ports: [{
					port:       6379
					targetPort: 6379
					protocol:   "TCP"
					name:       "tcp-6379"
				}]
				selector: "prodigy9.co/app": "my-redis"
			}
		},
	],
]
