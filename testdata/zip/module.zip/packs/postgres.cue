package packs

import (
	"prodigy9.co/defs"
	"prodigy9.co/defs/attr"
	"prodigy9.co/defs/parts"
)

#Postgres: Self={
	attr.#Metadata

	#version:       string | *"17"
	#storage:       string
	#storage_class: string

	#db_name:     string
	#db_user:     string | *#db_name
	#db_password: string

	#components: {
		env: defs.#Secret & {
			#name: "\(Self.#name)-secret"
			#ns:   Self.#ns

			#type: "Opaque"
			#data: {
				POSTGRES_DB:       Self.#db_name
				POSTGRES_USER:     Self.#db_user
				POSTGRES_PASSWORD: Self.#db_password
				PGDATA:            "/var/lib/postgres/data/pgdata/\(Self.#db_name)"
			}
		}

		pvc: defs.#PVC & {
			#name:          "\(Self.#name)-pvc"
			#ns:            Self.#ns
			#storage:       Self.#storage
			#storage_class: Self.#storage_class
		}

		ss: defs.#StatefulSet & {
			#name: Self.#name
			#ns:   Self.#ns
			if Self.#labels != _|_ {
				#labels: Self.#labels
			}
			if Self.#annotations != _|_ {
				#annotations: Self.#annotations
			}

			#image:    "postgres:\(Self.#version)-alpine"
			#replicas: 1
			#port:     5432
			#env_from: Self.#components.env.#name

			parts.#PodMounts
			#mount_pvc: "\(Self.#name)-pvc": "/var/lib/postgres/data/pgdata"
		}

		svc: defs.#Service & {
			#name:     "\(Self.#name)-service"
			#ns:       Self.#ns
			#port:     Self.#components.ss.#port
			#selector: Self.#components.ss.#out.selector
		}
	}

	[
		Self.#components.env,
		Self.#components.pvc,
		Self.#components.ss,
		Self.#components.svc,
	]

	#out: {
		let db_auth = "\(Self.#db_user):\(Self.#db_password)"

		host:         "\(Self.#components.svc.#name).\(Self.#ns).svc.cluster.local"
		port:         "\(Self.#components.svc.#port)"
		name:         Self.#db_name
		url:          "postgres://\(db_auth)@\(host):\(port)/\(name)?sslmode=disable"
		service_name: Self.#components.svc.#name
	}
}

tests: postgres: [

	#Postgres & {
		#name: "my-postgres"
		#ns:   "my-ns"
		#labels: custom:      "label"
		#annotations: custom: "annotation"

		#version:       "17"
		#storage:       "10Gi"
		#storage_class: "cue-standard"

		#db_name:     "mydb"
		#db_user:     "myuser"
		#db_password: "mypassword"

		#out: {
			host:         "my-postgres-service.my-ns.svc.cluster.local"
			port:         "5432"
			name:         "mydb"
			url:          "postgres://myuser:mypassword@my-postgres-service.my-ns.svc.cluster.local:5432/mydb?sslmode=disable"
			service_name: "my-postgres-service"
		}

		[...]
	} & [
		{
			kind: "Secret"
			data: close({
				POSTGRES_DB:       "bXlkYg=="
				POSTGRES_USER:     "bXl1c2Vy"
				POSTGRES_PASSWORD: "bXlwYXNzd29yZA=="
				PGDATA:            "L3Zhci9saWIvcG9zdGdyZXMvZGF0YS9wZ2RhdGEvbXlkYg=="
			})
		},

		{
			kind: "PersistentVolumeClaim"
			spec: close({
				accessModes: ["ReadWriteOnce"]
				resources: close({requests: storage: "10Gi"})
				storageClassName: "cue-standard"
			})
		},

		// statefulset
		{
			kind: "StatefulSet"
			metadata: {
				name:      "my-postgres"
				namespace: "my-ns"
				labels: custom:      "label"
				annotations: custom: "annotation"
			}
			spec: {
				replicas:    1
				serviceName: "my-postgres"
				template: spec: {
					containers: [{
						name:  "my-postgres"
						image: "postgres:17-alpine"
						ports: [{
							name:          "port-5432"
							containerPort: 5432
							protocol:      "TCP"
						}]
						envFrom: [{secretRef: name: "my-postgres-secret"}]
						volumeMounts: [{
							name:      "my-postgres-pvc"
							mountPath: "/var/lib/postgres/data/pgdata"
						}]
					}]
					volumes: [{
						name: "my-postgres-pvc"
						persistentVolumeClaim: claimName: "my-postgres-pvc"
					}]
				}
			}
		},

		// service
		{
			kind: "Service"
			metadata: close({
				name:      "my-postgres-service"
				namespace: "my-ns"
			})
			spec: {
				ports: [{
					port:       5432
					targetPort: 5432
				}]
				selector: "prodigy9.co/app": "my-postgres"
			}
		},

	],

]
