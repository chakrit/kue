package packs

import (
	"prodigy9.co/defs"
	"prodigy9.co/defs/attr"
)

#WebApp: Self={
	attr.#Metadata
	attr.#Hosts

	#image:        string
	#replicas:     int | *1
	#pull_secret?: string

	// #host: uses attr.#Hosts
	#port:         int
	#gateway_name: string
	#gateway_ns?:  string
	#env: {[string]: string} | *{}
	#command?: [...string]
	#args?: [...string]

	#components: {
		env: defs.#Secret & {
			#type: "Opaque"
			#name: "\(Self.#name)-secret"
			#ns:   Self.#ns
			#data: Self.#env
		}

		deploy: defs.#Deployment & {
			#name: Self.#name
			#ns:   Self.#ns

			if Self.#labels != _|_ {
				#labels: Self.#labels
			}
			if Self.#annotations != _|_ {
				#annotations: Self.#annotations
			}

			#image:    Self.#image
			#replicas: Self.#replicas
			#port:     Self.#port
			#env_from: Self.#components.env.#name

			if Self.#command != _|_ {
				#command: Self.#command
			}
			if Self.#args != _|_ {
				#args: Self.#args
			}
			if Self.#pull_secret != _|_ {
				#pull_secret: Self.#pull_secret
			}
		}

		svc: defs.#Service & {
			#name:     "\(Self.#name)-service"
			#ns:       Self.#ns
			#port:     Self.#port
			#selector: Self.#components.deploy.#out.selector
		}

		route: defs.#HTTPRoute & {
			#name:         "\(Self.#name)-route"
			#ns:           Self.#ns
			#hosts:        Self.#hosts
			#gateway_name: Self.#gateway_name
			if Self.#gateway_ns != _|_ {
				#gateway_ns: Self.#gateway_ns
			}
			#service: Self.#components.svc
		}
	}

	[
		Self.#components.env,
		Self.#components.deploy,
		Self.#components.svc,
		Self.#components.route,
	]

	#out: {
		service_name:    Self.#components.svc.#name
		env_secret_name: Self.#components.env.#name
		selector:        Self.#components.deploy.#out.selector
		route:           Self.#components.route
	}
}

tests: web_app: [

	// barebones
	#WebApp & {
		#name:         "my-app"
		#ns:           "my-ns"
		#image:        "nginx:latest"
		#host:         "my-app.mydomain.com"
		#port:         80
		#gateway_name: "my-gateway"
		#env: {}

		[...]
	} & [{
		data: {}
		_
	}, {_}, {_}, {_}],

	// basic
	#WebApp & {
		#name: "my-app"
		#ns:   "my-ns"

		#image:       "nginx:latest"
		#replicas:    777
		#pull_secret: "my-pull-secret"

		#host:         "my-app.mydomain.com"
		#port:         8080
		#gateway_name: "my-gateway"
		#env: {
			NODE_ENV: "production"
			HOST:     "0.0.0.0"
			PORT:     "8080"
		}

		[...]
	} & [
		{
			type: "Opaque"
			data: close({
				NODE_ENV: "cHJvZHVjdGlvbg=="
				HOST:     "MC4wLjAuMA=="
				PORT:     "ODA4MA=="
			})
		},
		{
			apiVersion: "apps/v1"
			kind:       "Deployment"
			metadata: close({
				name:      "my-app"
				namespace: "my-ns"
			})
			spec: {
				replicas: 777
				selector: close({matchLabels: close({
					"prodigy9.co/part-of": "my-ns"
					"prodigy9.co/app":     "my-app"
				})
				})
				template: {
					metadata: close({labels: close({
						"prodigy9.co/part-of": "my-ns"
						"prodigy9.co/app":     "my-app"
					})
					})
					spec: {
						imagePullSecrets: [close({name: "my-pull-secret"})]
						containers: [{
							name:            "my-app"
							image:           "nginx:latest"
							imagePullPolicy: "Always"
							ports: [{
								name:          "port-8080"
								containerPort: 8080
								protocol:      "TCP"
							}]
							envFrom: [close({secretRef: close({name: "my-app-secret"})})]
						}]
					}
				}
			}
		},
		{
			apiVersion: "v1"
			kind:       "Service"
			metadata: close({
				name:      "my-app-service"
				namespace: "my-ns"
			})
			spec: {
				selector: close({
					"prodigy9.co/part-of": "my-ns"
					"prodigy9.co/app":     "my-app"
				})
				ports: [{
					name:       "tcp-8080"
					protocol:   "TCP"
					port:       8080
					targetPort: 8080
				}]
			}
		},
		{
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "HTTPRoute"
			metadata: close({
				name:      "my-app-route"
				namespace: "my-ns"
			})
			spec: {
				parentRefs: [{name: "my-gateway"}]
				hostnames: ["my-app.mydomain.com"]
				rules: [{
					backendRefs: [{
						name: "my-app-service"
						port: 8080
					}]
				}]
			}
		},
	],

	// basic with outputs
	(#WebApp & {
		#name: "my-app"
		#ns:   "my-ns"

		#image:        "nginx:latest"
		#replicas:     3
		#gateway_name: "my-gateway"

		#host: "my-app.mydomain.com"
		#port: 80
		#env: ENV: "dev"

		[...]
	}).#out & {
		service_name:    "my-app-service"
		env_secret_name: "my-app-secret"
	},

	// multiple hosts
	#WebApp & {
		#name:         "my-app"
		#ns:           "my-ns"
		#image:        "nginx:latest"
		#gateway_name: "my-gateway"
		#hosts: [
			"mydomain.com",
			"www.mydomain.com",
			"my-app.internal.local",
		]
		#port: 8080
		#env: {}
		[...]
	} & [_, _, _, {
		spec: {
			parentRefs: [{name: "my-gateway"}]
			hostnames: [
				"mydomain.com",
				"www.mydomain.com",
				"my-app.internal.local",
			]
			rules: [{
				backendRefs: [{
					name: "my-app-service"
					port: 8080
				}]
			}]
		}

		_
	}],

	// custom command
	#WebApp & {
		#name:         "my-app"
		#ns:           "my-ns"
		#image:        "nginx:latest"
		#host:         "my-app.mydomain.com"
		#port:         80
		#gateway_name: "my-gateway"
		#command: ["/bin/sh", "-c", "npm start"]
		#env: {}

		[...]
	} & [{
		data: {}
		_
	}, {
		spec: template: spec: containers: [{
			command: ["/bin/sh", "-c", "npm start"]
			_
		}]
		_
	}, {_}, {_}],

	// custom command with args
	#WebApp & {
		#name:         "my-app"
		#ns:           "my-ns"
		#image:        "nginx:latest"
		#host:         "my-app.mydomain.com"
		#port:         80
		#gateway_name: "my-gateway"
		#command: ["/bin/sh", "-c"]
		#args: ["npm", "start"]
		#env: {}

		[...]
	} & [{
		data: {}
		_
	}, {
		spec: template: spec: containers: [{
			command: ["/bin/sh", "-c"]
			args: ["npm", "start"]
			_
		}]
		_
	}, {_}, {_}],

]
