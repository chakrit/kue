# Mixins (v0.3)

**Status**: implemented as locked.
**Rationale**:
[`decisions/0001-mixin-design-v0.3.md`](decisions/0001-mixin-design-v0.3.md).

A mixin layers a kind-scoped patch onto an existing pack or raw def. One helper
(`parts.#Mixin`), one authoring shape, one call-site form for both targets.

---

## Mental model

Each mixin declares a map of *additions* — keyed entries pairing a K8s `kind` with a
patch. At unification time, the mixin dispatches via a disjunction over the target's
shape:

- **Pack target** (publishes `#components`, top-level list emit) → list-shape branch.
  The patch lands on every `#components` entry whose `kind` matches.
- **Def target** (pure K8s resource struct, has root `kind`) → struct-shape branch.
  The patch lands at the resource's root.
- **Neither** (target lacks both `#components` and `kind`) → error branch surfaces a
  clear message instead of an "empty disjunction" wall.

Defs and packs keep their v0.2 shapes; mixins changed.

---

## The helper

```cue
parts.#Mixin: Self={
    ...
    #additions: [string]: {
        #kind:  string
        #patch: _
    }

    let _patch = {
        kind: string
        for _, add in Self.#additions {
            if kind == add.#kind {
                add.#patch
            }
        }
        ...
    }

    let listShape = {
        #components: [string]: _patch
        [...]
    }
    let structShape = {
        _patch
        ...
    }

    listShape | structShape | error("#Mixin: target must have #components (pack lists) or kind: string")
}
```

The `_patch` body is written once and embedded twice — as the `#components` pattern
constraint (in `listShape`) and at root (in `structShape`). Bare `kind` resolves to
the entry's own `kind` field at unification. CUE's disjunction picks whichever shape
unifies; `error(...)` only surfaces when neither does.

Trailing `...` at the outer struct level keeps the definition open so it can be
embedded by `#`-prefixed mixin definitions without propagating closure into closed
targets like `defs.#Gateway`.

---

## Authoring a mixin

Embed `#Mixin`, declare params, populate `#additions` with **scoped keys** and a
`let`-bound patch. Localize conditionals to the field site, not the outer block.

```cue
#UseCertManager: Self={
    #Mixin
    #cluster_issuer: string | *"cluster-issuer-main"

    let _patch = {
        metadata: {
            annotations: {
                "cert-manager.io/cluster-issuer": Self.#cluster_issuer
                ...
            }
            ...
        }
        ...
    }

    #additions: cert_gw:  {#kind: "Gateway", #patch: _patch}
    #additions: cert_ing: {#kind: "Ingress", #patch: _patch}
}
```

```cue
#PodResources: Self={
    #Mixin
    #reserved_cpu?: string
    #reserved_mem?: string

    let _patch = {
        spec: {
            template: {
                spec: {
                    containers: [{
                        if Self.#reserved_cpu != _|_ || Self.#reserved_mem != _|_ {
                            resources: requests: {
                                if Self.#reserved_cpu != _|_ { cpu:    Self.#reserved_cpu }
                                if Self.#reserved_mem != _|_ { memory: Self.#reserved_mem }
                            }
                        }
                        ...
                    }]
                    ...
                }
                ...
            }
            ...
        }
        ...
    }

    #additions: resources_dep: {#kind: "Deployment",  #patch: _patch}
    #additions: resources_ss:  {#kind: "StatefulSet", #patch: _patch}
    #additions: resources_ds:  {#kind: "DaemonSet",   #patch: _patch}
}
```

### Conventions

- **Scoped `#additions` keys.** Format: `<mixin_short>_<kind_short>`. Two mixins
  targeting the same kind would clash if both used `deploy:`/`ss:`/`ds:` —
  prefixing isolates them. Conventional shorts: `dep` (Deployment), `ss`
  (StatefulSet), `ds` (DaemonSet), `gw` (Gateway), `ing` (Ingress).
- **Localized guards.** Conditionals (`if Self.#x != _|_`) live at the field's
  emission site, not wrapping the entire patch. Each level inside a patch needs
  trailing `...` so unification stays open.
- **Required `...` at every level.** Every nested struct in `_patch` must end
  with `...`. The mixin patches into closed defs and packs; without explicit
  openness at every level, CUE rejects fields the patch doesn't mention.

---

## Call site

Mixin authors write **one** mixin — the `#Mixin` helper handles both targets via
internal disjunction dispatch. Call sites differ only in that pack targets need a
trailing `[...]` in the parameter struct (list-shape compat); raw def targets
don't.

```cue
my_def  & parts.#UseCertManager & {#cluster_issuer: "letsencrypt-prod"}
my_pack & parts.#PodResources   & {#reserved_cpu: "200m", [...]}
```

Multiple mixins compose by chaining `&`. Each mixin contributes additions under
**unique scoped keys**; the `#additions` map merges cleanly across composition.

```cue
my_pack
    & parts.#UseCertManager & {#cluster_issuer: "letsencrypt-prod"}
    & parts.#UseKeel
    & parts.#PodResources   & {#reserved_cpu: "200m", [...]}
```

### Composition: two mixins on the same kind

`#UseKeel` and `#PodResources` both target `Deployment`. With scoped keys
(`keel_dep` vs `resources_dep`), both patches land cleanly on the same target:

```cue
my_deploy
    & parts.#UseKeel
    & parts.#PodResources & {#reserved_cpu: "100m"}
// → metadata.annotations gets keel.sh/* annotations
// → spec.template.spec.containers[0].resources.requests.cpu = "100m"
```

If either mixin used the unscoped `deploy:` key, the second `&` would conflict on
the `#additions.deploy` field and unification would fail.

---

## Available mixins (v0.3)

| Mixin                   | Kinds                              | `#additions` keys                                | Effect                                                                                        |
| ----------------------- | ---------------------------------- | ------------------------------------------------ | --------------------------------------------------------------------------------------------- |
| `parts.#UseCertManager` | Gateway, Ingress                   | `cert_gw`, `cert_ing`                            | injects `cert-manager.io/cluster-issuer` annotation                                           |
| `parts.#UseKeel`        | Deployment, StatefulSet, DaemonSet | `keel_dep`, `keel_ss`, `keel_ds`                 | injects `keel.sh/policy` + `keel.sh/match-tag` annotations                                    |
| `parts.#PodResources`   | Deployment, StatefulSet, DaemonSet | `resources_dep`, `resources_ss`, `resources_ds`  | sets `spec.template.spec.containers[].resources.requests`                                     |
| `parts.#PodTolerations` | Deployment, StatefulSet, DaemonSet | `tolerations_dep`, `tolerations_ss`, `tolerations_ds` | sets `spec.template.spec.tolerations`                                                       |
| `parts.#NodeAffinity`   | Deployment, StatefulSet, DaemonSet | `affinity_dep`, `affinity_ss`, `affinity_ds`     | sets `spec.template.spec.affinity.nodeAffinity`                                               |
| `parts.#PodMounts`      | Deployment, StatefulSet, DaemonSet | `mounts_dep`, `mounts_ss`, `mounts_ds`           | sets `spec.template.spec.{volumes, containers[].volumeMounts, initContainers[].volumeMounts}` |

---

## Openness requirement

Mixin patches inject fields into existing resource structs. The target's nested
K8s structs MUST be open with `...` for the patch to unify. See
[`defs-and-packs.md`](defs-and-packs.md#openness-rule-required-for-mixin-compatibility)
for the rule and the audit scope.

---

## v0.2 → v0.3 migration

**Breaking**:

- `parts.#X.#Direct` sub-form removed. Single uniform `parts.#X` form works on
  both raw defs and packs via disjunction dispatch.
- `parts.#PodResources`, `parts.#PodTolerations`, `parts.#NodeAffinity` drop their
  `[...] | {...}` dual-mode shape.
- `parts.#UseKeel` no longer overlays via the loose `_` form. Re-authored as a
  `#Mixin`-based entry like the others.

**Non-breaking**:

- `parts.#PodResources` / `#PodTolerations` / `#NodeAffinity` now work uniformly
  on `packs.#Postgres` and `packs.#Redis` (these were broken in v0.2).
- Pack and def shapes are unchanged. Downstream consumers don't have to update
  their pack/def usage.
- The `#components`-map migration of existing packs
  (`web_app`/`postgres`/`redis`/`basics`) is no longer required for mixin
  compatibility. Migrate for clarity, not necessity.

---

## Pack list-emit constraint

Packs that conditionally add to `#components` MUST use a list comprehension, not
hand-listed indices, when emitting the top-level list:

```cue
// ✅ works — disjunction-friendly
[for _, c in Self.#components {c}]

// ❌ closure leaks under disjunction dispatch
[
    Self.#components.gateway,
    Self.#components.redirect,
    if cond { Self.#components.rg },
]
```

The hand-listed form combined with a conditional `if cond { #components: rg: ... }`
add trips a closure leak in evalv3 — the mixin's pattern constraint evaluates against
a stale view of `#components` and retroactively closes other entries. The
comprehension form iterates whatever ended up in `#components` and produces the same
ordering deterministically.

---

## See also

- [`decisions/0001-mixin-design-v0.3.md`](decisions/0001-mixin-design-v0.3.md) —
  design rationale, alternatives considered, spike receipts.
- [`defs-and-packs.md`](defs-and-packs.md) — openness rule the mixins depend on.
