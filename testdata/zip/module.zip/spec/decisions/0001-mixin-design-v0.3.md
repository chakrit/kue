# Mixin Design — v0.3

**Status**: **IMPLEMENTED AS LOCKED** — disjunction dispatch shipped 2026-05-02 (commit `b39fa85`). The earlier if-branch divergence is documented in the session log; the locked design itself was correct as recorded.
**Started**: 2026-05-01.
**Locked**: 2026-05-02.
**Shipped**: 2026-05-02.
**Drives**: `parts/` refactor for v0.3 release.
**Spec**: [`../mixins.md`](../mixins.md).

Historical record. Captures every learning so future sessions don't re-spike.
Spike code lived at `spike/` during design — gitignored, not committed; the
patterns and conclusions are inline below, and the final working forms are in
[`../mixins.md`](../mixins.md). Phase 5 cleanup may delete the local directory
entirely.

---

## Why we're doing this

v0.2 ships **four incompatible mixin shapes**, none of them uniform:

| Mixin                                                                   | Shape                                                                                                              | Works on                                                                                | Pain                                                                                                  |
| ----------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| `parts.#UseCertManager`                                                 | discriminator-disjunction `_target` + trailing `[...]`, plus separate `.#Direct` sub-form                          | packs publishing `#components`; raw defs via `.Direct`                                  | two flavors authored by hand; pass-through arm enumerates excluded kinds                              |
| `parts.#UseKeel`                                                        | uniform overlay with trailing `_`                                                                                  | anything embedding `#Metadata`                                                          | loose; `_` discards shape safety                                                                      |
| `parts.#PodResources`, `parts.#PodTolerations`, `parts.#NodeAffinity`   | top-level `[...] \| {...}`, list arm hardcoded to WebApp's 4-element shape, patch at index 1                       | `packs.#WebApp` only (pack arm); `defs.#Deployment` / `#PodController` (struct arm)     | **broken on Postgres/Redis** (wrong arity); pack shape leaks into mixin                               |
| `parts.#PodMounts`                                                      | direct-only struct overlay on `spec.template.spec`                                                                 | applied inside packs at the def level (e.g. `packs/postgres.cue:55`)                    | doesn't compose at the pack call site at all                                                          |

Root fault: list-shape compatibility was a forcing function. Whenever a mixin
tried to apply both at the pack-list level *and* at the def level, the author
baked the pack shape into the mixin.

Symptom we want to kill: "PodResources doesn't work on Postgres."

---

## Final design

`parts.#Mixin` — 20 lines, single dispatch body, two embedding sites,
disjunction-based shape selection:

```cue
parts.#Mixin: Self={
    #additions: [string]: {
        #kind:  string
        #patch: _
    }

    let patch = {
        kind: string

        for _, add in Self.#additions {
            if kind == add.#kind {
                add.#patch
            }
        }

        ...
    }

    let listShape = {
        #components: [string]: patch
        [...]
    }

    let structShape = {
        patch
        ...
    }

    listShape | structShape
}
```

Mixin authors embed `parts.#Mixin` and populate `#additions: <name>: {#kind,
#patch}`. Composition merges the maps under unique keys. Defs and packs keep
their v0.2 shapes — only mixins change. Full reference in
[`../mixins.md`](../mixins.md).

---

## Hard CUE constraints (evalv3, v0.15.4)

Confirmed by spikes. Do not re-litigate.

- **No package-self iteration.** Cannot iterate over the package's own top-level
  fields from within. Cross-file collection requires writing into a shared
  struct (e.g. `#apps: [string]: string`).
- **No variadic struct unification.** `&` is binary; CUE has no `list.UnifyAll`.
  `#merge & [a, b, c]` cannot be implemented over an arbitrary list. The
  natural primitive *is* `&`. Wrap with `let` for naming. (Spike 4.)
- **List-vs-struct duality is permanent.** A value's primary shape is list OR
  struct, not both. Caller param structs need a trailing `[...]` to be
  dual-shape-compatible when unifying with list-shape packs. (Spikes 3C, 5.)
- **Full self-reference cycles.** `#components: this: Self` errors with
  `structural cycle`. Workarounds exist (let-binding to extract a resource
  shape and embed it twice — spike 3B), but the polymorphic-mixin design
  obviates the need. (Spikes 3A, 3B.)
- **Pattern-constraint scoping.** Inside `[string]: {…}`, identifiers either
  resolve to the entry via `Self=`/`Inner=` aliasing (spike 1) or — when the
  pattern body declares a field of the same name — bind to that field
  (spike 14, where `kind: string` makes bare `kind` resolve to the entry's
  kind).
- **Disjunction shape-selection works.** The CLAUDE.md note flagging
  `({...} | [...])` as unstable for params-via-`&` is **not** a blanket
  restriction — it doesn't apply to the
  `let listShape = {…, [...]}; let structShape = {…}; listShape | structShape`
  pattern. CUE evalv3 0.15.4 disambiguates cleanly because each branch's shape
  contradicts the other under unification. (Spike 13, 14.)
- **CUE 0.16.1 panics** on the existing `parts/` package. v0.3 stays on 0.15.4
  until that's fixed upstream.

---

## Spike results

All in `spike/` (one file per spike, package `spike`). Run via
`./cue-fmt.sh && ./cue-check.sh && ./cue-test.sh`.

| #   | File                            | What it tests                                                                                                                  | Result        | Conclusion                                                                                          |
| --- | ------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ | ------------- | --------------------------------------------------------------------------------------------------- |
|  1  | `01_self_alias_pattern.cue`     | `Self={…}` + `if Self.kind == "X"` inside `[string]:` pattern                                                                  | ✅            | drops the `kind: !="X" & !="Y"` pass-through arm                                                    |
|  2  | `02_onkinds_helper.cue`         | early helper: for-loop over `Outer.#kinds` injects `Outer.#patch` into matching entries                                        | ✅            | feasibility of a shared dispatch helper                                                             |
|  3  | `03_self_reference.cue`         | (3A) full `Self` self-ref / (3B) let-binding workaround / (3C) `_AsPack & {#it: …}` wrapper                                    | 3A ❌ / 3B,3C ✅ | Option D infeasible cleanly; 3C requires same `[...]` ceremony as `.Direct` — no win                |
|  4  | `04_optional_mixin.cue`         | straight `&` / `let`-pre-bound mixin / named bundle via `&`                                                                    | ✅ × 3        | `&` is the merger; `#merge` adds nothing                                                            |
|  5  | `05_shim.cue`                   | `_Shim` protocol marker (`#components: [string]: _` + `[...]`)                                                                 | ✅            | naming-only; doesn't raise abstraction — **rejected as noise**                                      |
|  6  | `06_deep_patch.cue`             | one helper applied with deep `PodResources`-shaped patch on Deployment AND StatefulSet across two packs                        | ✅ × 2        | one helper covers annotation mixins AND per-resource pod config — false dichotomy of "two patterns" |
|  7  | `07_optional_path.cue`          | optional-path constraint (`#components?: gateway?: …`) fires only when path exists                                             | ✅ × 2        | viable but trades robustness for simplicity — kind-routed is more robust                            |
|  8  | (removed)                       | embed + list emit conflict — superseded; user's `#components.X` embed pattern is cleaner                                       | dropped       | n/a                                                                                                 |
|  9  | `09_user_pattern_def.cue`       | user's def pattern (`#components.deployment` embed) with polymorphic mixin (`if Self.#components` / `if Self.kind`)             | ✅            | polymorphic dispatch works on raw defs                                                              |
| 10  | `10_user_pattern_pack.cue`      | same polymorphic mixin on multi-resource pack via struct-shape with `#out.list`                                                | ✅            | rejected later — pack stays list per user direction                                                 |
| 11  | `11_two_mixins.cue`             | two mixins composed; `#kinds` field clash resolved by keyed map (`_patches: <name>: {kinds, patch}`)                           | ✅            | composition-safe; map keys merge across mixins                                                      |
| 12  | `12_polymorphic_mixin.cue`      | `if Self.#components`/`if Self.kind` branches with `[...]` gated inside the components branch; defs as pure-struct K8s         | ✅ × 3        | one form for both targets; defs unchanged from v0.2; packs unchanged from v0.2                      |
| 13  | `13_disjunction_mixin.cue`      | `(listShape | structShape)` replaces if-branches                                                                               | ✅ × 3        | disjunction disambiguates cleanly in evalv3 0.15.4 — old CLAUDE.md concern superseded               |
| 14  | `14_extracted_patch.cue`        | dispatch body extracted into `let patch`, embedded twice (in `#components` pattern and at struct root); bare `kind` resolves   | ✅ × 3        | final shape — 20 lines, single dispatch body                                                        |

---

## Decisions

### D1. Mixin substrate: `parts.#Mixin` with `#additions` map

The mixin author surface is a single map keyed by addition name:

```cue
#additions: [string]: {
    #kind:  string
    #patch: _
}
```

Each entry pairs one K8s `kind` with one `#patch`. Mixins targeting multiple
kinds with a shared patch use a `let`-bound patch and one addition per kind.

Composition: two mixins composed via `&` contribute additions under unique map
keys; the merged map is iterated by the dispatch. No clash on shared
`#kinds`/`#patch` fields.

### D2. Polymorphic shape selection via disjunction

The mixin's value is `listShape | structShape`:

- `listShape` carries `[...]` and a `#components: [string]: patch` constraint —
  matches list-shape packs.
- `structShape` carries `patch` at root — matches struct-shape raw defs.

CUE picks the branch that unifies with the target. No `if Self.X != _|_`
checks; CUE's disjunction elimination drives the dispatch.

### D3. Patch dispatch is written once

```cue
let patch = {
    kind: string

    for _, add in Self.#additions {
        if kind == add.#kind {
            add.#patch
        }
    }

    ...
}
```

Embedded twice — as the `#components` pattern constraint (in `listShape`) and
at root (in `structShape`). Single body, two embedding sites. Bare `kind`
resolves to the patch struct's own `kind: string` field at unification.

### D4. Defs and packs keep their v0.2 shapes

- **Defs**: pure K8s resource structs at root (no `#components` publishing
  required). Caller wraps `[def]` for YAML emission, same as v0.2.
- **Packs**: list-shape with top-level `[Self.#components.X, …]` emit, same as
  v0.2.

The polymorphic mixin handles both shapes via disjunction. No trivial pack
wrappers, no `.Direct` sub-form, no ABI break for downstream.

### D5. `packs.#Shim` rejected

A naming-only marker that doesn't raise abstraction is noise. Spike 5
confirmed the protocol mechanically but added nothing the `#components`
convention doesn't already imply.

### D6. `#components` migration of existing packs is optional

The original v0.3 wishlist mandated migrating
`packs.#{web_app, postgres, redis, basics}` to publish a `#components` map.
With the polymorphic mixin, this is no longer required for mixin compatibility
— mixins work on the existing list-emit shape too. Migrate if desired for
internal clarity, not necessity.

---

## Iteration log

The design didn't land in one shot. Recording the pivots so future sessions
know what was tried.

1. **Initial sketch** — `parts.#Mixin & {#kinds: [...string], #patch: {…}}`.
   Issue surfaced quickly: composing two mixins clashes on the shared
   `#kinds` field (`["A"] & ["B"]` = `_|_`).
2. **Keyed map** — `_patches: <name>: {kinds, patch}` (spike 11). Map keys
   merge cleanly across composition.
3. **Public-facing rename** — `#additions` over `_patches` (`#`-prefix matches
   the convention for user-input fields).
4. **Singular `#kind`** — split plural `#kinds: [...string]` into one entry per
   kind. More uniform per-entry semantics, slightly more verbose for
   multi-kind mixins (resolved via `let`-bound patches).
5. **Polymorphic shape via if-branches** — `if Self.#components != _|_` and
   `if Self.kind != _|_` blocks (spike 12). Works but ungainly.
6. **Disjunction replaces if-branches** — `listShape | structShape` (spike 13).
   CUE picks the matching shape; cleaner than the if-checks.
7. **Extracted patch body** — single `let patch = {…}` embedded in both
   shapes (spike 14). Final form.

Along the way: rejected `#out.list` pack restructuring (Option C variant — pack
stays list per user direction), rejected `#components: this: Self` defs
(Option D — structural cycle), rejected the `.Direct` sub-form (no longer
needed once polymorphic dispatch handles raw defs).

---

## Alternatives rejected

### Option A — small cleanup, no API change

Subset of the chosen design. Migrate to `#components`, kill dual-mode, keep
manual disjunction. Rejected: leaves the disjunction verbosity in place when
the `parts.#Mixin` helper demonstrably removes it.

### Option C — forward-as-param (in any form)

Mixin params become pack fields; pack forwards into the right resource.
Initially proposed for "per-resource" mixins (PodResources etc.), then
generalized. Rejected:

- Reverse dependency — pack/def must know about every mixin that may target it.
- Adding a new mixin requires touching every pack that wants it.
- Spike 6 proved the polymorphic mixin handles deep patches uniformly, so the
  split was a false dichotomy.

User feedback: "this option sucks, we can't easily add new parts to existing
packs/defs because of the reversed dependency."

### Option D — every def is a one-component pack

`defs.#X` self-publishes `#components: this: Self`, mixins always operate on
`#components`, no `.Direct` needed.

Rejected:

- Full `Self` self-reference cycles in evalv3 (spike 3A).
- Let-binding workaround works (spike 3B) but every def grows boilerplate for
  marginal gain — and the polymorphic mixin obviates the need entirely.
- Wrapper helper still needs `[...]` ceremony at the call site (spike 3C) — no
  better than `.Direct`.
- Making raw defs list-shape would change the ABI for all existing
  `"file.yaml": [defs.#X & {…}]` downstream usage.

### Option N — optional-path mixin

Mixin enumerates canonical component names (`#components?: gateway?: …`); CUE's
optional-path semantics no-op when the path is absent. Spike 7 confirmed it
works, but:

- requires strict canonical naming convention across all packs;
- breaks for multi-instance kinds (e.g., two Gateways in one pack);
- mixin code grows linearly with target paths to enumerate;
- component names become a hidden API surface (rename = break).

Kind-routed dispatch is more robust. Filed for future special-case use.

### Option O — capability tags on defs

Defs publish `_accepts_X: true` tags; mixin reads them. Rejected: same
reverse-dependency smell as Option C. Defs would have to know about every
mixin that might target them.

### `#merger` value-as-function

User idea: `let gwWithCM = #merge & [gw, cm]`. Rejected: CUE has no variadic
struct unification (spike 4). The natural CUE primitive is `&`. Wrap with
`let` for naming intermediate compositions.

### `packs.#Shim` as marker

User idea: every pack embeds `packs.#Shim`, becoming uniformly mixin-aware.
Spike 5 confirmed it works, but the shim adds nothing the `#components`
convention doesn't already imply. User feedback: "pointless noise."

### `#out.list` pack restructuring

Considered moving the pack's resource list from a top-level emit into
`#out.list` (so packs become struct-shape, mixin needs no `[...]`). User
feedback: "Pack MUST stay lists. `#out` is just ugly. That was defs v0 that we
went away from. I don't want to go back there again." Rejected.

---

## Implementation phases

1. **`parts.#Mixin`** — write the helper (~20 lines) + tests. Validate against
   the existing six mixins' shapes.
2. **Mixin migration** — convert `parts.#{UseCertManager, UseKeel, PodResources,
   PodTolerations, NodeAffinity, PodMounts}` to the `parts.#Mixin`-based form.
   Drop `.#Direct`, drop `[...] | {...}` dual-mode.
3. **Defs openness audit** — read every `defs/*.cue` and add `...` where a
   nested K8s struct lacks it (especially `metadata`, `spec` and below). Spike
   11 caught one instance (closed `metadata`); v0.2 likely has more.
4. **Pack `#components` migration (optional)** — `web_app`/`postgres`/`redis`/
   `basics` to publish `#components` for clarity. Not blocking — mixins work
   without it.
5. **Cleanup** — remove obsolete `_target`, dual-mode arms, `.#Direct`
   sub-forms, README/skill doc updates, drop `spike/` directory.

Each phase commits independently with `defs:` prefix.

---

## Session log

- **2026-05-01 (initial)** — options A/B/C/D plus user's `#merger` and `#Shim`
  ideas laid out. Spikes 1–5 run. Provisional: two patterns (D5),
  `.Direct` retained (D6), `#Shim` as marker (D7).
- **2026-05-01 (revision)** — user pushback on multiple counts. Spike 6
  proved one pattern works (deep `#patch` covers pod config). Spike 7
  showed Option N viable but less robust. `#Shim` rejected as noise.
- **2026-05-01 (lock #1)** — helper named `parts.#Mixin`. `.Direct` dropped
  via "mixin-target = pack" convention. Trivial pack wrappers planned for
  `#Deployment`, `#StatefulSet`, `#DaemonSet`, `#Ingress`.
- **2026-05-02 (composition fix)** — user flagged the `#kinds` clash on
  composition. Spike 11 introduced keyed map (`_patches`), then renamed to
  `#additions` per user. Polymorphic mixin via if-branches landed
  (spike 12) — defs and packs keep v0.2 shapes; trivial pack wrappers no
  longer needed.
- **2026-05-02 (final)** — user proposed `(listShape | structShape)`
  disjunction (spike 13) and extracted-patch refinement (spike 14). Both
  pass. Final design locked.
- **2026-05-02 (implementation)** — design hit two CUE evalv3 0.15.4
  errors that the spikes (which used hidden lowercase structs and
  hidden targets) didn't surface:
  1. `#Mixin` (definition) appeared to propagate closure into closed
     targets (`defs.#Gateway`, etc.), rejecting fields the patch doesn't
     mention even with `...` everywhere. Switched to `_Mixin` (hidden).
  2. `listShape | structShape` disjunction appeared to fail to collapse —
     both branches survived against closed defs, producing "field not
     allowed" at every level. Reverted to spike-12's two `if` branches
     gated on `Self.#components` / `Self.kind` presence.
  Authoring shape and call-site shape unchanged from spec — only helper
  internals differ. Specs (`mixins.md`) updated to reflect actual code.
- **2026-05-02 (post-impl bug report)** — user filed
  `v0.3-mixin-bugs.md`: two silent no-ops in the if-branch
  implementation. Bug 1 — `packs.#Gateway & parts.#UseCertManager`
  patches don't reach `#components.gateway`. Bug 2 — list-shape mixin
  dispatch on `packs.#WebApp`-style packs silently drops every patch.
  Both bugs reproduce; pack self-tests pass vacuously because they
  unify expected literal lists onto pack output (the assertion adds
  the missing field rather than detecting its absence — CLAUDE.md
  already documents this `close + literal` pitfall).
- **2026-05-02 (root-cause investigation, supersedes implementation
  notes above)** — empirical re-investigation in `_probe/` (probes
  `min2.cue`, `compare2.cue`, `compare3.cue`, `disj_v2.cue`,
  `error_demo.cue`):
  1. **The if-branch list-shape dispatch is broken** by an evalv3
     phasing bug. The pattern constraint `#components: [string]:
     Inner={ kind: string; for _, add in Self.#additions {…}; … }`
     installs lazily inside the `if Self.#components != _|_ { … }`
     block; at activation time, the for-comprehension's view of
     `Self.#additions` is stale and iterates zero times. Silent
     no-op, no error. The struct-shape branch (top-level for-loop in
     its if-block) does NOT have this bug — only nested-for-inside-
     pattern-constraint-inside-if hits it. This is the root cause of
     both reported bugs.
  2. **The original disjunction rejection was wrong.** Re-tested in
     `_probe/disj_v2.cue` with correctly-structured `_patch` (i.e.
     trailing `...` at every nested level): disjunction works for ALL
     four combinations — struct-shape × raw struct, struct-shape ×
     closed `defs.#Deployment`, list-shape × raw struct components,
     list-shape × closed-def components. The "field not allowed"
     error that drove the implementation-time switch to if-branches
     was a misleading downstream symptom: the test patch was written
     with path-shorthand (`spec: template: spec: x: …, …`) which
     puts `...` only at the OUTERMOST level, leaving `spec`,
     `template`, intermediate `spec` closed. Closure leaked UP into
     `parts.#PodController`'s spec, retroactively closing it and
     rejecting its own legitimately-defined `selector` and
     `revisionHistoryLimit`. CUE pointed at PodController; the bug
     was in the patch struct several layers away. Same misleading
     mechanism caused the `#Mixin → _Mixin` switch — neither change
     was needed for the reason recorded.
  3. **CUE error messages are unreliable.** Generalized this finding
     into a CLAUDE.md rule and a memory entry. Strategic `error()`
     calls (shape assertion before disjunction, post-dispatch
     unmatched-input check) verified in `_probe/error_demo.cue` —
     they short-circuit wrong unification paths and surface the real
     cause instead of letting evalv3 produce misleading downstream
     errors.

  **Pending fix (separate session):** revert to the locked
  disjunction design (D2/D3 above), keep `_Mixin` hidden form (the
  `#Mixin` switch was driven by the same misleading-error class —
  retest, but low priority), add the two strategic `error()` guards,
  fix the vacuous list-shape mixin tests so absence of patch fails
  loudly. The locked design itself is correct as recorded; the
  implementation just diverged from it on bad evidence.
- **2026-05-02 (revert shipped, commit `b39fa85`)** — locked design
  shipped. Helper is `parts.#Mixin` (definition with trailing `...`
  to keep it open) using the
  `listShape | structShape | error("...")` disjunction; the third
  branch surfaces a clear message when the target has neither
  `#components` nor a root `kind`. The `#Mixin` retest passed —
  the original `#Mixin → _Mixin` switch was indeed misleading-error
  driven. Two collateral fixes surfaced and shipped in the same
  commit:
  1. **`packs.#Gateway` list emit.** The hand-listed
     `[Self.#components.gateway, Self.#components.redirect, if cond {Self.#components.rg}]`
     paired with the conditional `if cond { #components: rg: ... }`
     add trips a closure leak under disjunction dispatch (isolated
     in `_probe/repro.cue` variants V1-V8). Switched to
     `[for _, c in Self.#components {c}]`. The CLAUDE.md note
     claiming `[for x in ...]` "silently breaks mixin routing in
     evalv3" was an artifact of the if-branch dispatch era and
     does not apply under disjunction.
  2. **`parts.#PodMounts` cycle.** The let-bound aggregate
     `let _has_mounts = Self.#mount_pvc != _|_ || ...` cycles under
     disjunction dispatch when referenced from within `_patch`.
     Replaced with inline `Self.#mount_* != _|_` checks at each
     emission site. No semantic change.

  The post-dispatch unmatched-input check from the earlier root-
  cause investigation was NOT shipped: multi-kind mixins like
  `#UseCertManager` (Gateway + Ingress) legitimately have
  additions that don't match every target. The check would
  reject a Gateway-only pack composed with `#UseCertManager`.
  Only the shape-assertion (third disjunction branch) ships.
- **2026-05-02 (post-impl)** — user flagged two design holes surfaced by
  the implementation:
  1. Outer-block guards in `_patch` (e.g. `if Self.#reserved_cpu != _|_ {
     spec: ... }`) make typoed inputs silently no-op. Moved guards to the
     field's emission site (e.g. inside `requests: {}` for cpu/mem) so
     unaffected paths emit cleanly and typos at least produce empty
     output instead of structured noise.
  2. `#additions` keys `deploy`/`ss`/`ds`/`gw`/`ing` clash when two
     mixins target the same kind (`my_pack & #UseKeel & #PodResources`
     both wrote `#additions.deploy`). Switched to scoped keys
     (`<mixin>_<kind>` — e.g. `keel_dep`, `resources_dep`).
