# Decision Records

Architecture decision records (ADRs) for `prodigy9.co/defs`. One file
per decision. Each captures the problem, options considered, spike
results, and the locked outcome.

## Index

| #                                 | Title                | Status | Drives                            |
| --------------------------------- | -------------------- | ------ | --------------------------------- |
| [0001](0001-mixin-design-v0.3.md) | Mixin design (v0.3) | Locked | [`spec/mixins.md`](../mixins.md) |

## Conventions

- Numbered chronologically: `0001-`, `0002-`, …
- Slug describes the topic — short, kebab-case.
- Status: `Open` (in design) → `Locked` (final, implementation pending
  or done) → `Superseded by NNNN` (replaced).
- Each record carries a session log so future sessions can pick up
  context without re-spiking.
- Once locked, the resulting API ships at `spec/<topic>.md`. The
  decision record stays as the historical "why."
