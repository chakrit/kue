# Spec

Design specs and decision records for the `prodigy9.co/defs` framework.

## Specs

Living reference docs for framework APIs and contracts.

| Doc                                 | Status                                                  |
| ----------------------------------- | ------------------------------------------------------- |
| [Defs and Packs](defs-and-packs.md) | partial (openness rule locked; rest TBD during phase-1) |
| [Mixins](mixins.md)                 | v0.3 design locked; implementation pending              |

## Decision records

History — the *why* behind significant design choices.

See [`decisions/`](decisions/) for the full log.

| #                                           | Title                | Status |
| ------------------------------------------- | -------------------- | ------ |
| [0001](decisions/0001-mixin-design-v0.3.md) | Mixin design (v0.3) | Locked |

## Conventions

- Specs live at `spec/<topic>.md`. One file per topic. Specs describe
  the *current* API; they do not document history.
- Decisions live at `spec/decisions/NNNN-<slug>.md`. Each decision
  captures one significant choice — the problem, options considered,
  spike results, final shape. Numbered chronologically.
- Each spec links to its driving decision record. Each decision links
  to the resulting spec once locked.
