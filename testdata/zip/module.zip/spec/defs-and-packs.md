# Defs and Packs

**Status**: openness rule locked; rest expands during implementation.
**Related**: [`mixins.md`](mixins.md) — consumes the openness rule below.

The framework has four layers, bottom-up:

- `attr.#X` — reusable input fragments (`#Metadata`, `#Hosts`, `#Ports`,
  `#Probe` family). Embedded via `&` into defs and parts.
- `parts.#X` — two roles: shared base patterns (`#PodController`, `#Metadata`)
  embedded into defs; and mixins (`#UseCertManager`, `#PodResources`, …)
  composed at the call site per [`mixins.md`](mixins.md).
- `defs.#X` — thin K8s resource wrappers, one per kind, in `package defs` at
  the repo root.
- `packs.#X` — blueprints in `package packs` under `packs/`. Each bundles
  multiple defs into an emitted list.

---

## Defs (`package defs`)

### Conventions

- One `.cue` file per K8s kind, at the repo root.
- Definition name matches the K8s `kind` exactly: `defs.#Deployment`,
  `defs.#HTTPRoute`, `defs.#Gateway`, `defs.#ReferenceGrant`.
- Input fields use `#snake_case` (`#name`, `#ns`, `#image`, `#pull_secret`,
  `#cluster_issuer`).
- Embed `attr.#X` and `parts.#X` to share input shape and base construction
  with siblings.
- Caller-facing derived values go under `#out`.
- Defs are **pure K8s resource structs at root** — they do not publish
  `#components`. The polymorphic mixin handles them via its struct-shape
  branch (see [`mixins.md`](mixins.md)).

### Openness rule (REQUIRED for mixin compatibility)

Defs MUST leave the K8s `spec`, `metadata`, and any other nested struct a
mixin patch may reach into open with `...`. Mixins inject fields by unifying a
deep patch into the target; a closed struct anywhere along that path breaks
the mixin.

```cue
// CORRECT
defs.#Deployment: Self={
    parts.#Metadata
    apiVersion: "apps/v1"
    kind:       "Deployment"
    spec: {
        template: {
            spec: {
                containers: [{
                    name:  Self.#name
                    image: Self.#image
                    ...                  // for resources, volumeMounts, …
                }]
                ...                      // for volumes, tolerations, affinity, …
            }
            ...
        }
        ...
    }
    ...
}
```

`metadata` also needs `...` for cert-manager / keel annotation patches —
spike 11 caught one closed-`metadata` instance during design. Phase-1
implementation includes an audit of every `defs/*.cue` to ensure every nested
K8s struct mixins might reach carries the trailing `...`.

---

## Packs (`package packs`)

### Conventions

- One `.cue` file per pack, in `packs/`.
- Pack name is semantic (`#WebApp`, `#Postgres`, `#Basics`, `#Gateway`).
- Pack value is a **list** at top level — `pack` IS the resource list. Caller
  writes `"file.yaml": pack` directly.
- Pack emission references `#components` paths when the pack publishes a
  `#components` map (recommended for clarity), or uses `let`-bound resources
  (current v0.2 shape).

```cue
// Recommended (publishes #components — clearer for mixin routing):
packs.#Gateway: Self={
    #components: gateway:  defs.#Gateway   & {…}
    #components: redirect: { … }

    [Self.#components.gateway, Self.#components.redirect]
}

// Also valid (current v0.2 shape — let-bound resources):
packs.#WebApp: Self={
    let env    = defs.#Secret     & {…}
    let deploy = defs.#Deployment & {…}
    let svc    = defs.#Service    & {…}

    [env, deploy, svc]
}
```

Both shapes work with the polymorphic mixin. The `#components`-map shape is
preferred for new packs and for migrations because it makes the pack's
internal structure explicit and aids mixin debugging — but it's not required
for mixin compatibility.

### Forbidden at the top-level list emission

Per evalv3 gotchas (confirmed in CLAUDE.md):

- `list.Concat(...)` — silently breaks mixin routing.
- `[for x in … { x }]` re-emit — same problem.
- Direct assignment of unset `[...T]` fields — stays incomplete and errors at
  `cue eval --concrete`.

Path references and `let`-bound resource references are the only safe forms.

---

## TBD (lock during implementation)

- **Defs openness audit** — read every `defs/*.cue` and add `...` where any
  nested K8s struct mixins might reach is closed. Spike 11 confirmed
  `metadata` needs `...` for annotation mixins; `spec` and below for
  pod-shape mixins.
- **`#components` map migration of existing packs** — `web_app`, `postgres`,
  `redis`, `basics`. Optional (mixins work either way). Migrate for clarity,
  not necessity.
- Whether `parts.#Metadata` needs adjustment for the `#components` model.
  Current pattern (writes `metadata.{name, namespace, labels, annotations}`
  based on `#`-prefixed inputs) likely works as-is — verify, don't refactor
  preemptively.

---

## See also

- [`mixins.md`](mixins.md) — mixin spec (consumes this spec's openness rule).
- [`decisions/0001-mixin-design-v0.3.md`](decisions/0001-mixin-design-v0.3.md)
  — v0.3 mixin design rationale.
