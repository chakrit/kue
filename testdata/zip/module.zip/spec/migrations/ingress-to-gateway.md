# Ingress → Gateway API Migration (NGINX Gateway Fabric)

> Spec-archive copy. Operational guidance preserved here so design
> discussions on this repo can reference framework-induced gotchas.
> Applies unchanged to both v0.2 and v0.3 — no framework-side change in
> the Ingress/Gateway path between those versions.

This is a one-time per-cluster migration. Every gotcha below has bitten us in
production at least once — read before starting, not while debugging.

For the orchestration layer (phase plan, cutover sequence, rollback per phase),
see [ingress-to-gateway-rollout.md](ingress-to-gateway-rollout.md). This file
is the *what* and *why*; that one is the *order*.

## Apply order

1. Install the NGF release bundle (CRDs + controller + GatewayClass + NginxProxy).
   Single `kubectl apply -f <bundle>` or `helm install` — order within the bundle
   doesn't matter; kubectl resolves it.
2. **Verify wiring before creating any Gateway:**
   ```sh
   kubectl get gatewayclass <name> -o jsonpath='{.spec.parametersRef}{"\n"}'
   kubectl get nginxproxy -A -o jsonpath='{.items[*].spec.serverTokens}{"\n"}'
   ```
   First must be non-empty (controller will silently ignore the NginxProxy if
   `parametersRef` isn't wired). Second must print `off` — see bug below.
3. Apply your `Gateway` + `HTTPRoute` manifests.

## Known bugs and traps

### NGF 2.5.x `server_tokens` default-render bug

Symptom: Gateway listeners stuck `Programmed: False` with
`failed to parse config invalid number of arguments in "server_tokens" directive`.
Root cause: an unset `NginxProxy.spec.serverTokens` renders bare `server_tokens ;`
(zero args), failing nginx's parser.

Workaround: explicit `serverTokens: "off"` on the NginxProxy.

### Partial `kubectl apply` strands `parametersRef`

If a previous apply used a stale copy of the NGF manifest that was missing
`parametersRef` on the GatewayClass, the field stays absent until you re-apply
the full bundle — `kubectl apply` is field-additive on the server side, but
client-side last-applied-configuration tracking can mask the omission.
Re-apply the canonical bundle and re-verify with the `jsonpath` check above.

### Stuck data-plane pods don't self-heal

If the agent's first config apply fails (e.g. due to the `server_tokens` bug),
the agent never serves `:8081/readyz`, so the pod stays 0/1 forever. Kubernetes
self-heal doesn't kick in — kubelet keeps the unready pod running indefinitely.

After fixing the controller-side issue (NginxProxy, parametersRef, etc.):

1. `kubectl rollout restart deploy/<ngf-controller> -n <ngf-ns>` — picks up
   the corrected config-rendering inputs.
2. Delete the stuck data-plane pod — the RS recreates it; the new pod pulls
   current (good) config and goes Ready.

A control-plane restart alone won't unstick an existing 0/1 pod.

## Listener layout

NGF requires **one HTTPS listener per hostname** — you can't have a single
HTTPS listener serving multiple hostnames with cert-manager auto-issued certs,
because each host has its own TLS secret. Fan out:

```yaml
listeners:
- name: https-host-a
  hostname: a.example.com
  port: 443
  protocol: HTTPS
  tls:
    certificateRefs: [{name: a.example.com-tls}]
- name: https-host-b
  hostname: b.example.com
  ...
```

Plus one shared `http` listener for ACME challenges and 80→443 redirects.

## cert-manager on Gateway

Two flips to do together:

- cert-manager must run with `--feature-gates=ExperimentalGatewayAPISupport=true`.
  In repos that use `./cli` for cert-manager generation, this is baked into the
  generator at a specific CLI version — bump `./cli` to a version that includes
  the gate, update `[cert_manager].version` in `settings.toml` if needed, and
  regenerate the cert-manager manifests. Don't hand-patch the Helm values or
  Deployment args.
- Switch `ClusterIssuer` HTTP-01 solver from `ingress.class` to
  `gatewayHTTPRoute` with `parentRefs` pointing at your Gateway.

### Renewal-time bomb

cert-manager keeps using whichever solver the Issuer specifies. If you keep
`ingress.class: nginx` past the cutover, renewals work as long as DNS still
points at the old nginx-ingress LB and that controller is still running.
The moment DNS flips to the Gateway LB or the old ingress is decommissioned,
ACME challenges fail at next renewal (~30 days before expiry — silent until
then).

**Switch the solver as part of the cutover, not after.**

### Issuer/Gateway namespace

cert-manager creates a temporary HTTPRoute in the Gateway's namespace. The
Gateway must allow `HTTPRoute` from the issuer's namespace via
`allowedRoutes.namespaces.from: All` (or an explicit selector). If routes
don't attach, cert-manager will report `pending` indefinitely.

### Pre-seeded secrets and hand-authored Certificates

A common cutover pattern is to pre-seed listener TLS secrets in the gateway
namespace by copying existing material from the old ingress namespaces. This
avoids LE round-trips at flip time and keeps a working cert in place if DNS
hasn't fully propagated. **cert-manager's Gateway integration (the
`ExperimentalGatewayAPISupport` shim) does not adopt those secrets.**
cert-manager only adopts secrets it can prove it issued, via the
`cert-manager.io/issuer-name` / `-kind` / `-group` annotations on the secret
— annotations a hand-copied secret won't have. Any Certificate targeting a
pre-seeded secret surfaces:

```
Reason: IncorrectIssuer
Message: Issuing certificate as Secret was previously issued by "Issuer.cert-manager.io/"
```

and cert-manager re-issues. Two consequences:

1. **Don't add `cert-manager.io/cluster-issuer` to the Gateway annotations
   during a pre-seeded cutover** unless you intend re-issuance. With the
   annotation, the shim auto-derives Certificates from listener hostnames;
   on pre-seeded secrets they all immediately re-issue (same
   `IncorrectIssuer` path). Fine if that's what you want — be deliberate.
   Note: `parts.#UseCertManager` (see CUE wiring below) sets this
   annotation, so skip the mixin on pre-seeded cutovers until ownership
   is established, then add it back for ongoing renewal.

2. **To take ownership of pre-seeded secrets, hand-author one Certificate
   per listener.** Single-SAN `dnsNames` matching the listener hostname,
   `secretName` matching the existing secret, `issuerRef` pointing at the
   ClusterIssuer:

   ```yaml
   apiVersion: cert-manager.io/v1
   kind: Certificate
   metadata:
     name: a.example.com-tls
     namespace: gateway
   spec:
     secretName: a.example.com-tls
     dnsNames: [a.example.com]
     issuerRef: { name: cluster-issuer-main, kind: ClusterIssuer }
   ```

   Outcome is one of: adopt (rare, pre-seeded material lacks the
   annotations) or `IncorrectIssuer` → re-issue via gateway HTTP-01
   (~30s TLS gap per host, brief and recoverable). Re-issue is the
   realistic outcome and is usually what you want — see the duplication
   note below.

End state: each listener secret owned by a Certificate, auto-renewing,
no follow-up cleanup.

### Apex+www two-SAN cleanup

Old Ingresses commonly packed `example.com` and `www.example.com` into a
single 2-SAN cert (one Ingress resource, two `tls.hosts`). When this is
copied into separate listener secrets — `example.com-tls` and
`www.example.com-tls` — both contain identical 2-SAN material. Hand-authoring
single-SAN Certificates per listener mismatches the SANs, forces re-issue,
and produces clean single-SAN material in one step. No follow-up cleanup
needed.

### Re-issue rate-limit math during cutover

Don't talk yourself out of synchronous re-issue across all listeners. LE
limits that actually bite during a small/medium-cluster cutover:

- **Certificates per Registered Domain**: 50/week. `example.com` and
  `example.net` count separately. 6-12 hosts per registered domain has no
  headroom problem.
- **Failed Validation**: 5/hour/host. Only triggers if HTTP-01 fails — and
  if HTTP-01 is broken your gateway path has a separate problem.
- **New Orders**: 300/3h/account. Trivially under.

If the gateway HTTP-01 path is healthy, simultaneous re-issue across all
listeners is fine. Stagger only for attended visibility, not rate-limit
safety.

### Stuck-Challenge recovery

When a partial or aborted cutover leaves orphan Challenges in the gateway
namespace — most often because the solver Ingress ran on the old LB while
DNS already pointed at the new one, so HTTP-01 self-check 404s indefinitely
— manual cleanup is required. The Challenges are finalizer-locked and won't
release on plain delete:

```sh
# Strip finalizers from every Challenge, then cascade-delete.
# Patching a single Challenge by name won't release the rest —
# delete --all blocks until every one is finalizer-free.
kubectl -n gateway get challenge -o name | xargs -I{} \
  kubectl -n gateway patch {} --type=merge \
  -p '{"metadata":{"finalizers":[]}}'
kubectl -n gateway delete challenge --all
kubectl -n gateway delete pod,svc,ingress \
  -l acme.cert-manager.io/http01-solver=true
```

Then delete the parent Certificate, CertificateRequest, **and Order**
(Order cascade is unreliable — it routinely outlives its Certificate
parent), and re-create the Certificate fresh.

Lesson: prefer single-host canaries when the cert-manager + Gateway
wiring isn't yet proven. Bulk failures leave residue that creates
constant controller-loop noise until cleaned manually.

## Operational gotchas

- **`apply.sh` does not prune.** Removing a resource from CUE leaves the live
  object until you `kubectl delete` it. Old Ingresses linger after the cutover
  CUE removes them — explicit cleanup in Phase 5.
- **`apply` updates Secrets, not pods.** Long-lived deployments reading env
  from a Secret won't see new values until restarted. After any cutover apply
  that changes Secrets, `kubectl rollout restart deploy/<name>` for affected
  workloads.
- **Re-applying the upstream argocd manifest resets all argocd workloads to
  `replicas: 1`.** Convenient when re-enabling Argo after a cutover where you
  scaled it to 0; surprising if you didn't expect it.

## ReferenceGrant for cross-namespace HTTPRoutes

If your `HTTPRoute` lives in app namespace `foo` but its `backendRefs` point
at services in namespace `bar`, you need a `ReferenceGrant` in `bar`
permitting `HTTPRoute` from `foo`. Without it, the route attaches but
`backendRefs` resolve to 503. NGF logs the rejection at the controller, not
on the route status.

## Validation checklist (post-apply)

```sh
kubectl get gatewayclass <name>            # ACCEPTED=True
kubectl get gateway -A                     # PROGRAMMED=True, ADDRESS populated
kubectl get httproute -A                   # PARENTS shows the Gateway
kubectl get certificate -A                 # READY=True
```

If any of these fails, work top-down — GatewayClass first, then Gateway,
then routes, then certs. A failure higher up cascades silently.

## CUE wiring (this framework)

`prodigy9.co/defs` v0.1.0+ provides:

- `#GatewayClass`, `packs.#Gateway` (auto-fans listeners per host, includes
  80→443 redirect)
- `parts.#UseCertManager` mixin (annotates Gateway, generates per-host TLS
  certificate refs)
- `#ClusterIssuer` (gateway HTTP-01 only; ingress-class solver intentionally
  not supported — it's the wrong direction)

See `apps/gateway.cue` and `apps/cert-manager.cue` in a recently-migrated
repo for canonical examples.
