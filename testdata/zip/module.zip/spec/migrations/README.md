# Migrations

Spec-archive copies of migration guides. The downstream-repo-facing
copies live in the `p9-infra` skill at
`school/skills/p9-infra/references/migrations/`. When updating, change
both — these archives exist so design discussions on this repo can
reason about the breaking-change history without leaving the tree.

| Doc                                                            | Scope                                                                      |
| -------------------------------------------------------------- | -------------------------------------------------------------------------- |
| [v0.1-to-v0.2.md](v0.1-to-v0.2.md)                             | `var:{}`/`objs` → `#snake_case`, attr/parts split, removed defs/packs.     |
| [v0.2-to-v0.3.md](v0.2-to-v0.3.md)                             | Mixin re-author: drop `.#Direct` and dual-mode, kind-dispatched `_Mixin`.  |
| [ingress-to-gateway.md](ingress-to-gateway.md)                 | Per-cluster Ingress → Gateway API cutover: bugs, cert-manager wiring.     |
| [ingress-to-gateway-rollout.md](ingress-to-gateway-rollout.md) | Phased rollout runbook for the same cutover.                               |
