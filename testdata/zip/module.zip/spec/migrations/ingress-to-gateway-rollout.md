# Ingress → Gateway Rollout Runbook

> Spec-archive copy. Cluster-cutover runbook kept here so framework
> changes can be evaluated against the operational sequence they affect.
> Applies unchanged to both v0.2 and v0.3.

Orchestration for the per-cluster cutover. The sibling
[ingress-to-gateway.md](ingress-to-gateway.md) covers the *what* and *why*
(NGF bugs, cert-manager wiring, recovery); this file covers the *order* —
phases, gates, and rollback. Use both.

Apply this top-down on a fresh downstream repo. Everything below survived
contact with prod on at least one cluster cutover.

## Ground rules

- **Argo stays OFF for the entire rollout.** Scale every workload in the
  `argocd` namespace to 0 (statefulset/argocd-application-controller plus the
  six deployments). Verify zero pods and a frozen `reconciledAt` before
  Phase 1. Argo only comes back in Phase 5, after cleanup.
- **DB backup gates Phase 2 and Phase 4.** Operator-run, separate from this
  runbook. Don't start a cutover without a fresh dump.
- **One env at a time.** Dev fully (Phase 2 → Phase 3) before prod (Phase 4).
- **Manual `kubectl apply` from the working tree** for the duration — the
  shared-gateway Application is intentionally not Argo-tracked, and Argo is
  off anyway.

## Data to record before starting

Capture in the rollout doc, not memory:

- Old ingress-nginx LB IP.
- Pre-cutover DNS state for every public host (which records, which targets).
- Public hostname inventory split by env (e.g. 6 dev + 6 prod + 1 argocd).
- Workloads in `argocd` ns and their replica counts (for restore).

## Phase 0 — Local prep

- [ ] `./cue-check.sh` clean.
- [ ] Regenerate every env; `git status` clean.
- [ ] Sanity-check the commit range about to land (`git log --oneline
      gh/main..HEAD`).
- [ ] Snapshot live state: `kubectl get ingress -A -o yaml >
      ingress-snapshot.yaml`. Keep until Phase 5 closes.
- [ ] **Lower DNS TTL** on every public hostname to 60s (or your provider's
      floor) at least one TTL-cycle before cutover. Makes the soak phase
      collapsible and rollback fast.
- [ ] Scale `argocd` ns to 0. Verify zero pods.

## Phase 1 — Cluster prereqs (additive, no traffic moves)

Order matters; each step must verify before the next.

1. Upgrade cert-manager to a version with Gateway API support GA on by default
   (≥ v1.20.x at time of writing). Bump `[cert_manager].version` in
   `settings.toml` and regenerate via `./cli.sh cert-manager`. Don't
   hand-patch.
2. Install NGF (CRDs + controller). NGF 2.x splits control-plane from
   data-plane — no LB IP exists yet; one per Gateway gets created in Phase 2.
3. **Pin Gateway API CRDs to a version NGF accepts.** NGF 2.5.x requires
   ≥ v1.5.1; the upstream NGF bundle's default of v1.2.x will silently fail
   GatewayClass `Accepted=True`. Set `[nginx_gateway].gateway_api_version` in
   `settings.toml`, regenerate, re-apply.
4. Verify `GatewayClass/<name>` Accepted=True; Gateway/HTTPRoute CRDs present;
   NginxProxy `serverTokens: "off"` (see sibling doc for the bug).

No DNS, no Gateway, no HTTPRoute yet.

## Phase 2 — Dev cutover

Sequence is rigid. Every step gates on the previous.

1. **Backup dev DBs.**
2. **Pre-seed gateway TLS secrets.** Copy the existing per-host TLS secrets
   from each app namespace into the `gateway` namespace, renamed to match
   the listener hostnames (`<host>-tls`). Apex+www can both pull from the
   same source 2-SAN secret — re-issue in Phase 5 will produce clean
   single-SAN material. This avoids LE round-trips at flip time.
3. **Apply gateway manifests.** `./apply.sh gateway`. Watch
   `kubectl get certificate -n gateway -w`. Expect Ready=True near-instant
   (no ACME). If any goes `Issuing` within ~30s, abort — pre-seed didn't
   match listener spec; recover before failed challenges accumulate.
4. **Record the new NGF data-plane LB IP.**
   `kubectl get svc -A -l app.kubernetes.io/name=nginx-gateway -o wide`.
5. **Apply env manifests.** `./apply.sh <env>`. HTTPRoutes attach to the
   shared Gateway. `apply.sh` does not prune — old Ingresses linger until
   Phase 5.
6. **Rolling restart of long-lived deployments whose env reads from a Secret
   that just changed.** `apply` updates Secrets but doesn't reload pods.
   Typically `api` and any worker that reads cluster-DNS service URLs from
   env. Skip Postgres/Redis StatefulSets unless you actually changed their
   Secret.
7. **Verify internal wiring.** Internal services
   (`<name>-service.<env-ns>.svc.cluster.local:<port>`) should already work
   — this is just a smoke check, not a change.
8. **Flip DNS.** Public hosts → new NGF LB. Any host that's becoming
   cluster-only as part of this migration is **removed from public DNS** in
   the same change.
9. **Smoke-test public endpoints.** Every host, expected status code, TLS
   chain valid.

If any step fails, halt and consult the rollback section — don't push
forward to recover.

## Phase 3 — Soak (collapsible)

If Phase 0 dropped DNS TTLs to 60s, soak is optional: rollback is fast
enough that catching async failures during Phase 4 is acceptable. Cert
renewal is explicitly deferred to Phase 5 — pre-seeded secrets are good
for ~90 days.

If TTLs are higher, soak dev for at least one renewal window or one full
business cycle — whichever surfaces async failures (cron jobs, webhooks,
workers with long backoff).

## Phase 4 — Prod cutover

Same sequence as Phase 2, with prod values. No new gotchas — if Phase 2
ran clean, Phase 4 is mechanical.

## Phase 5 — Cleanup (gated order)

**The order matters.** Out-of-order cleanup creates silent failures that
surface 30 days later when an unrelated cert tries to renew.

1. **Validate cert-manager renewal of listener TLS secrets.** Hand-author
   one single-SAN `Certificate` per listener (CUE-managed; see
   `apps/gateway.cue` in a recently-migrated repo). Pre-seeded secrets
   trigger `IncorrectIssuer` and re-issue via gateway HTTP-01 — expected,
   ~30s TLS gap per host. End state: every listener secret owned by a
   Certificate, auto-renewing.
2. **Single-host canary first** if Gateway + cert-manager wiring isn't
   battle-tested in this cluster. One host green end-to-end → batch the
   rest. Bulk failures leave residue (orphan Challenges, finalizer-locked)
   that creates constant controller-loop noise until cleaned manually
   (recovery in sibling doc).
3. **Prune stale Ingresses.** Once gateway-ns Certificates are
   self-renewing, `kubectl delete ingress` per env namespace.
   ingress-shim sweeps the per-ns `Certificate` resources automatically;
   verify no orphan TLS Secrets via label query.
4. **Move the ClusterIssuer.** Delete the old
   `k8s/cert-manager/cluster-issuer.yaml` (HTTP-01 via `ingress.class:
   nginx`). Authoritative copy is now in the gateway dir with a
   `gatewayHTTPRoute` solver. Leaving the old file in tree means the next
   `./cli.sh cert-manager` + apply silently clobbers the gateway solver.
5. **Migrate ArgoCD onto the shared gateway** (if it was on a separate
   ssl-passthrough Ingress). Add an `argo.<domain>` listener; switch
   `argocd-server` to `--insecure` via `argocd-cmd-params-cm`
   (`server.insecure: "true"`); attach an HTTPRoute; drop the old Ingress.
6. **Turn Argo back on.** Re-applying the upstream argocd manifest resets
   all argocd workloads to `replicas: 1` — this doubles as the scale-up.
   Verify all Applications Synced/Healthy.
7. **Uninstall ingress-nginx.** Delete the namespace, `IngressClass nginx`,
   and the admission webhook. Remove `k8s/ingress-nginx/` from the repo.
   Old LB IP is now free.

## Rollback by phase

Pre-Phase-2: revert in-tree, no live impact.

Pre-DNS-flip (Phase 2/4 steps 1–7): `kubectl apply` the prior manifests
from a known-good commit per env. Gateway resources can stay; nothing
points at them yet.

Post-DNS-flip (Phase 2/4 step 8 onward):

1. Revert DNS to the old ingress-nginx LB IP.
2. `kubectl delete -f k8s/gateway/gateway.yaml`. NGF tears down the
   data-plane Deployment + LoadBalancer Service for that Gateway.
   Skipping this leaves the LB live and listening, mismatched with
   reverted DNS.
3. Re-apply the prior env manifests to restore Ingress objects.
4. Replay from the `ingress-snapshot.yaml` from Phase 0 if any object is
   missing.

cert-manager runaway (any phase, ACME orders firing unexpectedly):

1. Strip the cluster-issuer annotation off the Gateway to stop new
   Certificates from spawning:
   ```sh
   kubectl annotate gateway -n gateway <name> cert-manager.io/cluster-issuer-
   ```
2. Delete in-flight orders by deleting all Certificates in the gateway ns.
3. If renewals in *other* namespaces are blocked by the new gateway-only
   solver, temporarily revert the ClusterIssuer to the ingress-class solver
   until the rollout resumes.

LE failed-authz rate-limit window is forgiving (~15–30 min before any
hostname trips, since cert-manager backs off 1m → 2m → 4m…). Move
fastest-first, not perfectly.

## Repo-shape prerequisites

These changes belong in the same set of commits that introduce the
gateway, not as follow-ups:

- `apps/gateway.cue` — shared single Gateway in its own namespace, not
  per-env.
- `config/subdomains.cue` (or equivalent) — public subdomain prefixes
  pulled out of components into one place; Gateway listener list and
  HTTPRoute hostnames both reference it.
- **Internal-only services** (no public HTTPRoute) rebuilt from raw
  `defs.#Secret` + `defs.#Deployment` + `defs.#Service`, not
  `defaults.#WebApp`. Reachable as
  `<name>-service.<env-ns>.svc.cluster.local:<port>`.
- Cross-service URLs in component config switched to cluster DNS in the
  same set, so callers don't need a Phase-2 change.
- `argo/argocd.yaml` gitignored — argocd does not self-manage during the
  cutover.

Without these, the cutover requires app-code changes mid-rollout, which
defeats the phase isolation.
