#!/bin/sh

set -o errexit
set -o xtrace

./cue.sh vet -c ./...
