package defs

import (
	"prodigy9.co/defs/parts"
)

#GatewayClass: Self={
	parts.#Metadata

	#controller: string | *"gateway.nginx.org/nginx-gateway-controller"

	apiVersion: "gateway.networking.k8s.io/v1"
	kind:       "GatewayClass"
	spec: controllerName: Self.#controller
}

tests: gateway_class: [
	// basic — default controller (NGINX Gateway Fabric)
	#GatewayClass & {
		#name: "nginx"
	} & close({
		apiVersion: "gateway.networking.k8s.io/v1"
		kind:       "GatewayClass"
		metadata: close({name: "nginx"})
		spec: close({controllerName: "gateway.nginx.org/nginx-gateway-controller"})
	}),

	// with labels and annotations
	#GatewayClass & {
		#name:       "traefik"
		#controller: "traefik.io/gateway-controller"
		#labels: "prodigy9.co/app":         "cueinfra"
		#annotations: "keel.sh/managed-by": "keel"
	} & close({
		apiVersion: "gateway.networking.k8s.io/v1"
		kind:       "GatewayClass"
		metadata: close({
			name: "traefik"
			labels: close({"prodigy9.co/app": "cueinfra"})
			annotations: close({"keel.sh/managed-by": "keel"})
		})
		spec: close({controllerName: "traefik.io/gateway-controller"})
	}),
]
