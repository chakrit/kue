package defs

import (
	"prodigy9.co/defs/parts"
)

#ServiceAccount: {
	parts.#Metadata

	apiVersion: "v1"
	kind:       "ServiceAccount"
}

tests: service_account: [
	// basic
	#ServiceAccount & {
		#name: "example"
		#ns:   "my-ns"
	} & close({
		apiVersion: "v1"
		kind:       "ServiceAccount"
		metadata: close({
			name:      "example"
			namespace: "my-ns"
		})
	}),

	// with labels
	#ServiceAccount & {
		#name: "example"
		#ns:   "my-ns"
		#labels: "prodigy9.co/app":         "cueinfra"
		#annotations: "keel.sh/managed-by": "keel"
	} & close({
		apiVersion: "v1"
		kind:       "ServiceAccount"
		metadata: close({
			name:      "example"
			namespace: "my-ns"
			labels: "prodigy9.co/app":         "cueinfra"
			annotations: "keel.sh/managed-by": "keel"
		})
	}),
]
