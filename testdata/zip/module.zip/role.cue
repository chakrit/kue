package defs

import (
	"prodigy9.co/defs/parts"
)

#Role: Self={
	parts.#Metadata

	#rules: [...{
		groups: [...string] | *["*"] // default to core API group
		resources: [...string] | *["*"]
		names?: [...string]
		verbs: [...string] | *["*"]
	}]

	apiVersion: "rbac.authorization.k8s.io/v1"
	kind:       "Role"
	rules: [
		for r in Self.#rules {
			apiGroups: r.groups
			resources: r.resources
			verbs:     r.verbs

			if r.names != _|_ {
				resourceNames: r.names
			}
		},
	]
}

tests: role: [
	// basic
	#Role & {
		#name: "example"
		#ns:   "my-ns"

		#rules: [{
			groups: ["apps", "extensions"]
			resources: ["deployments"]
			verbs: ["get", "list", "watch"]
		}, {
			resources: ["pods"]
			verbs: ["get", "list"]
		}]
	} & close({
		apiVersion: "rbac.authorization.k8s.io/v1"
		kind:       "Role"
		metadata: close({name: "example", namespace: "my-ns"})
		rules: [
			{
				apiGroups: ["apps", "extensions"]
				resources: ["deployments"]
				verbs: ["get", "list", "watch"]
			},
			{
				apiGroups: ["*"]
				resources: ["pods"]
				verbs: ["get", "list"]
			},
		]
	}),

	// with labels and resource names
	#Role & {
		#name: "example"
		#ns:   "my-ns"
		#labels: "prodigy9.co/app":         "cueinfra"
		#annotations: "keel.sh/managed-by": "keel"

		#rules: [{
			groups: ["apps", "extensions"]
			resources: ["deployments"]
			names: ["cueinfra-deployment", "another-deployment"]
			verbs: ["get", "list", "watch"]
		}, {
			resources: ["pods"]
			verbs: ["get", "list"]
		}]

	} & close({
		apiVersion: "rbac.authorization.k8s.io/v1"
		kind:       "Role"
		metadata: close({
			name:      "example"
			namespace: "my-ns"
			labels: "prodigy9.co/app":         "cueinfra"
			annotations: "keel.sh/managed-by": "keel"
		})
		rules: [
			close({
				apiGroups: ["apps", "extensions"]
				resources: ["deployments"]
				resourceNames: ["cueinfra-deployment", "another-deployment"]
				verbs: ["get", "list", "watch"]
			}),
			close({
				apiGroups: ["*"]
				resources: ["pods"]
				verbs: ["get", "list"]
			}),
		]
	}),

]
