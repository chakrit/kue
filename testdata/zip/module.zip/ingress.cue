package defs

import (
	"prodigy9.co/defs/attr"
	"prodigy9.co/defs/parts"
)

#Ingress: Self={
	parts.#Metadata
	attr.#Hosts
	attr.#ServiceRef

	#ingress_class: string | *"nginx"

	apiVersion: "networking.k8s.io/v1"
	kind:       "Ingress"

	spec: {
		ingressClassName: Self.#ingress_class
		tls: [
			for h in Self.#hosts {
				hosts: [h]
				secretName: "\(h)-tls"
			},
		]
		rules: [
			for h in Self.#hosts {
				host: h
				http: paths: [{
					path:     "/"
					pathType: "Prefix"
					backend: service: {
						name: Self.#service_name
						port: number: Self.#service_port
					}
				}]
			},
		]
		...
	}
	...
}

tests: ingress: [

	// basic
	{
		#Expected: {
			apiVersion: "networking.k8s.io/v1"
			kind:       "Ingress"
			metadata: {
				name:      "my-ingress"
				namespace: "my-ns"
			}
			spec: {
				ingressClassName: "nginx"
				tls: [{
					hosts: ["example.com"]
					secretName: "example.com-tls"
				}]
				rules: [
					{
						host: "example.com"
						http: paths: [{
							path:     "/"
							pathType: "Prefix"
							backend: service: {
								name: "my-service"
								port: number: 80
							}
						}]
					},
				]
			}
		}

		#Expected & #Ingress & {
			#name: "my-ingress"
			#ns:   "my-ns"
			#hosts: ["example.com"]
			#service_name: "my-service"
			#service_port: 80
		}
	},

	// multiple hosts
	{
		#Expected: {
			apiVersion: "networking.k8s.io/v1"
			kind:       "Ingress"
			metadata: {
				name:      "my-ingress"
				namespace: "my-ns"
			}
			spec: {
				ingressClassName: "nginx"
				tls: [{
					hosts: ["alpha.com"]
					secretName: "alpha.com-tls"
				}, {
					hosts: ["beta.com"]
					secretName: "beta.com-tls"
				}]
				rules: [
					{
						host: "alpha.com"
						http: paths: [{
							path:     "/"
							pathType: "Prefix"
							backend: service: {
								name: "my-service"
								port: number: 80
							}
						}]
					},
					{
						host: "beta.com"
						http: paths: [{
							path:     "/"
							pathType: "Prefix"
							backend: service: {
								name: "my-service"
								port: number: 80
							}
						}]
					},
				]
			}
		}

		#Expected & #Ingress & {
			#name: "my-ingress"
			#ns:   "my-ns"
			#hosts: ["alpha.com", "beta.com"]
			#service_name: "my-service"
			#service_port: 80
		}
	},

]
