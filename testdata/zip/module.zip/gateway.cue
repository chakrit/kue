package defs

import (
	"strings"

	"prodigy9.co/defs/attr"
	"prodigy9.co/defs/parts"
)

#Gateway: Self={
	parts.#Metadata
	attr.#Hosts

	#gateway_class: string
	#tcp_ports: [...int] | *[]
	#passthrough_hosts: [...string] | *[]

	apiVersion: "gateway.networking.k8s.io/v1"
	kind:       "Gateway"

	spec: {
		gatewayClassName: Self.#gateway_class
		listeners: [
			for h in Self.#hosts {
				name:     "https-\(strings.Replace(h, ".", "-", -1))"
				hostname: h
				port:     443
				protocol: "HTTPS"
				tls: {
					mode: "Terminate"
					certificateRefs: [{name: "\(h)-tls"}]
				}
				allowedRoutes: namespaces: from: "All"
			},
			{
				name:     "http"
				port:     80
				protocol: "HTTP"
				allowedRoutes: namespaces: from: "All"
			},
			for h in Self.#passthrough_hosts {
				name:     "tls-\(strings.Replace(h, ".", "-", -1))"
				hostname: h
				port:     443
				protocol: "TLS"
				tls: mode: "Passthrough"
				allowedRoutes: namespaces: from: "All"
			},
			for p in Self.#tcp_ports {
				name:     "tcp-\(p)"
				port:     p
				protocol: "TCP"
				allowedRoutes: namespaces: from: "All"
			},
		]
		...
	}
	...
}

tests: gateway: [

	// single host: https + http listeners
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "Gateway"
			metadata: {
				name:      "my-gateway"
				namespace: "my-ns"
			}
			spec: {
				gatewayClassName: "cilium"
				listeners: [{
					name:     "https-example-com"
					hostname: "example.com"
					port:     443
					protocol: "HTTPS"
					tls: {
						mode: "Terminate"
						certificateRefs: [{name: "example.com-tls"}]
					}
					allowedRoutes: namespaces: from: "All"
				}, {
					name:     "http"
					port:     80
					protocol: "HTTP"
					allowedRoutes: namespaces: from: "All"
				}]
			}
		}

		#Expected & #Gateway & {
			#name:          "my-gateway"
			#ns:            "my-ns"
			#gateway_class: "cilium"
			#host:          "example.com"
		}
	},

	// multiple hosts: one https listener per host
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "Gateway"
			metadata: {
				name:      "my-gateway"
				namespace: "my-ns"
			}
			spec: {
				gatewayClassName: "cilium"
				listeners: [{
					name:     "https-alpha-example-com"
					hostname: "alpha.example.com"
					port:     443
					protocol: "HTTPS"
					tls: {
						mode: "Terminate"
						certificateRefs: [{name: "alpha.example.com-tls"}]
					}
					allowedRoutes: namespaces: from: "All"
				}, {
					name:     "https-beta-example-com"
					hostname: "beta.example.com"
					port:     443
					protocol: "HTTPS"
					tls: {
						mode: "Terminate"
						certificateRefs: [{name: "beta.example.com-tls"}]
					}
					allowedRoutes: namespaces: from: "All"
				}, {
					name:     "http"
					port:     80
					protocol: "HTTP"
					allowedRoutes: namespaces: from: "All"
				}]
			}
		}

		#Expected & #Gateway & {
			#name:          "my-gateway"
			#ns:            "my-ns"
			#gateway_class: "cilium"
			#hosts: ["alpha.example.com", "beta.example.com"]
		}
	},

	// host + tcp ports: https + http + tcp listeners
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "Gateway"
			metadata: {
				name:      "my-gateway"
				namespace: "my-ns"
			}
			spec: {
				gatewayClassName: "cilium"
				listeners: [{
					name:     "https-db-example-com"
					hostname: "db.example.com"
					port:     443
					protocol: "HTTPS"
					tls: {
						mode: "Terminate"
						certificateRefs: [{name: "db.example.com-tls"}]
					}
					allowedRoutes: namespaces: from: "All"
				}, {
					name:     "http"
					port:     80
					protocol: "HTTP"
					allowedRoutes: namespaces: from: "All"
				}, {
					name:     "tcp-5432"
					port:     5432
					protocol: "TCP"
					allowedRoutes: namespaces: from: "All"
				}, {
					name:     "tcp-6379"
					port:     6379
					protocol: "TCP"
					allowedRoutes: namespaces: from: "All"
				}]
			}
		}

		#Expected & #Gateway & {
			#name:          "my-gateway"
			#ns:            "my-ns"
			#gateway_class: "cilium"
			#host:          "db.example.com"
			#tcp_ports: [5432, 6379]
		}
	},

	// passthrough hosts: https + http + tls listeners
	{
		#Expected: {
			apiVersion: "gateway.networking.k8s.io/v1"
			kind:       "Gateway"
			metadata: {
				name:      "my-gateway"
				namespace: "my-ns"
			}
			spec: {
				gatewayClassName: "nginx"
				listeners: [{
					name:     "https-app-example-com"
					hostname: "app.example.com"
					port:     443
					protocol: "HTTPS"
					tls: {
						mode: "Terminate"
						certificateRefs: [{name: "app.example.com-tls"}]
					}
					allowedRoutes: namespaces: from: "All"
				}, {
					name:     "http"
					port:     80
					protocol: "HTTP"
					allowedRoutes: namespaces: from: "All"
				}, {
					name:     "tls-grpc-example-com"
					hostname: "grpc.example.com"
					port:     443
					protocol: "TLS"
					tls: mode: "Passthrough"
					allowedRoutes: namespaces: from: "All"
				}]
			}
		}

		#Expected & #Gateway & {
			#name:          "my-gateway"
			#ns:            "my-ns"
			#gateway_class: "nginx"
			#host:          "app.example.com"
			#passthrough_hosts: ["grpc.example.com"]
		}
	},

]
