package defs

import (
	"prodigy9.co/defs/parts"
)

#RoleBinding: Self={
	parts.#Metadata

	#role?:         #Role | string
	#cluster_role?: #ClusterRole | string

	_role: {
		name: string
		kind: "Role" | "ClusterRole"
	}
	if Self.#role != _|_ {
		_role: {
			name: string & (Self.#role | Self.#role.#name)
			kind: "Role"
		}
	}
	if Self.#cluster_role != _|_ {
		_role: {
			name: string & (Self.#cluster_role | Self.#cluster_role.#name)
			kind: "ClusterRole"
		}
	}

	#service_account:    #ServiceAccount | string
	#service_account_ns: string | *Self.#ns

	// resolve inputs
	let sa = string & (Self.#service_account | Self.#service_account.#name)
	if Self.#service_account.#ns != _|_ {
		#service_account_ns: Self.#service_account.#ns
	}

	// output
	apiVersion: "rbac.authorization.k8s.io/v1"
	kind:       "RoleBinding"
	subjects: [
		{
			kind:      "ServiceAccount"
			name:      sa
			namespace: Self.#service_account_ns
		},
	]
	roleRef: {
		kind:     Self._role.kind
		name:     Self._role.name
		apiGroup: "rbac.authorization.k8s.io"
	}
}

tests: role_binding: [
	// string cluster role
	#RoleBinding & {
		#name:               "example-binding"
		#ns:                 "my-ns"
		#cluster_role:       "example-role"
		#service_account:    "example-sa"
		#service_account_ns: "sa-ns"
	} & close({
		apiVersion: "rbac.authorization.k8s.io/v1"
		kind:       "RoleBinding"
		metadata: close({name: "example-binding", namespace: "my-ns"})
		subjects: [{
			kind:      "ServiceAccount"
			name:      "example-sa"
			namespace: "sa-ns"
		}]
		roleRef: {
			kind:     "ClusterRole"
			name:     "example-role"
			apiGroup: "rbac.authorization.k8s.io"
		}
	}),

	// cluster role string, default sa ns
	#RoleBinding & {
		#name:            "example-binding"
		#ns:              "my-ns"
		#cluster_role:    "admin"
		#service_account: "example-sa"
	} & {
		subjects: [{
			kind:      "ServiceAccount"
			name:      "example-sa"
			namespace: "my-ns"
		}]
		roleRef: {
			kind:     "ClusterRole"
			name:     "admin"
			apiGroup: "rbac.authorization.k8s.io"
		}
	},

	// with #Role ref
	#RoleBinding & {
		#name: "example-binding"
		#ns:   "my-ns"
		#role: #Role & {#name: "example-role", #ns: "my-ns"}
		#service_account: #ServiceAccount & {#name: "example-sa", #ns: "sa-ns"}
	} & close({
		apiVersion: "rbac.authorization.k8s.io/v1"
		kind:       "RoleBinding"
		metadata: close({name: "example-binding", namespace: "my-ns"})
		subjects: [{
			kind:      "ServiceAccount"
			name:      "example-sa"
			namespace: "sa-ns"
		}]
		roleRef: {
			kind:     "Role"
			name:     "example-role"
			apiGroup: "rbac.authorization.k8s.io"
		}
	}),

	// with #ClusterRole ref
	#RoleBinding & {
		#name: "example-binding"
		#ns:   "my-ns"
		#cluster_role: #ClusterRole & {#name: "example-cluster-role"}
		#service_account: "example-sa"
	} & close({
		apiVersion: "rbac.authorization.k8s.io/v1"
		kind:       "RoleBinding"
		metadata: close({name: "example-binding", namespace: "my-ns"})
		subjects: [{
			kind:      "ServiceAccount"
			name:      "example-sa"
			namespace: "my-ns"
		}]
		roleRef: {
			kind:     "ClusterRole"
			name:     "example-cluster-role"
			apiGroup: "rbac.authorization.k8s.io"
		}
	}),

	// inputs-only: disjunction must resolve without output constraints
	(#RoleBinding & {
		#name:            "resolve-binding"
		#ns:              "my-ns"
		#cluster_role:    "admin"
		#service_account: "example-sa"
	}),

	// error: both #role and #cluster_role provided
	(#RoleBinding & {
		#name:            "both-binding"
		#ns:              "my-ns"
		#role:            "my-role"
		#cluster_role:    "my-cluster-role"
		#service_account: "example-sa"
	}) | "expected error: mutually exclusive",
]
